%% pkt format

% each word have 64 bits
% Each word is subdivided in I or Q words of 16 bits, where the LSB is 
% zeroed due CPRI packet
% The  first word is the header with the following informations:
% 15:0  have the number of Huffman words for imag part
% 31:16 have the number of Huffman words for real part
%
% For each nonquantized sample, the a word of 60 bits have the following
% information
% 15:0 have the nonquantized imag. samples
% 31:16 have the nonquantized real samples
%
% The reaminig words have 
% 60 bits of Huffman codes for real part
% 60 bits of Huffman codes for imag part
%
%
% For each 15 bits (in each word of 60 bits) a zero is appended, such that 
% there are 64 bits to be saved in DMA
%
% Parameters: 
% nq_fi_re real part of non quantized samples
% nq_fi_im imag part of non quantized samples
% indices_encoded_re Huffman encoded streams of LPC real samples
% indices_encoded_re Huffman encoded streams of LPC imag samples
%
% Return:
% DMA words with 32 bits each one
function words_dma = pusqh_build_pkt(nq_fi_re,nq_fi_im,indices_encoded_re,indices_encoded_im,duplicate_streams,filename)

len_nq_re = length(nq_fi_re);
len_nq_im = length(nq_fi_im);

ind_Nwords_re = 29:44;
ind_Nwords_im = 45:60;

if(len_nq_re~=len_nq_im)
    error('Number of not quantized samples must be the same in real and imag pats.');
end

% The words of 32 bits are ready to be delivered to CPRI source
[words32b_nq,words60b_nq]           = pusqh_add_fields_to_nq_samples(nq_fi_re,nq_fi_im);
[words32b_Huff_re,words59b_Huff_re,words60b_Huff_re] = pusqh_add_fields_to_huffman_streams(indices_encoded_re);
[words32b_Huff_im,words59b_Huff_im,words60b_Huff_im] = pusqh_add_fields_to_huffman_streams(indices_encoded_im);


% Build header
% The header is a single word of 60 bits mapped in 64 bits
% TODO: make the header and buildwords of 32 bits
header_word = zeros(60,1);

% Number of words of Huffman coded
Nwords_Huff_re = size(words60b_Huff_re,2);
Nwords_Huff_im = size(words60b_Huff_im,2);

% Binary of number of words in array of 1's and 0's instead of char
Nwords_Huff_re_bin = dec2bin(Nwords_Huff_re,16) - '0';
Nwords_Huff_im_bin = dec2bin(Nwords_Huff_im,16) - '0';

% MSB of header is 1 to indicate First Word of Symbol (FWS)
header_word(1) = 1;

% LSBs of header indicate the Number of words in each Huffman stream
header_word(ind_Nwords_re) = Nwords_Huff_re_bin;
header_word(ind_Nwords_im) = Nwords_Huff_im_bin;

header_word_15b = reshape(header_word,15,[]);

header_word_16b = [header_word_15b; zeros(1,4)];

header_word_64b = header_word_16b(:);

header_words_32b = reshape(header_word_64b(:),32,[]);

words_pkt_32b_bin = [header_words_32b words32b_nq words32b_Huff_re ...
                                                        words32b_Huff_im];

Nwords_32b = size(words_pkt_32b_bin,2);

words_pkt_32b_dec = zeros(Nwords_32b,1);

for i= 1 : Nwords_32b
    words_pkt_32b_dec(i) = bin2dec(sprintf('%d',words_pkt_32b_bin(:,i)));
end

words_dma = words_pkt_32b_dec;

if nargin >=5
    % TODO: create different streams for each antenna carrier
    if duplicate_streams
        words_axc0  = words_pkt_32b_dec;
        words_axc1  = words_pkt_32b_dec;

        words_dma   = zeros(2*Nwords_32b,1);

        words_dma(1:2:end) = words_axc0;
        words_dma(2:2:end) = words_axc1;
    end
end

if nargin>=6
    save_int_as_ascii(filename,words_dma);
end

end


