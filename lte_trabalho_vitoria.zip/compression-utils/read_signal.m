% READ_SIGNAL returns a signal stored in a file, 
%
% usage: 
% 
% signal=read_signal(signal_real_filename)
% read all the signal stored in SIGNAL_REAL_FILENAME as a float
%
% signal=read_signal(signal_real_filename,signal_len)
% read SIGNAL_LEN samples stored in SIGNAL_REAL_FILENAME as a float
%
% signal=read_signal(signal_real_filename,signal_len,signal_enconding)
% read SIGNAL_LEN samples stored in SIGNAL_REAL_FILENAME encoded with SIGNAL_ENCONDING
%
function signal=read_signal(signal_filename,signal_len,signal_enconding)

fp_signal = fopen([signal_filename],'r');
if (-1==fp_signal)
    error(sprintf('unable to open %s',signal_filename));
end


if(1==nargin)
    signal=fread(fp_signal,Inf,'float');
elseif(2==nargin)
    signal=fread(fp_signal,signal_len,'float');
else
    signal=fread(fp_signal,signal_len,signal_enconding);
end

fclose(fp_signal);
end