% This script loads the compressed OFDM symbols and add zero at bits 0 and 16.
% The input file is organized in word of 32 bits.
% The steps performed by algorithm are described below:
% 
% 1) creates a single long vector of the input bits
% 2) Split the long vector in words of 15 bits, and fill with zeros if
% necessary, in order to have a integer number of words with 15 bits
% 3) For each word of 15 bits, append a dummy zero
% 4) recreate the words with 32 bits

function words_with_dummy0s_dec = read_pusqh_pkt_and_insert0s(filename)
    words_uint32    = read_signal(filename,Inf,'uint32');
    words_hex8      = dec2hex(words_uint32,8);
    words_bin32     = dec2bin(words_uint32,32);
    
    %each word is in a collumn, instead of in eachline
    words_bin32_trans = transpose(words_bin32);
    
    %1) creates a single long vector
    words_vec       = words_bin32_trans(:);
    
    % Number of bits necessary to be total be a multiple of 15
    fill_with   = 15-mod(length(words_vec),15);
    filer_bits  = zeros(fill_with,1);
    filer_bits_char = sprintf('%d',filer_bits);
    
    words_vec_padded_to_15bits = [words_vec(:); filer_bits_char(:)];
    
    %2) Split the long vector in words of 15 bits, and fill with zeros if
    %necessary
    words_15bits = reshape(words_vec_padded_to_15bits,15,[]);
    
    % For each 15 bits, a dummy zero is appended at the end
    N_words_15bits = size(words_15bits,2);
    dummy_zeros = sprintf('%d',zeros(1,N_words_15bits));
    
    %3) For each word of 15 bits, append a dummy zero
    words_16bits_with_dummy0    = [words_15bits; dummy_zeros];
    
    N_words_16bits = size(words_16bits_with_dummy0,2);
    
    
    
    if(mod(N_words_16bits,2)~=0)
        % verify if the number of words with 16 bits are odd.
        % Two words of 16 bits will create one word of 32 bits. 
        % Thus the number of words with 16 bits must be even.
        
        filler_word16bits = num2str(zeros(16,1));
        
        words_16bits_with_dummy0 = [words_16bits_with_dummy0  filler_word16bits];
    end
    
    %4) recreate the words with 32 bits
    words_32bits_with_dummy0s       = reshape(words_16bits_with_dummy0,32,[]);
    
    words_32bits_with_dummy0s_trans = transpose(words_32bits_with_dummy0s);
    
    % decimal representation 
    words_with_dummy0s_dec = bin2dec(words_32bits_with_dummy0s_trans); 
    
    %% decoding. Going back to original stream
    if 1
        rx_words_32bits_bin = dec2bin(words_with_dummy0s_dec);
        
        rx_words_32bits_bin_trans = transpose(rx_words_32bits_bin);
        
        %RX1) split the input bits in col of 16 bits
        rx_words_16bits     = reshape(rx_words_32bits_bin_trans,16,[]);
        
        %RX2) discard the LSB of each array, creating words of 15 bits
        rx_words_15bits     = rx_words_16bits(1:15,:);
        
        %RX3) From words of 15 bits, recreates a single stream of bits
        % (without the dummy 0s) 
        rx_words_15bits_col = rx_words_15bits(:);
        
        extra_bits = mod(length(rx_words_15bits_col),32);
        
        rx_words_15bits_col_aligned = rx_words_15bits_col(1:end-extra_bits);
        
        %RX4) from the stream without dummy 0s, get streams of 32 bits
        rx_words_32_bits = reshape(rx_words_15bits_col_aligned,32,[]);
        
        rx_words_32_bits_trans = transpose(rx_words_32_bits);
        
        rx_words_dec = bin2dec(rx_words_32_bits_trans);
        
        diff = sum(abs(rx_words_dec - words_uint32));
        
        if(diff == 0)
            disp('coding and decoding sucefful');
        else
            error('coding and decoding failed');
        end
        
    end
end