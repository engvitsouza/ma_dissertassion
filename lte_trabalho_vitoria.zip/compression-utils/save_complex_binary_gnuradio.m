function save_complex_binary_gnuradio(filename,cplx)

signal_file=[real(cplx(:)).'; imag(cplx(:)).'];

f = fopen (filename, 'wb');
fwrite(f,signal_file(:),'float');
fclose(f);
end