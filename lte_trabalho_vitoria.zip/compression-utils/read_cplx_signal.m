% READ_CPLX_SIGNAL returns a complex signal, where the real part is in a
% file named SIGNAL_REAL_FILENAME and the imaginary part in SIGNAL_IMAG_FILENAME
%
% usage: 
% signal_cplx=read_cplx_signal(signal_real_filename,signal_imag_filename,fileType)
%
% fileType is optional
%
function signal_cplx=read_cplx_signal(signal_real_filename,signal_imag_filename,fileType);
% load not-quantized signals
fp_signal_real = fopen([signal_real_filename],'r');
fp_signal_imag = fopen([signal_imag_filename],'r');

if (fp_signal_real==-1)
    error(sprintf('unable to open %s',signal_real_filename));
end

% read all samples of the signal
if (3 ==nargin)
    signal_i=fread(fp_signal_real,Inf,fileType);
    signal_q=fread(fp_signal_imag,Inf,fileType);
else
    signal_i=fread(fp_signal_real,Inf,'float');
    signal_q=fread(fp_signal_imag,Inf,'float');
end
fclose(fp_signal_real);
fclose(fp_signal_imag);

signal_cplx = complex(signal_i(:),signal_q(:));

end