function save_dict(dict_huffman,filename_prefix)
[number_of_cws,nothing] = size(dict_huffman);
cw_index = 0:number_of_cws-1;

cws_length_dusq     = zeros(number_of_cws,1);
dict_huffman_str       = cell(number_of_cws,3);
for i=1:number_of_cws
    cws_length_dusq(i)  = length(cell2mat(dict_huffman(i,2)));
    dict_huffman_str{i,1} = cell2mat(dict_huffman(i,1)); % index
    dict_huffman_str{i,2} = sprintf('%d',cell2mat(dict_huffman(i,2))); % codeword
    dict_huffman_str{i,3} = cws_length_dusq(i); % length of codeword
end

%dict_dusq_str_sorted    = sortcell(dict_huffman_str,3);

cw_lengths  = unique(cell2mat(dict_huffman_str(:,3)));
fp_cw       = zeros(length(cw_lengths),1);
fp_index    = zeros(length(cw_lengths),1);

%% open all files
for i=1:length(cw_lengths)
    filename_cw     = sprintf('%s.%d.cw',filename_prefix,cw_lengths(i));
    filename_ind    = sprintf('%s.%d.ind',filename_prefix,cw_lengths(i));
    fp_cw(i) = fopen(filename_cw,'w');
    fp_index(i) = fopen(filename_ind,'w');
end

%% write files
for i=1:number_of_cws
    cw_decoded  = dict_huffman_str{i,1};
    cw_str      = dict_huffman_str{i,2};
    cw_len      = dict_huffman_str{i,3};
    
    % there is one length per iteration 'cw_lengths' has unique values
    save_in_file_ind = find (cw_lengths == cw_len);
    
    fprintf(fp_cw(save_in_file_ind),'%s\n',cw_str);
    fprintf(fp_index(save_in_file_ind),'%d\n',cw_decoded);
end

% i = number_of_cws;
% cw_decoded  = dict_huffman_str{i,1};
% cw_str      = dict_huffman_str{i,2};
% cw_len      = dict_huffman_str{i,3};
% 
% % there is one length per iteration 'cw_lengths' has unique values
% save_in_file_ind = find (cw_lengths == cw_len);
% 
% fprintf(fp_cw(save_in_file_ind),'%s',cw_str);
% fprintf(fp_index(save_in_file_ind),'%d',cw_decoded);

%% close all files
for i=1:length(cw_lengths)
    fclose(fp_cw(i));
    fclose(fp_index(i));
end

end