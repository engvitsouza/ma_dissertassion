function [iqClipped]=clip(iq,maximum_par_dB)
    % Hard clipping
    crestFactor = 10^(maximum_par_dB/20); 
    rms = std(iq(:));
    clipLevel = rms*crestFactor;
    iqClipped = min(abs(iq), clipLevel).*sign(iq);
end