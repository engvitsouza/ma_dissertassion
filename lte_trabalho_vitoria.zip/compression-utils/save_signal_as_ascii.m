function save_signal_as_ascii(filename,x)

fp = fopen([filename],'w');

fprintf(fp,'%f\n',x(:));

fclose(fp);
end