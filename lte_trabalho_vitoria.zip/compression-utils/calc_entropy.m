% This function calculates the entropy of a given dstribution
%
% Usage:
% H = calc_entropy(p)
% p is the probability function
% H is the entropy of p
function H = calc_entropy(p)
if(single(sum(p))~=single(1))
    error('The input distribution must sum 1');
end
if(p<0)
    error('The distribution must contain only positive values');
end
% Note that -0*log(0)=0, so the sum need only of non-zero values
p_non_zero= p(find(0~=p));
H=-sum(p_non_zero.*log2(p_non_zero));