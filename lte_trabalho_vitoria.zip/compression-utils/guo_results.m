% This file has the results of guo et al in [1]
%
% [1] LTE/LTE-A Signal Compression on the CPRI Interface

% number of bits per I or Q uncompressed sample
Qs=15;

% Compression ratios
guo_results_comp_ratio  = [0.5201 0.4757 0.4313 0.3868 0.3424 0.2979 0.2535 0.209 0.1646 0.1201];

% Rate in bits per second for each IQ component
guo_results_bps         = guo_results_comp_ratio*Qs;


%% Our simulations results
guo_results_snr_dB      = [37.7466 37.0046 36.8606 36.9119 34.658 31.2091 25.8216 19.7423 13.1991 5.9057];
% Average frequency domain EVM accoding to the Annecx E of 3gpp 36.104
guo_results_avg_evm     = [0.1858 0.2268 0.3379 0.5962 1.1514 2.2945 4.6446 9.6057 20.5612 47.7371];