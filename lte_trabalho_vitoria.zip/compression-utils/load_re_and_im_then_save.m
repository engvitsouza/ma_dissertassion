function total_samples=load_re_and_im_then_save(filename_re,filename_im,filename_re_and_im)
s_re=read_signal(filename_re);
s_im=read_signal(filename_im);
s_re_and_im=[s_re(:) ; s_im(:)];
total_samples = length(s_re_and_im);
save_signal(s_re_and_im,filename_re_and_im,'float');
end