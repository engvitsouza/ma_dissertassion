% this function takes an Huffman stream and pack it to be delivered to CPRI
% source 
%
% TODO: improve description of function
%
% *streams* are words of 32 bits that must be delivered to CPRI source
% *rx_60b* are the 60 bits words in output of CRPI sink
% *rx_59b* are 59 bits words in output of CPRI sink and with the flag of
% first sample removed
function [streams,rx_59b,rx_60b] = pusqh_add_fields_to_huffman_streams(indices_encoded)
    
    Bits_per_pkt_word   = 59;
    Nbits               = length(indices_encoded(:));
    if(mod(Nbits,Bits_per_pkt_word) ==0)
        pkt_paylod_bits     = indices_encoded(:);
    else
        Nfilling_bits       = Bits_per_pkt_word - mod(Nbits,Bits_per_pkt_word);
        pkt_paylod_bits     = [indices_encoded(:); zeros(Nfilling_bits,1)];
    end
    
    
    payload_words       = reshape(pkt_paylod_bits,Bits_per_pkt_word,[]);
    
    % Number of payod words
    Nwords              = size(payload_words,2);
    
    %% 1) Add the bit of "first sample of symbol". This bit is '1' only in 
    % header. In word first
    
    % first sample of symbol
    fss_bits = zeros(1,Nwords);
    
    payload_words_with_fss = [fss_bits; payload_words];
    
    %% 2) Add the dummy zeros that will be removed by CPRI codec at LSB of 
    % each word with 16 bits
    payload_words_with_fss_15b = reshape(payload_words_with_fss(:),15,[]);
    
    Nwords_15b  = size(payload_words_with_fss_15b,2);
    
    dummy_bits  = zeros(1,Nwords_15b);
    
    words_16b   = [payload_words_with_fss_15b; dummy_bits];
    
    Nwords_16b  = size(words_16b,2);
    
    streams     = reshape(words_16b(:),32,[]);
    
    %% decoder
    if 1
        
        %RX1) split in words of 16 bits 
        rx_16b = reshape(streams(:),16,[]);
        
        %RX2) Remove LSBs (control words of CPRI)
        rx_15b = rx_16b(1:15,:);
        
        %RX3) Reorganize in 60 bits
        rx_60b = reshape(rx_15b(:),60,[]);
        
        %RX4) remove MSB (flag of first symbol)
        rx_59b = rx_60b(2:end,:);
        
        rx_stream = rx_59b(:);
        % check if the stream in rx is compliant with the stream in tx
        if(sum(abs(rx_stream(1:Nbits)-indices_encoded))==0)
            disp('Huffman streams codifed correctly');
        else
            error('Huffman streams codifed with error');
        end
        
    end
end


