% TODO: make a description of function
function [streams,rx_60b] = pusqh_add_fields_to_nq_samples(nq_fi_re,nq_fi_im)
    
    bits_per_payload_word   = 60;
    
    %location of real and imag parts in words of 60 bits
    ind_re = 29:44;
    ind_im = 45:60;
    
    nq_fi_re = nq_fi_re(:);
    nq_fi_im = nq_fi_im(:);
    
    % convert binary str to matrix of num
    nq_re_bin       = (nq_fi_re.bin-'0');
    nq_im_bin       = (nq_fi_im.bin-'0');
    Nbits_per_nq    = length(nq_re_bin);
    Nwords_nq       = length(nq_fi_re);
    
    words_60b       = zeros(Nwords_nq,bits_per_payload_word);
      
    words_60b(1:Nwords_nq,ind_im) = nq_im_bin;
    words_60b(1:Nwords_nq,ind_re) = nq_re_bin;
    
    
    words_60b_col = transpose(words_60b);
    
    words_15b = reshape(words_60b_col(:),15,[]);
    
    Nwords_15b = size(words_15b,2);
    
    %% insert 0's in LSBs
    words_16b_with_zeros = [words_15b; zeros(1,Nwords_15b)];
    
    streams = reshape(words_16b_with_zeros,32,[]);
    %% decoder 
    if 1
        %RX1) split in words of 16 bits 
        rx_16b = reshape(streams(:),16,[]);
        
        %RX2) Remove LSBs (control words of CPRI)
        rx_15b = rx_16b(1:15,:);
        
        %RX3) Reorganize in 60 bits
        rx_60b = reshape(rx_15b(:),60,[]);
        
        %RX4) find words in each
        rx_bin_re = rx_60b(ind_re,:);
        rx_bin_im = rx_60b(ind_im,:);
        
        rx_bin_re_trans = transpose(rx_bin_re);
        rx_bin_im_trans = transpose(rx_bin_im);
        
        if(sum(abs(rx_bin_re_trans(:)-nq_re_bin(:)))==0 && ...
           sum(abs(rx_bin_im_trans(:)-nq_im_bin(:)))==0)
            disp('NQ samples codifed correctly');
        else
            error('NQ samples codifed with error');
        end
    end
    
end


