% save_cplx_signal save a complex signal in two files
%
% usage: 
% signal_cplx=save_cplx_signal(signal,signal_real_filename,signal_imag_filename,type)
%
% signal is the complex signal
% signal_filename_prefix is the prefix of filename. The final filename is
% signal_filename_prefix+'_real.dat' and signal_filename_prefix+'_imag.dat'
% type is 'float' or 'double'. The precision of signal to save.
%
function save_cplx_signal(signal,signal_real_filename,signal_imag_filename,type)

file_output_name_bin_real   = signal_real_filename;
file_output_name_bin_imag   = signal_imag_filename;

fp_real=fopen(file_output_name_bin_real,'wb');
fp_imag=fopen(file_output_name_bin_imag,'wb');

if((-1==fp_real))
    error(sprintf('unable to open %s',file_output_name_bin_real))
elseif((-1==fp_imag))
    error(sprintf('unable to open %s',file_output_name_bin_imag))
else
    fwrite(fp_real,real(signal),type);
    fwrite(fp_imag,imag(signal),type);
    fclose(fp_real);
    fclose(fp_imag);
end
end