% TODO: modify this comment with more information
% This script gets the 60b words from words with 32b
function [words60b_bin,words60b_hex]=pusqh_get60b_from_pkt_words(words_of_32b)
    
    words_of_32b_bin = decimalToBinaryVector(words_of_32b(:));
    
    words_30b_bin = words_of_32b_bin(:,[1:15 17:31]);

    words60b_bin = [words_30b_bin(1:2:end,:) words_30b_bin(2:2:end,:)];
        
    words60b_hex = binaryVectorToHex(words60b_bin);
    
end
