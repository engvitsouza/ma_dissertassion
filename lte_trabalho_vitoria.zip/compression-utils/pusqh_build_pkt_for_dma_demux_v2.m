% This function creates a pusqh pkt for ROE plataform
% Each packet is composed of words of 60 bits.
% The first P samples has the following information
% see https://www.laps.ufpa.br/redmine/issues/2154 for more details

function [dma_words_32b_dec,dma_words_32b] = pusqh_build_pkt_for_dma_demux_v2(...
    x_nq_fi_re,x_nq_fi_im,indices_encoded_re,indices_encoded_im,...
    is_first_slot_sym)

bitsPerWord = 60;

x_nq_fi_re = x_nq_fi_re(:);
x_nq_fi_im = x_nq_fi_im(:);

if(length(x_nq_fi_re) ~= length(x_nq_fi_im))
    error('The number of non-quantized samples must be the same for Re and Im');
end

ind_re      = 29:44;
ind_im      = 45:60; % 60 is the LSB
words_nq    = zeros(bitsPerWord,length(x_nq_fi_re));
Nwords_nq   = length(x_nq_fi_re);

 % convert binary str to matrix of 1s and 0s
x_nq_bin_re = transpose(x_nq_fi_re.bin - '0');
x_nq_bin_im = transpose(x_nq_fi_im.bin - '0');

words_nq(ind_re,:)= x_nq_bin_re;
words_nq(ind_im,:)= x_nq_bin_im;

% The first word of symbol shuold indicate if this is the init of a slot of
% not
if (is_first_slot_sym)
    words_nq(1:4,1)   = [1 1 1 0];
else
    words_nq(1:4,1)   = [1 1 1 1];
end
% The remaning words with Not quanitzed samples are init with 1 0 0 0
words_nq(1,2:end) = [1];

words_nq_64b = pusqh_60b_to_64b(words_nq);
%% encode indices streams
[tmp1,tmp2,ind_60b_re] = pusqh_add_fields_to_huffman_streams(indices_encoded_re);
[tmp1,tmp2,ind_60b_im] = pusqh_add_fields_to_huffman_streams(indices_encoded_im);

Nwords_re = size(ind_60b_re,2);
Nwords_im = size(ind_60b_im,2);

Nwords_max      = max(Nwords_re,Nwords_im);
Nwords_min      = min(Nwords_re,Nwords_im);
Npadding_words  = Nwords_max - Nwords_min;
padding_words   = zeros(bitsPerWord,Npadding_words);

% Word that must be discarded by dma_demux_v2, the two MSBs are set to 1
padding_words(1:2,:)= 1;

if (Nwords_max > Nwords_re)
    ind_60b_re= [ind_60b_re padding_words];
elseif(Nwords_max > Nwords_im)
    ind_60b_im= [ind_60b_im padding_words];
end
huffman_streams_60b = zeros(bitsPerWord,2*Nwords_max);

huffman_streams_60b(:,1:2:end) = ind_60b_re;
huffman_streams_60b(:,2:2:end) = ind_60b_im;

huffman_streams_64b = pusqh_60b_to_64b(huffman_streams_60b);
%%pack Non quantized and huffman streams

pkt_64b = [words_nq_64b huffman_streams_64b];

dma_words_32b = reshape(pkt_64b(:),32,[]);
dma_words_32b_dec = binaryVectorToDecimal(dma_words_32b.');

%% receiver

rx_words64b = reshape(dma_words_32b(:),64,[]);
rx_words60b = pusqh_64b_to_60b(rx_words64b);
N_rx_words  = size(rx_words60b,2);

for i =1:length(x_nq_fi_re)
    rx_x_nq_re_bin = rx_words60b(ind_re,i);
    rx_x_nq_im_bin = rx_words60b(ind_im,i);
    
    
    if(binaryVectorToDecimal(rx_x_nq_re_bin) ~= ...
       binaryVectorToDecimal(x_nq_bin_re(i)))
        error('Error on packing NQ re');
    end
    
    if(binaryVectorToDecimal(rx_x_nq_im_bin) ~= ...
       binaryVectorToDecimal(x_nq_bin_im(i)))
        error('Error on packing NQ im');
    end
end

cnt_huff_re =1;
cnt_huff_im =1;
for i=Nwords_nq+1:2:N_rx_words-1
    rx_words_huff_re = rx_words60b(:,i);
    rx_words_huff_im = rx_words60b(:,i+1);
    if(rx_words_huff_re(1)==0)
        if(isequal(rx_words_huff_re,ind_60b_re(:,cnt_huff_re)))
            cnt_huff_re = cnt_huff_re +1;
        else
            error('Error on packing Huffman RE streams');
        end
    end
    if(rx_words_huff_im(1)==0)
        if(isequal(rx_words_huff_im,ind_60b_im(:,cnt_huff_im)))
            cnt_huff_im = cnt_huff_im +1;
        else
            error('Error on packing Huffman IM streams');
        end
    end
end
  
    disp('Words packed with success')
end