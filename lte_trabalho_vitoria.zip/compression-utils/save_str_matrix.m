% save_str_matrix takes an  matrix of chars and save each row in a new line
% Usage:
% save_str_matrix(filename,str_matrix)
% filename file name
% str_matrix matrix of chars. 
function save_str_matrix(filename,str_matrix)
    f=fopen(filename,'w');
    [n_rows, n_cols]=size(str_matrix);
    for i=1:n_rows-1
        fprintf(f,'%s\n',str_matrix(i,:));
    end
    fprintf(f,'%s',str_matrix(n_rows,:));
    fclose(f);
end
