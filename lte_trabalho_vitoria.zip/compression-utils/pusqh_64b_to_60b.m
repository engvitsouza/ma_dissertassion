% This function takes words of 64 bits, split each word in 4 words of 16
% bits and then remove the LSBs, creating 4 words of 15 bits.
% These four words are combined in words of 60 bits
function words_60b = pusqh_64b_to_60b(words_64b)
    [sizeOfWord,Nwords]=size(words_64b);
    if(sizeOfWord ~= 64)
        error('Matrix must have 64 lines');
    end
    
    words_16b = reshape(words_64b(:),16,[]);
   
   %Remove LSB
   words_15b = words_16b(1:15,:);
   words_60b = reshape(words_15b(:),60,[]);
end 