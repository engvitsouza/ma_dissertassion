
function [signal_q, i] = quantize_mse(quantizer, signal)

signal_q = zeros(size(signal));
q_sorted = sort(quantizer);

rows = size(signal_q,1);
cols = size(signal_q,2);

% TODO: since qunatizer is sorted from lowest to highest value, there is a
% more efficient way to find the closest.
for i=1:rows
    for j=1:cols
        e_abs = abs(q_sorted - signal(i,j));
        [V,I] = min(e_abs);
        signal_q(i,j) = quantizer(I);
    end
end

end