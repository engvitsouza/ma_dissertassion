function gmean = my_geomean(x,dim)
    if(nargin==1)
        N=length(x);
        dim=1;
    else
        N = size(x,dim);
    end
        tmp_x = x.^(1/N);
        gmean=prod(tmp_x,dim);
end