%quantize_sq(x,xmin,xmax,Nbits) get the dynamic range (xmax-xmin) and split
% it in 2^Nbits quantization levels. The input x is quantized according to
% these quantization levels.
%
% Usage: 
% quantize_sq(x,xmin,xmax,Nbits)
% x input to be quantized
% xmin minimum value of quantizer dynamic range
% xmax maximum value of quantizer dynamic range
% Nbits number of bits used by quantizer
function xq=quantize_sq(x,xmin,xmax,Nbits)
[values_q,delta_x]  = uniform_quantization_levels(xmin,xmax,Nbits);
xq                  = delta_x*round((x-xmin)/delta_x) + xmin;

xq(x>xmax)   = xmax;
xq(x<xmin)   = xmin;
end