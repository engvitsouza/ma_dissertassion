% This function takes words of 60 bits, split each word in 4 words of 15
% bits and then adds a zero at the LSB, forming 4 word of 16 bits.
% These four words are combined in words of 64 bits

function [words_64b] = pusqh_60b_to_64b(words60b)
    [sizeOfWord,Nwords]=size(words60b);
    if(sizeOfWord ~= 60)
        error('Matrix must have 60 lines');
    end
    words15b = reshape(words60b(:),15,[]);
    Nwords_15b = size(words15b,2);
    words16b = [words15b; zeros(1,Nwords_15b)];
    
    words_64b = reshape(words16b(:),64,[]);
end