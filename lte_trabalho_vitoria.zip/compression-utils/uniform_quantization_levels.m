function [xq_values,delta_x]=uniform_quantization_levels(xmin,xmax,Nbits)
% Number of steps
steps       = 2^Nbits;    
% Delta between quantizer outputs
delta_x     = (xmax-xmin)/(steps-1);
% all output values
xq_values   = delta_x*(0:steps-1) + xmin;
end