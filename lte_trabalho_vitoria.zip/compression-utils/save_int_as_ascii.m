% save_as_ascii takes an  matrix of chars and save each row in a new line
% Usage:
% save_str_matrix(filename,str_matrix)
% filename file name
% str_matrix matrix of chars. 
function save_int_as_ascii(filename,integer)
    f=fopen(filename,'w');
    sig = integer(:);
    n_rows= length(sig);
    fprintf(f,'%d\n',sig(1:n_rows-1));
    fprintf(f,'%d',sig(n_rows,:));
    fclose(f);
end
