clear;
addpath('../laps-lte/');
%% config
filepath    ='D:\lapse\svn\Lasse\compression\msvq\msvq_k_and_N_variable\signals\s15\vq6\';
signal      = read_cplx_signal([filepath 'lte_dl_rb100_real.dat'],[filepath 'lte_dl_rb100_imag.dat']);

enb_param.NDLRB         = 100;
enb_param.CyclicPrefix  = 'normal';

ts=read_cplx_signal('.\ts\lte_dl_rb100_real.dat','.\ts\lte_dl_rb100_imag.dat');

ts_max = max([max((real(ts(:)))) max((imag(ts(:))))]);
ts_min = min([min((real(ts(:)))) min(imag(ts(:)))]);

x_i = real(signal);
x_q = imag(signal);

% quantize are specifed in according to training sequence
x_min=ts_min;
x_max=ts_max;

signal_cplx_abs_max = max([ abs(real(signal(:))) ; abs(imag(signal(:)))]);

%Nb= 4:8;
Nb= 1:11;
%% initialization
SNRs_quant  = zeros(length(Nb),1);
SNR_matlab  = zeros(length(Nb),1);
SNR_cplx    = zeros(length(Nb),1);
EVMs_cplx   = zeros(length(Nb),1);
EVMs_xquant = zeros(length(Nb),1);
ent         = zeros(length(Nb),1);
%ent_matlab  = zeros(length(Nb),1);
%comp_bits_all_signal   = zeros(length(Nb),1);

huffman_avglen      = zeros(length(Nb),1);
signal_quant        = zeros(length(signal),length(Nb));
quantizaton_noise   = zeros(size(signal_quant));

lte_tx_grid = lteOFDMDemodulate(enb_param,signal(:));

index=1;
for b=Nb
    %% quantization
    
%    [quant_values,delta_q] = uniform_quantization_levels(x_min,x_max,b);
    
%     ts_i_quant   = quantize_mse(quant_values,real(ts));%quantize_sq (real(ts),x_min,x_max,b);
%     ts_q_quant   = quantize_mse(quant_values,imag(ts));%quantize_sq (imag(ts),x_min,x_max,b);
    [ts_i_quant,ts_i_quant_ind,quant_values_i]   = ak_quantizer2(real(ts),b,x_min,x_max,1);
    [ts_q_quant,ts_i_quant_ind,quant_values_q]   = ak_quantizer2(imag(ts),b,x_min,x_max,1);
    
    if(quant_values_i~=quant_values_q)
        error('The quantization values must be the same, for real and imag parts');
    end
    quant_values = quant_values_i;
    
%     x_i_quant    = quantize_mse(quant_values,x_i);%quantize_sq(x_i,x_min,x_max,b);
%     x_q_quant    = quantize_mse(quant_values,x_q);%quantize_sq(x_q,x_min,x_max,b);
    x_i_quant    = ak_quantizer2(x_i,b,x_min,x_max,1);
    x_q_quant    = ak_quantizer2(x_q,b,x_min,x_max,1);
    
    x_quant      = complex(x_i_quant(:),x_q_quant(:));
    ts_quant     = complex(ts_i_quant(:),ts_q_quant(:));
    
    %x_q_int     = uencode(x/x_abs_max,b);
    %x_q_matlab  = x_abs_max*udecode(x_q_int,b);
    
    % uencode do not round, the quantization simply trunk or rounds the 
    % elements of X to the nearest integers towards minus infinity.
    %signal_cplx_int     = uencode(signal/signal_cplx_abs_max,b);
    %signal_cplx_quant   = signal_cplx_abs_max*udecode(signal_cplx_int,b);
    
    %% calculate EVM
    lte_rx_grid_xquant = lteOFDMDemodulate(enb_param,x_quant(:));
    %lte_rx_grid = lteOFDMDemodulate(enb_param,signal_cplx_quant(:));
    evms_xquant = lte_evm_annexE_36104(lte_rx_grid_xquant,lte_tx_grid);
    %evms        = lte_evm_annexE_36104(lte_rx_grid,lte_tx_grid);
    
    EVMs_xquant(index) = mean(evms_xquant(:))*100;
    %EVMs_cplx(index)   = mean(evms(:))*100;
    
    %disp(['b=' num2str(b) ' EVM= ' num2str(EVMs_cplx(index)) ' EVM_x_quant= ' num2str(EVMs_xquant(index))]);
    disp(['b=' num2str(b) ' EVM_x_quant= ' num2str(EVMs_xquant(index))]);
    %% calculate SNR
    noise       = signal(:)-x_quant(:);
    %noise_cplx  = signal(:) - signal_cplx_quant(:);
    
    SNRs_quant(index)=sum(abs(signal).^2)/sum(abs(noise).^2);
    %SNR_cplx(index)  =sum(abs(signal(:)).^2)/sum(abs(noise_cplx(:)).^2);
    %% calculate entropy
    
    % Optimized quantizer
    [N,C]=hist([ts_i_quant(:); ts_q_quant(:)],quant_values);
    p = N/sum(N);
    
    if 0
        [dict_huffman,avglen_huffman] = huffmandict(C,p);
        % single to avoid numerical errors. Thus, the values are limited to the
        % quantizaton values
        input_of_huffman = ([x_i_quant(:); x_q_quant(:)]);
        
        comp = huffmanenco(input_of_huffman,dict_huffman);
        huffman_avglen(index) = length(comp)/(length(input_of_huffman(:)));
    end
    ent(index) = calc_entropy(p);
    
    %Matlab encoder
%     [N_matlab,C_matlab]=hist([real(signal_cplx_int(:)); imag(signal_cplx_int(:))],[0:(2^b)-1]);
%     p_matlab = N_matlab/sum(N_matlab);
%     %[dict_huffman_matlab,avglen_huffman_matlab] = huffmandict(C_matlab,p_matlab);
%     ent_matlab(index) = calc_entropy(p_matlab);
    
    index=index+1;
end

%% plots config

plot_colors     = ['rgbkymcr'];
plot_markers    = ['o+*sxdv.'];
set(0,'DefaultAxesFontSize', 18);
lineWidth = 2;
MarkerSize = 12;

str_pattern = '%-35s';
%% plots SNRs
if 1
    str_legend=[];
    SNR_quant_dB    = 10*log10(SNRs_quant);
    %SNR_dB_matlab   = 10*log10(SNR_matlab);
    SNR_dB_cplx     = 10*log10(SNR_cplx);
    figure;
    hold on;
    %rate_bits_per_samples = [1:0.5:10];
    %SNR_shannon_bound = 20*log10(2.^(2*rate_bits_per_samples));
    % Shannon bound as shown in 1998_Gray_Quantization, Eq(16).
    Rbps = [1:0.1:10]; % rate Bits per sample
    distortion_by_var = (2.^(2*Rbps));
    SNRdb_shannon_bound = 10*log10(distortion_by_var);
    
    
        
    plot(Rbps,SNRdb_shannon_bound,'--b','LineWidth',lineWidth,'MarkerSize', MarkerSize);
    str_legend=[str_legend; sprintf(str_pattern,['Bound for iid gaussian source'])];
    
    plot(Nb(:),SNR_quant_dB(:),'-^y',ent(:),SNR_quant_dB(:),'-vy','LineWidth',lineWidth,'MarkerSize', MarkerSize);
    str_legend=[str_legend; sprintf(str_pattern,['USQ'])];
    str_legend=[str_legend; sprintf(str_pattern,['USQ+ENT'])];
    
%     plot(Nb(:),SNR_dB_cplx(:),'--^c','LineWidth',lineWidth,'MarkerSize', MarkerSize)
%     plot(ent_matlab(:),SNR_dB_cplx(:),'--vc','LineWidth',lineWidth,'MarkerSize', MarkerSize);
%     str_legend=[str_legend; sprintf(str_pattern,['SQ (matlab quantizer)'])];
%     str_legend=[str_legend; sprintf(str_pattern,['SQ+entropy (matlab quantizer)'])];
    
    load('../compression/msvq/msvq_k_and_N_variable/SNRdB_rate_k0_4.N0_4096.k1_4.N1_2_to_4096.mat');
    plot(bitsPerSample(:),SNR_dB(:),['-' plot_markers(1) plot_colors(1)],'LineWidth',lineWidth,'MarkerSize', MarkerSize);
    str_legend=[str_legend; sprintf(str_pattern,['MSVQ k0=' num2str(4) ' k1=' num2str(4) ])];
    
    load('../compression/msvq/msvq_k_and_N_variable/SNRdB_rate_k0_4.N0_4096.k1_2.N1_2_to_4096.mat');
    plot(bitsPerSample(:),SNR_dB(:),['-' plot_markers(2) plot_colors(2)],'LineWidth',lineWidth,'MarkerSize', MarkerSize);
    str_legend=[str_legend; sprintf(str_pattern,['MSVQ k0=' num2str(4) ' k1=' num2str(2) ])];
    
    %load('../compression/msvq/SNRdB_rate_k0_4.N0_4096.mat');
    load('../compression/msvq/SNRdB_rate_k0_4.N0_65536.mat');
    plot(bitsPerSample(:),SNR_dB(:),['-' plot_markers(3) plot_colors(3)],'LineWidth',lineWidth,'MarkerSize', MarkerSize);
    str_legend=[str_legend; sprintf(str_pattern,['VQ k0=' num2str(4)])];
    
    hold off;
    grid on;
%     xlim([1 11]);
    xlim([0.5 8.5]); set(gca,'xtick',[0:0.5:11]); % x lines
    ylim([0 40]);
    legend(str_legend);
    xlabel('Bits per component sample');
    ylabel('SQNR (dB)');
end

%% plot EVMS
if 1
    str_legend=[];
    figure;
    hold on;
    
    plot(Nb(:),EVMs_xquant(:),'-^y','LineWidth',lineWidth,'MarkerSize', MarkerSize);
    str_legend=[str_legend; sprintf(str_pattern,['USQ'])];
    
    plot(ent(:),EVMs_xquant(:),'-vy','LineWidth',lineWidth,'MarkerSize', MarkerSize);
    str_legend=[str_legend; sprintf(str_pattern,['USQ+ENT'])];
    
    
%     plot(Nb(:),EVMs_cplx(:),'--^c','LineWidth',lineWidth,'MarkerSize', MarkerSize);
%     str_legend=[str_legend; sprintf(str_pattern,['Scalar Quant.'])];
    
%     plot(ent_matlab(:),EVMs_cplx(:),'--vc','LineWidth',lineWidth,'MarkerSize', MarkerSize);
%     str_legend=[str_legend; sprintf(str_pattern,['SQ+entropy'])];
    
    load('../compression/msvq/msvq_k_and_N_variable/EVM_rate_k0_4.N0_4096.k1_4.N1_2_to_4096.mat');
    plot(bitsPerSample(:),EVM_mean(:),['-' plot_markers(1) plot_colors(1)],'LineWidth',lineWidth,'MarkerSize', MarkerSize);
    str_legend=[str_legend; sprintf(str_pattern,['MSVQ k0=' num2str(4) ' k1=' num2str(4) ])];
    
    load('../compression/msvq/msvq_k_and_N_variable/EVM_rate_k0_4.N0_4096.k1_2.N1_2_to_4096.mat');
    plot(bitsPerSample(:),EVM_mean(:),['-' plot_markers(2) plot_colors(2)],'LineWidth',lineWidth,'MarkerSize', MarkerSize);
    str_legend=[str_legend; sprintf(str_pattern,['MSVQ k0=' num2str(4) ' k1=' num2str(2) ])];
    
    load('../compression/msvq/EVM_rate_k0_4.N0_2_to_65536.mat');
    plot(bitsPerSample(:),evms_ave_per_cent(:),['-' plot_markers(3) plot_colors(3)],'LineWidth',lineWidth,'MarkerSize', MarkerSize);
    str_legend=[str_legend; sprintf(str_pattern,['VQ k=' num2str(4) ])];
    
    legend(str_legend);
    rate_x_axis=16;
    line_QPSK =17.5*ones(rate_x_axis,1);
    line_16QAM=12.5*ones(rate_x_axis,1);
    line_64QAM=8*ones(rate_x_axis,1);
    x_tmp = 0:rate_x_axis-1;
    plot(   x_tmp,line_QPSK,'--r',...
        x_tmp,line_16QAM,'--m',...
        x_tmp,line_64QAM,'--b','LineWidth',lineWidth+1);
    
    text(6,8.5,'\color{blue}max EVM for 64QAM','FontSize',18);
    text(6,13,'\color{magenta}max EVM for 16QAM','FontSize',18);
    
    hold off;
    grid on;
    xlabel('Bits per component sample');
    ylabel('Average EVM(%)');
    ylim([0 15]); set(gca,'ytick',[0:1:15]); % y lines
    xlim([0.5 8.5]); set(gca,'xtick',[0:0.5:11]); % x lines
    hold off;
end
%% plot noises
if 0
    figure;
    plot(real(noise));
    title('real(noise) of optimum scalar quantization');
    
    figure;
    plot(real(noise_cplx));
    title('real(noise) of matlab encoder');
    
    Energy_noise_cplx   = sum(abs(noise_cplx).^2);
    Energy_noise_cplx_without_mean =sum(abs(noise_cplx-mean(noise_cplx)).^2);
    Energy_noise_opt_sq = sum(abs(noise).^2);
    disp(sprintf('Matlab encoder energy noise: %f',Energy_noise_cplx));
    disp(sprintf('Matlab encoder energy noise without *DC*: %f',Energy_noise_cplx_without_mean));
    disp(sprintf('Matlab encoder energy noise: %f',Energy_noise_opt_sq));
end