% save_signal saves a real signal in a file
%
% usage: 
% save_signal(signal,signal_filename,type)
%
% signal is the (real) signal
% signal_filename is the name of file. 
% type is 'float' or 'double'. The precision of signal to save.
%
function save_signal(signal,signal_filename,type)

file_output_name_bin   = signal_filename;

fp=fopen(file_output_name_bin,'wb');

if((-1==fp))
    error(sprintf('unable to open %s',file_output_name_bin))
else
    fwrite(fp,real(signal),type);
    fclose(fp);
end
end