%% parameters xconfigurations
lte_signal = txWaveform;
%lte_signal = x_te_with_cp(length(x_te_with_cp)/2+1:end);
Fs1_MHz = 3.84; 	% original Fs in MHz
Fs2_MHz = 153.6;  	% Fs after upsampling in MHz
Fc_MHz  = Fs2_MHz/4;	%Fs2_MHz/4; % carrier frequency in Mhz
fileName = sprintf('D:\\lapse\\git\\compression\\LTEsignals\\upconverted\\s17_Fs_%fMHz_Fc_%fMHz.txt',Fs2_MHz,Fc_MHz);
fileName_carrier = sprintf('D:\\lapse\\git\\compression\\LTEsignals\\upconverted\\carrier_%4.3fMHz_real.txt',Fc_MHz);

%% Resample, carrier generation and upconversion

% "digital" frequency
Wc = 2*pi*Fc_MHz/Fs2_MHz;

% calculate resample ratio
[n_res, d_res] = rat(Fs2_MHz/Fs1_MHz);

lte_signal_up = resample(lte_signal, n_res, d_res);
carrier = transpose(exp(j*Wc*[0:length(lte_signal_up)-1]));

carrier_real_normalized = max(abs(real(carrier)));
lte_signal_bp_cplx  = lte_signal_up(:).*carrier(:);
lte_signal_bp       = real(lte_signal_bp_cplx);
max_lte_signal_bp   = max(abs(lte_signal_bp))+1e-6;

% lte signal is normalized to range ]-1,1[
lte_signal_normalized = lte_signal_bp/max_lte_signal_bp;
%% create .txt
fid=fopen(fileName,'w');
% create file with signal
fprintf(fid,'%f\n',lte_signal_normalized);
fclose(fid);
% create file with carrier only
% fid=fopen(fileName_carrier,'w');
% fprintf(fid,'%f\n',real(carrier));
% fclose(fid);