% ak_lteADPCM uses ADPCM for quantizing the LTE signal. The first samples of
% signal are not quantized. They are sent to decompression side without
% quantization (or at a high rate quantization). 
% The adaptative part of code is due the gain before (G[n]) and 
% after (1/G[n]) quantization, where:
%
% G[n] = (fs/qlf)/rms(eq[n-1]);
%
% fs is the maximum quantizer's output level
% qlf is the Quantizer loading factor
% eq[n] is the previous quantized prediction error
%
% Usage:
%   [xq,xeq_index,histogram,e_clp]=ak_lteADPCM(x,A,b,fs,qlf)
%
% 'x' is the LTE signal (real or imag part). A matrix where each column is
% OFDM symbol without cyclic prefix.
% 'A' is the predcitor coeffcients. Note that when x is applied to A
% directly, the result is the predction error. x->|A|->e. Also, A(1)=1.
% 'b' is the number of bits used to quantize the predictive error.
% 'fs' is the full scale of quantizer, i. e., the quantizer ranges from 
% [-fs to fs].
% 'qlf' is quantizer loading factor,i. e., the ratio between maximum 
% Quantizer's output level and the quantizer's input signal. Nothe that
% Gain*rms(predictor error) = fs/qlf
% 'fixed_gain' (optional) the gain is fixed and adaptive algorithm is 
% disabled and qlf is ignored. If fixed_gain is a single value the gain 
% in all instants of all  OFDM symbols are the same. If fixed_gain is a 
% vector with the same length as the number of OFDM symbols, each element 
% of fixed_gain is a fixed gain for each OFDM symbol.
%
% return:
% 'xq' is the quantized version of x
% 'xeq_indexes' is the indixes of quantized predictor error of each sample
% 'histogram' is the histogram of xeq_indexes
% 'e_clp' is the error for closed loop prediction
% 'G' is a matrix with all gains, where each collumn are the gains for each
% OFDM symbol.
%
function [xq,xeq_indexes,histogram,e_clp,G]=ak_lteADPCM(x,A,b,fs,qlf,fixed_gain)

if(fs<0)
    error('Full scale fs must be a positive real number.');
end

xmax = fs;
xmin = -xmax;
A=A(:); %make it a colum vector
predictorOrder=length(A)-1;
Apred_flipped=flipud(-A(2:end)); %column vector time-flipped
[numSamplesPerDMTSymbol,numDMTSymbols] = size(x);
xq=zeros(size(x));
xeq_indexes = zeros(size(x));
histogram=zeros(1,2^b);
e_clp = zeros(size(x));
e_vector = zeros(numSamplesPerDMTSymbol,numDMTSymbols);
eq_vector= zeros(numSamplesPerDMTSymbol,numDMTSymbols);
G        = zeros(numSamplesPerDMTSymbol,numDMTSymbols);
%G[P+1] = 1; The first gain is one, before P +1 the gain is not used
G(predictorOrder+1,:) = 1;

for i=1:numDMTSymbols
    %assume the first samples are quantized without error
    %later we will quantize them
    xq(1:predictorOrder,i) = x(1:predictorOrder,i);
    xeq_indexes(1:predictorOrder,i) = -1; % the first samples are not quantized with dpcm
    maxG = Inf;
    for j=predictorOrder+1:numSamplesPerDMTSymbol    
        xp=sum(Apred_flipped.*xq(j-predictorOrder:j-1,i)); %predicted value
        xe=x(j,i)-xp; %closed loop prediction error
        e_clp(j,i) = xe;
        
        % define the gain
        if(nargin >= 6)
            % Check if the fixed_gain is a matrix or a single value
            if(numDMTSymbols==length(fixed_gain))
                % TODO: this steatement may be placed out of the loop to
                % improve performance
                G(j,i) = fixed_gain(i);
            elseif (length(fixed_gain)==1)
                G(j,i) = fixed_gain;
            else
                error('Fixed gain must be a single value or one array with length equals to number of OFDM symbols');
            end
        else
            if(j==predictorOrder+1)
                G(j,i) = 1;
            else
                
                % standard variation of (quantized) error. There is the same
                % error in encoder and decoder. rms was used instead of std
                % because the mean is zero and std of a single value is zero.
                std_eq = rms(eq_vector(predictorOrder+1:j-1,i));
                
                G(j,i) = (fs/qlf)/std_eq;
            end
        end
        xeg = G(j,i)*xe;
        [xeg_q,xeq_index]=ak_quantizer2(xeg,b,xmin,xmax,0); %quantize
        xeq = xeg_q/G(j,i);
        xq(j,i)=xeq+xp; %reconstruct the signal
        xeq_indexes(j,i) = xeq_index; % The bits needed to transmit
        histogram(xeq_index+1) = histogram(xeq_index+1)+1; %update histogram
        
        %Lines for debugging
        e_vector(j,i)= xe;
        eq_vector(j,i) = xeq;
    end
    if(mod(i,140)==0)
        disp(sprintf('sym %d ok',i));
    end
end
%quant_noise = eq_vector - e_vector;
%SQNR = mean(abs(e_vector(:)).^2)/mean(abs(quant_noise(:)).^2);
%disp(sprintf('%d bits | SQNR: %.2f dB',b,10*log10(SQNR)));