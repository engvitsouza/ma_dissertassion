This repository contains the main scripts for simulation of compression based on
`adaptive scaling + LPC + Huffman` in uplink transmissions. The following text
summarizes the steps for running the simulations.

## MATLAB Version and Toolboxes

MATLAB 2015b or newer and LTE system toolbox are required.

## Dependencies

In order to run the scripts contained in this repository you need the
dependencies contained in the following 3 additional repositories:

- compression-utils (http://www.laps.ufpa.br/gitlab/lte-signal-compression/compression-utils.git)
- lapse-lte (http://www.laps.ufpa.br/gitlab/lte/lapse-lte.git)
- lte_dpcm (http://www.laps.ufpa.br/gitlab/lte-signal-compression/lte_dpcm.git)

These three repositories must be cloned at the same level of the folder
that contains this README. Something like the following:

```
matlab/lte-lpc-ul #(the repository of this README)
matlab/compression-utils
matlab/lapse-lte
matlab/lte_dpcm
```

To quickly do this in a single step, run the following script from the 
lte-lpc-ul folder:
```
./set_env
```

## Basic information about Simulations

Please find below a table with the simulations available in this repository.

  | File                    | Simulation                         |
--| ----------------------- |:----------------------------------:|
A | `lpc_ul_comp_2ues.m`    | Compression of uplink with two UEs |
B | `lpc_ul_compression.m`  | Compression of uplink with one UE  |

Change the current folder of MATLAB to lte-lpc-ul and then run 
lpc_ul_comp_2ues.m or lpc_ul_compression.m

### A) More details about the simulation for compression of uplink with two UEs

The training and testing signals are created on `lpc_ul_comp_2ues.m`. You can
changes the parameters of the LTE signals, channel and compression. The
variables are listed below and theirs functions are described on code
`lpc_ul_comp_2ues.m`.

#### A.1) Signal parameters (input):
```
	Nframes
	Nframes_tr
	RC
	ue1_PRBSet
	ue2_PRBSet
	ue1_TrBlkSize
	ue2_TrBlkSize
```

#### A.2) Channel parameters (input):
```
	attdB_ue1
	attdB_ue2
	SNRdB
```

#### A.3) Compression parameters (input):
```
	Nbits
	predictorOrder
	get_qlf_from_training
	quantizer_lf
```

#### A.4) Variables with results (output of simulation):
```
	evms_rms_ue1
	evms_rms_ue2
	evm_rms_ue1_only_ch
	evm_rms_ue2_only_ch
	throughput_ue1
	throughput_ue2
	throughput_ue1_only_ch
	throughput_ue2_only_ch
	snr_geomeans_ue1
	snr_geomeans_ue2
	snr_gm_ue1_only_ch
	snr_gm_ue2_only_ch
	actual_rate_huffman
```

#### A.5) At the end, The simulation diplays something like the following:

```
RBs allocated to UE1: 15
RBs allocated to UE2: 10
Attenuation for UE1: 28.30 dB
Attenuation for UE2: 6.80 dB
SNR in time domain for UE1: 5.00 dB
SNR in time domain for UE2: 24.75 dB
Nbits	bits(IorQ)	UE1-EVM(%)	UE1-SNRg	UE1-Thru(%)	UE2-EVM(%)	UE2-SNRg	UE2-Thru(%)
    6	   4.83   	  42.13% 	   5.66  	      100%	  3.32%  	910.59 	      100%
    7	   5.75   	  40.69% 	   6.10  	      100%	  3.22%  	975.31 	      100%
    8	   6.68   	  40.38% 	   6.24  	      100%	  3.23%  	979.02 	      100%

  Only Channel		  39.80%	   6.34  	      100%	  3.12% 	1031.04	      100%
```

### B) More details about the simulation for compression of uplink with one UE

The training and testing signals for simulation with sngle UE are created on 
`lpc_ul_compression.m`. You can change the parameters of the LTE signals, 
channel and compression. The variables are listed below and theirs functions are
 described on code `lpc_ul_compression.m`.

#### B.1) Signal parameters (input):
```
	Nframes_tr
	Nframes_te
	frc_name
	Nrb
	frc_nrbs
```

#### B.2) Channel parameters (input):
```
	SNRdB
	attdB
```

#### B.3) Compression parameters (input):
```
	Nbits
	predictorOrder
	enable_asymptotic_gain
	get_qlf_from_training
	quantizer_lf
```

#### B.4) Variables with results (output of simulation)**:
```
	evms_rms
	evm_rms_nocomp
	throughput
	throughput_nocomp
	SNR_geomeans
	SNR_gm_fd_only_ch
	actual_rate_huffman
```

#### B.5) At the end, The simulation diplays something like the following:
```
Number of allocated RBs: 25
Channel Attenuation: 31.30 dB
SNR in time domain: 5.00 dB
Nbits	bits(IorQ)	EVM RMS(%)	SNRg	Throughput(%)
   6	   4.83   	  58.21%  	2.96 	       90%
   7	   5.76   	  53.50%  	3.51 	      100%

  Only Channel		  52.79%  	3.60 	      100%
```
