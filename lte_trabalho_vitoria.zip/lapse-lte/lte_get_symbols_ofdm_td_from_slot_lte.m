% LTE_GET_SYMBOLS_OFDM_TD_FROM_SLOT_LTE returns the ofdm symbols from a 
% lte slot
%
% usage:
% [ofdm_symbols_td] = lte_get_symbols_ofdm_td_from_slot_lte(slot,Nrb,cp_type)
%
% SLOT a slot lte
% NRB Number of resource block in this lte signal
% CP_TYPE Type of cyclic prefix applied: 'Normal' or 'Extended'
%
function [ofdm_symbols_td] = lte_get_symbols_ofdm_td_from_slot_lte(slot,Nrb,cp_type)

enb = lte_DLPHYparam(Nrb,cp_type);

% Number of points in a OFDM symbol
FFT_size = enb.FFT_size;

% Number of OFDM symbol per slot
N_dl_symb = enb.N_dl_symb;

N_cp_l_0    = enb.cp_0_length;
N_cp_l_else = enb.cp_else_length;

ofdm_symbols_td = zeros(FFT_size,N_dl_symb);
for symb= 0:N_dl_symb-1
    if(0==symb)
        from_sample = N_cp_l_0+1;
        to_sample   = N_cp_l_0+FFT_size;
    else
        from_sample =   (N_cp_l_0+FFT_size)+(symb-1)*(FFT_size+N_cp_l_else)+N_cp_l_else+1;
        to_sample   =   (N_cp_l_0+FFT_size)+(symb)*(FFT_size+N_cp_l_else);
    end
    ofdm_symbols_td(:,symb+1) = slot(from_sample:to_sample);
end
end