%
% lte_plotOFDMSymbols receives a lte signal in time domain and plot the OFDM
% symbol of one slot.
%
% lte_plotOFDMSymbols(lteSignal_td,Nrb,cyclicPrefixType,frame,slot)
%
% LTESIGNAL_TD is the complex lte signal in time domain with a number of frame
% greater or equals than specified by FRAME.
% NRB is the number of resource blocks used by enb.
% FRAME is the frame to display.
% CYCLICPREFIXTYPE is 'Normal' or 'Extended'. it is not case sensitive.
% FRAME is the frame of interest.
% SLOT is the slot to display within the frame specified. It is a number
% between  0-19
%
% Author: Leonardo Ramalho
%
function lte_plotOFDMSymbols(lteSignal_td,Nrb,cyclicPrefixType,frame,slot)
lte_signal=lteSignal_td;
%% config parameters
enb     = lte_DLPHYparam(Nrb,cyclicPrefixType);

N_rb_dl     = Nrb; % number of resource block per slot
N_sc_rb     = 12;

% select the frame and slot to be displayed
frame_number=frame;
slot_number=slot;
%% precomputation

N_sc_ofdm   = enb.Nsc;
N_dl_symb   = enb.N_dl_symb;
N_cp_l_0    = enb.cp_0_length;
N_cp_l_else = enb.cp_else_length;
FFT_size    = enb.FFT_size;

Nsamples_per_frame= enb.samplesPerFrame;

%% prepare signal to plot
frame_lte_td=lte_get_frame_lte_td(lte_signal,Nsamples_per_frame,frame_number);
x_slot=lte_get_slot_ofdma_td_from_frame_lte(frame_lte_td,slot_number,N_cp_l_0,N_cp_l_else,N_dl_symb,FFT_size);
ofdm_symbols_td=zeros(FFT_size,N_dl_symb);  % ofdm symbols in time domain
ofdm_symbols_fd=zeros(FFT_size,N_dl_symb);  % ofdm symbols in freq domain

for i=0:N_dl_symb-1
    symb_ofdm_td=lte_get_symb_ofdm_td_from_slot_lte(x_slot,i,N_cp_l_0,N_cp_l_else,FFT_size); %time domain
    ofdm_symbols_td(:,i+1)=symb_ofdm_td;
end

bin_fd=-(FFT_size/2):(FFT_size/2)-1; %bin freq domain, used after fftshift
ofdm_symbols_fd=fft(ofdm_symbols_td);
abs_ofdm_symbols_fd= abs(ofdm_symbols_fd);
%% plots
%plot
set(0,'DefaultAxesFontSize', 14);
figure(101);
for i=0:N_dl_symb-1
    %subplot(2,2,mod(i,4)+1);
    subplot(2,4,i+1);
    plot(real(ofdm_symbols_fd(:,i+1)),imag(ofdm_symbols_fd(:,i+1)),'o');
    max_y=max(abs(imag(ofdm_symbols_fd(:,i+1))));
    %ylim([-1 1]);
    if(max_y<1e-6)
        ylim([-0.5 0.5]); % this command avoid strange behaviour of constellation plot
    end
    %ylim([-1 1]);xlim([-1 1]);
    title(sprintf('OFDM symbol %d, slot %d',i,slot_number));
end

figure(102);
for i=0:N_dl_symb-1
    %subplot(2,2,mod(i,4)+1);
    subplot(N_dl_symb,1,i+1);
    stem(bin_fd,abs(fftshift(ofdm_symbols_fd(:,i+1))),'-x');
    ylabel(sprintf('OFDM %d',i));
    %ylim([0 1]);
    xlim([-(N_sc_ofdm/2+10) (N_sc_ofdm/2+10)]);
end

abs_fftshift_ofdm_symbols_fd=zeros(size(abs_ofdm_symbols_fd));
for i=0:N_dl_symb-1
    abs_fftshift_ofdm_symbols_fd(:,i+1)=fftshift(abs_ofdm_symbols_fd(:,i+1));
end

%y_axes=[-(N_sc_ofdm/2+10):(N_sc_ofdm/2+10)];
y_axes=-50:50;
ofdm_symbols=0:6;
figure(103);
bar3(y_axes,(abs_fftshift_ofdm_symbols_fd(FFT_size/2+y_axes+1,:)));
xlabel('ofdm symbol');
ylabel('bin');

if 1 %each line is a frequency and each collumn is a OFDM symbol
figure(104);

subFrameNumber = fix(slot_number/2);
slotInSubFrame = mod(slot_number,2);
title(sprintf('Frame: %d | Slot %d (SubFrame %d | Slot %d)',...
    frame_number,slot_number,subFrameNumber,slotInSubFrame));


    image(y_axes,ofdm_symbols,(abs_fftshift_ofdm_symbols_fd(FFT_size/2+y_axes+1,:).'),'CDataMapping','scaled');
    xlabel('Frequency bin');
    ylabel('OFDM symbol');

    %------------------------------------------------------------------------
    %drawing grid pixel from (with some modifications):
    %http://blogs.mathworks.com/steve/2011/02/17/pixel-grid/
    h = findobj(gcf,'type','image');
    xdata = get(h, 'XData');
    ydata = get(h, 'YData');
    M = size(get(h,'CData'), 1);
    N = size(get(h,'CData'), 2);
    
    pixel_height=1;
    pixel_width = 1;
    
    y_top = ydata(1) - (pixel_height(1)/2);
    y_bottom = ydata(end) + (pixel_height(1)/2);
    y = linspace(y_top, y_bottom, M+1);
    x_left = xdata(1) - (pixel_width(1)/2);
    x_right = xdata(end) + (pixel_width(1)/2);
    xx = linspace(x_left, x_right, N+1);
    
    xv = zeros(1, 2*numel(xx));
    xv(1:2:end) = xx;
    xv(2:2:end) = xx;
    
    yv = repmat([y(1) ; y(end)], 1, numel(xx));
    yv(:,2:2:end) = flipud(yv(:,2:2:end));
    
    xv = xv(:);
    yv = yv(:);
    
    lineWidth=0.025;
    
    line ='-k';
    
    hold on
    plot(xv, yv, line, 'LineWidth', lineWidth, 'Clipping', 'off')
    hold off
    
    yh = zeros(1, 2*numel(y));
    yh(1:2:end) = y;
    yh(2:2:end) = y;
    
    xh = repmat([xx(1) ; xx(end)], 1, numel(y));
    xh(:,2:2:end) = flipud(xh(:,2:2:end));
    
    xh = xh(:);
    yh = yh(:);
    
    hold on
    plot(xh, yh, line, 'LineWidth', lineWidth, 'Clipping', 'off')
    hold off
    colorbar;
end % end figure(104)

if 0
    figure(105);
    bins_fd                     = 1+enb.FFT_size/2 +[-Nrb*12/2:-1 1:Nrb*12/2];
    freq_shifted_abs_ofdm_syms  = abs(ofdm_symbols_fd);
    %xStep = 0:((14*10)-1);
    yStep = 0:(Nrb*12-1);
    xStep = 0:((N_dl_symb)-1);
    %yStep = 0:(FFT_size-1);
    surface(xStep,yStep,(abs_fftshift_ofdm_symbols_fd(bins_fd,:)));
    %axis([0 (14*10) 0 (Nrb*12-1) 0 1]);
    axis([0 (N_dl_symb) 0 (Nrb*12-1) 0 1]);
    view([0,90]);
    set(gca,'xtick',[0:N_dl_symb-1]);
    set(gca,'ytick',[[0:12:Nrb*12-1] [Nrb*12-1]]);
    colorbar;
end % end figure(105)

end