% This code is a modified version of the code in link below:
% http://www.mathworks.com/help/lte/examples/pusch-throughput-conformance-test.html
clear; close all;
%% config
NFrames = 1;    % Number of frames to simulate
SNRdB=10;       % SNR of received signal on antenna

file_output_name    = sprintf('lte_ul_snrdb%d_input',SNRdB);
file_bin_path       = 'D:\LAPS_LASSE\svn\Lasse\compression\msvq\uplink\cb_usage_10dB\';

save_signal_in_a_file = 0;

file_output_name_mat        = [file_bin_path file_output_name];
file_output_name_bin_real   = [file_bin_path file_output_name '_real.dat'];
file_output_name_bin_imag   = [file_bin_path file_output_name '_imag.dat'];
%% UE configuration and Uplink RMC Configuration
ue.TotSubframes    = 1; % Total number of subframes to generate a waveform for
ue.NCellID = 10;     % Cell identity
ue.RC = 'A3-2';      % FRC number

% Generate FRC configuration structure for A3-2
frc = lteRMCUL(ue);
rvSeq = frc.PUSCH.RVSeq;

% Transport block sizes for each subframe within a frame
trBlkSizes = frc.PUSCH.TrBlkSizes;
codedTrBlkSizes = frc.PUSCH.CodedTrBlkSizes;

%channel bandwidth options
lte_param.bw=[1.4 3 5 10 15 20];
lte_param.samples_per_slot = [960 1920 3840 7680 11520 15360];
lte_param.Nrb=[6 15 25 50 75 100];

%% Propagation Channel Model Configuration
chcfg.NRxAnts = 1;               % Number of receive antenna
chcfg.DelayProfile = 'EPA';      % Delay profile
chcfg.DopplerFreq = 5.0;         % Doppler frequency
chcfg.MIMOCorrelation = 'Low';   % MIMO correlation
chcfg.Seed = 100;                % Channel seed
chcfg.NTerms = 16;               % Oscillators used in fading model
chcfg.ModelType = 'GMEDS';       % Rayleigh fading model type
chcfg.InitPhase = 'Random';      % Random initial phases
chcfg.NormalizePathGains = 'On'; % Normalize delay profile power
chcfg.NormalizeTxAnts = 'On';    % Normalize for transmit antennas

% Set Propagation Channel Model Sampling Rate
info = lteSCFDMAInfo(frc);
chcfg.SamplingRate = info.SamplingRate;

%% Channel Estimator Configuration
cec.FreqWindow = 13;              % Frequency averaging windows in REs
cec.TimeWindow = 1;               % Time averaging windows in REs
cec.InterpType = 'cubic';         % Interpolation type
cec.PilotAverage = 'UserDefined'; % Type of pilot averaging
cec.Reference = 'Antennas';       % Reference for channel estimation

%% Setup HARQ Processes
% Generate HARQ process table
noHarqProcesses = 8;
harqTable = mod(0:noHarqProcesses-1, noHarqProcesses)+1;

%% Processing Loop

% Initialize variables used in the simulation and analysis
totalBLKCRC = zeros(1, NFrames*10);   % Total block CRC vector
bitThroughput = zeros(1, NFrames*10); % Total throughput vector
resultIndex = 1;        % Initialize frame counter index

% Calculate required AWGN channel noise
SNR = 10^(SNRdB/20);
N = 1/(SNR*sqrt(double(info.Nfft)))/sqrt(2.0);

% With rng the random functions rand, randi, and randn produce
% a predictable sequence of numbers.
%rng('default');

% Store results for every subframe at SNR point
bitTp = zeros(1, NFrames*10);  % Intermediate bit throughput vector
blkCRC = zeros(1, NFrames*10); % Intermediate block CRC vector

% Initialize state of all HARQ processes
for i = 1:8
    harqProc(i) = hPUSCHNewHARQProcess( ...
        trBlkSizes(i), codedTrBlkSizes(i), rvSeq); %#ok
end

% TODO: initialize vector with the right size in rodr to improve performance
txFullSignal = [];
rxQamSymbols_all =[];
txQamSymbols_all = [];
txAllSubframes = [];
rxAllSubframes = [];

% TODO: transmitter and receiver in different loops
offsetused = 0;
for subframeNo = 0:(NFrames*10-1) % each frame has 10 subframes
    
    %% transmitter
    
    % Update subframe number
    frc.NSubframe = subframeNo;
    
    % Get HARQ index for given subframe from HARQ index table
    harqIdx = harqTable(mod(subframeNo, length(harqTable))+1);
    
    % Update current HARQ process
    harqProc(harqIdx)   = hPUSCHHARQScheduling(harqProc(harqIdx));
    frc.PUSCH.RV        = harqProc(harqIdx).rvSeq(harqProc(harqIdx).rvIdx);
    frc.PUSCH.RVSeq     = harqProc(harqIdx).rvSeq(harqProc(harqIdx).rvIdx);
    
    % Create an SC-FDMA modulated waveform
    [txWaveform,txGrid, txSubframe] = lteRMCULTool( ...
        frc, harqProc(harqIdx).ulschTransportBlk);
    samples_per_subframe=length(txWaveform);
    
    % preallocate vector in first ieration
    if(isempty(txAllSubframes))
        disp('aaa');
        % each column is a subframe
        txAllSubframes = zeros(samples_per_subframe,NFrames*10);
    end
    txAllSubframes(:,subframeNo+1) = txWaveform;
end
max_sample_offset = 60;
rxAllSubframes = zeros(samples_per_subframe+max_sample_offset,NFrames*10);
%% channel
%TODO: The channel must be simulated for each frame separetely?

% Transmit an additional 25 samples at the end of the waveform to
% cover the range of delays expected from the channel modeling
%txFullSignal = [txAllSubframes(:,subframeNo+1);];
txFullSignal = txAllSubframes(:);
txFullSignal = [txFullSignal; zeros(max_sample_offset, 1)];

% The initialization time for channel modeling is set each subframe
% to simulate a continuously varying channel.
% Each subframe has 1 ms (1/1000 s)
%chcfg.InitTime = subframeNo/1000;
chcfg.InitTime=0;

% Pass data through channel model
% channel_info contains information regarding the channel modeling
% 
% For example channel_info.PathSampleDelays informs the delay in samples,
% to find the delay in nanoseconds do the following: 
% 1e9*channel_info.PathSampleDelays/chcfg.SamplingRate
% This value is compitable with tables B.2-1-2(EPA),B.2-1-3(EVA) and 
% B.2-1-4(ETU) as specifed in 3GPP 36.101 Annex B
[rxFullSignal,channel_info] = lteFadingChannel(chcfg, txFullSignal);

% Add noise at the receiver
v = N*complex(randn(size(rxFullSignal)), randn(size(rxFullSignal)));
%v =0;
rxFullSignal = rxFullSignal+v;
%rxAllSubframes(:,subframeNo+1) = rxFullSignal;

%% save signals
if (1==save_signal_in_a_file)
    save(file_output_name_mat);
    fp_real=fopen(file_output_name_bin_real,'wb');
    fp_imag=fopen(file_output_name_bin_imag,'wb');
    fwrite(fp_real,real(rxFullSignal),'float');
    fwrite(fp_imag,imag(rxFullSignal),'float');
    fclose(fp_real);
    fclose(fp_imag);
end