%lte_evm calculates the error vector magnitude accordingly to Annex E of
% 3GPP TS 36.104
% usage
% lte_evm_annexE_36104(RX_EQ,TX) returns the EVM for each resourse block 
% in 1 subframe.
% RX_EQ is the received QAM symbol (post equalization) for each OFDM symbol
% TX is the ideal transmitted signal QAM symbol for each OFDM symbol
% Each row in TX and RX_EQ is a subcarrier and each collumn is an OFDM.
% symbol. Note that the number of Subcarrier is 72, 180, 300, 600, 900 and
% 1200, for 1.4 MHz, 3 MHz, 5 MHz, 10 MHz, 15 MHz and 20 MHz, respectively.
% CP_type is optional: 'normal' (default) or 'extended'
%
% evms is numerical value. To find evm in %, just multiply evms by 100.
function evms=lte_evm_annexE_36104(rx_eq,tx,cp_type)
    [m n]       = size(tx);
    [m_rx n_rx] = size(rx_eq);
    if(m~=m_rx | n~=n_rx)
        error('tx and rx grids must have the same size');
    end
    
    if (nargin>2)
        % Number of OFDM symbols per subframe: 12 or 14
        if(strcmpi(cp_type,'normal'))
            N_symb = 14;
        elseif(strcmpi(cp_type,'extended'))
            N_symb = 12;
        else
            error('Select a valid cp type: normal or extended');
        end
    else
        N_symb =14;
    end
    
    rows = m/12;
    cols = n/N_symb;
    % one EVM per resource block per subframe:
    % 1 resource block has 12 subcarriers and 1 subframe has 14 or 12 OFDM 
    % symbols 
    evms = zeros(rows,cols);
    if 1
        evm_col=1;
        for j=1:N_symb:n
            evm_row=1;
            for i=1:12:m
                
                % calculates the indices of resource elements in each 
                % subframe
                ind_rows = i+[0:11];
                ind_cols = j+[0:N_symb-1];
                
                % get subframe by subframe
                sf_tx   = tx(ind_rows,ind_cols);
                sf_rx   = rx_eq(ind_rows,ind_cols);
                
                if 1
                    % If this is actived, some REs are desconsidered, the
                    % REs where TX RE is not used.
                    % find(sf_tx>1e-7) instead of find(sf_tx==0), beacause
                    % the FFT can create some numerical errors
                    ind_of_res_not_used         = find(abs(sf_tx)<1e-7);
                    sf_rx(ind_of_res_not_used)  = 0;
                end
                
                den     = sum(abs(sf_tx(:)).^2);
                num     = sum(abs(sf_rx(:)-sf_tx(:)).^2);
                
                evms(evm_row,evm_col)=sqrt(num/den);
                evm_row=evm_row+1;
            end
            evm_col=evm_col+1;
        end
    else
        sf_tx = tx(1:12,1:N_symb);
        sf_rx = rx_eq(1:12,1:N_symb);
        den     = sum(abs(sf_tx(:)).^2);
        num     = sum(abs(sf_rx(:)-sf_tx(:)).^2);
        sf_evm  = sqrt(num/den);
        evms    = sf_evm;
    end
end