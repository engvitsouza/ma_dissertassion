close all; clear;
%% Load Files

% .mat with original signal (Before and after channel)
load('.\uplink\cb_usage\lte_ul_snrdb20_input');

% File path of signals after VQ
filePath = '.\uplink\cb_usage\';

%load('.\uplink\cb_usage_10dB\lte_ul_snrdb10_input');
%filePath = '.\uplink\cb_usage_10dB\';
useMSVQ =1;
if(1==useMSVQ) % 1-> rxFullSignal is a quantized version of signal rx signal
    Nstages = 4;
    cb_size = 2^8;
    cb_dim  = 6;
    rxFullSignal = ...
        load_msvq_output([filePath 'output_i'],[filePath 'output_q'],Nstages,cb_size,cb_dim);
end
%% receiver
offsetused=0;
noiseEstPerSubFrame = zeros(NFrames*10,1);
for subframeNo = 0:(NFrames*10-1) % each frame has 10 subframes
    
    % Update subframe number
    frc.NSubframe = subframeNo;
    
    % Get HARQ index for given subframe from HARQ index table
    harqIdx = harqTable(mod(subframeNo, length(harqTable))+1);
    
    % Update current HARQ process
    harqProc(harqIdx)   = hPUSCHHARQScheduling(harqProc(harqIdx));
    frc.PUSCH.RV        = harqProc(harqIdx).rvSeq(harqProc(harqIdx).rvIdx);
    frc.PUSCH.RVSeq     = harqProc(harqIdx).rvSeq(harqProc(harqIdx).rvIdx);
    
    %disp(offsetused)
    samples_ind =   (subframeNo*samples_per_subframe)+1:...
        ((subframeNo+1)*samples_per_subframe)+max_sample_offset;
    rxWaveform =   rxFullSignal (samples_ind);
    %rxWaveform =   rxFullSignal;
    %rxWaveform = rxAllSubframes(:,subframeNo+1);
    % Calculate synchronization offset
    offset = lteULFrameOffset(frc, frc.PUSCH, rxWaveform);
    if (offset < max_sample_offset)
        offsetused = offset;
    end
    
    %disp(sprintf('offset: %d | offset_used: %d',offset,offsetused));
    
    % SC-FDMA demodulation
    rxSubframe = lteSCFDMADemodulate(frc, ...
        rxWaveform(1+offsetused:end, :));
    
    % Channel and noise power spectral density estimation
    [estChannelGrid, noiseEst] = lteULChannelEstimate(frc, ...
        frc.PUSCH, cec, rxSubframe);
    
    noiseEstPerSubFrame(subframeNo+1) = noiseEst;
    %disp(sprintf('Est. of PSD noise in subFrame %d: %f',subframeNo,noiseEst));
    
    % Extract resource elements (REs) corresponding to the PUSCH from
    % the given subframe across all receive antennas and channel
    % estimates
    puschIndices = ltePUSCHIndices(frc, frc.PUSCH);
    
    [rxSymbols csi]= lteEqualizeZF(rxSubframe,estChannelGrid);
    
    
    %     [puschRx, puschEstCh] = lteExtractResources( ...
    %         puschIndices, rxSubframe, estChannelGrid);
    %
    %     % MMSE equalization
    %     rxSymbols = lteEqualizeMMSE(puschRx, puschEstCh, noiseEst);
    
    % Update frc.PUSCH to carry complete information of the UL-SCH
    % coding configuration
    %frc.PUSCH = lteULSCHInfo(frc, ...
    %    frc.PUSCH, harqProc(harqIdx).trBlkSize, 'chsconcat');
    tmp_pusch = lteULSCHInfo(frc,frc.PUSCH, harqProc(harqIdx).trBlkSize, 'chsconcat');
    
    % Decode the PUSCH
    [rxEncodedBits rxQamSymbols]= ltePUSCHDecode(frc, tmp_pusch, rxSymbols(puschIndices));
    
    rxQamSymbols_all = [rxQamSymbols_all; rxQamSymbols];
    
    % For plotting issues, Decode the TX PUSCH
    [txEncodedBits txQamSymbols]= ltePUSCHDecode(frc, tmp_pusch, txGrid(puschIndices));
    txQamSymbols_all = [txQamSymbols_all; txQamSymbols];
    
    %txQamSymbols_all = [txQamSymbols_all; txQamSymbols];
    
    % Decode the UL-SCH channel and store the block CRC error for given
    % HARQ process harqIdx
    trBlkSize = trBlkSizes(mod(subframeNo, 10)+1);
    [rxDecodedBits, harqProc(harqIdx).crc, ...
        harqProc(harqIdx).decState] = lteULSCHDecode(...
        frc, tmp_pusch, trBlkSize, ...
        rxEncodedBits, harqProc(harqIdx).decState);
    
    % Store the CRC calculation and total number of bits per subframe
    % successfully decoded
    blkCRC(subframeNo+1) = harqProc(harqIdx).crc;
    bitTp(subframeNo+1) = ...
        harqProc(harqIdx).trBlkSize.*(1-harqProc(harqIdx).crc);
end

% Record the block CRC error and bit throughput for the total number of
% frames simulated at a particular SNR
totalBLKCRC(resultIndex, :) = blkCRC;
bitThroughput(resultIndex, :) = bitTp;
resultIndex = resultIndex + 1;

%% prints
if(1==useMSVQ)
    bitsPerSample=log2(cb_size*Nstages)/cb_dim;
    disp(sprintf('Rate: %f bits per samples',bitsPerSample));
end
disp(sprintf('Mean of noise PSDs: %f',mean(noiseEstPerSubFrame)));
%% plots
set(0,'DefaultAxesFontSize', 16);
if(1)
    figure(101);
    plot(rxQamSymbols_all,'o');
    hold on;
    plot(txQamSymbols_all,'r+','linewidth',2,'markersize',20);
    
    if(1==useMSVQ)
        title_str = sprintf('MSVQ (%.2f bits per sample) of a signal with SNR= %.2f dB',bitsPerSample,SNRdB);
    else
        title_str = sprintf('Without VQ, SNR= %.2f dB',SNRdB);
    end
    title(title_str);
end
figure(102);
plot([0:10*NFrames-1],noiseEstPerSubFrame);
xlabel('Subframe Number');
title('Noise Estimation (PSD) for each subFrame');

%pause;
%hold off;