%   lte_SNRPerOFDMSymbol calculates the SNR of received LTE signals for a
%   given slot.
% txLteSginal and rxLteSignalis are complex lte signals in time domain with
% a number of frame greater or equals than specified by frame.
%
% Nrb is the number of resource blocks used by enb.
% frame is the frame to display.
% slot is the slot to display within the frame specified. It is a number
% between  0-19
%
% lte_SNRPerOFDMSymbol(txLteSignal,rxLteSignal,Nrb,cyclicPrefix,frame)
% returns ans matrix with SNR, such that each line is a OFDM symbol in a
% slot and each collumn correspond to a slot.
function SNRs=lte_SNRPerOFDMSymbol(txLteSignal,rxLteSignal,Nrb,cyclicPrefix,frame,slot,plotQAMsymbols)

enb         = lte_DLPHYparam(Nrb,cyclicPrefix);
N_dl_symb   = enb.N_dl_symb;
if(nargin<=5)
    % if slot is not given in parameter, The SNR of all the ofdm symbols is
    % calculated, ofdm symbols of 1 slot per time.
    SNRs=zeros(N_dl_symb,20);
    for slot_number=0:19
        SNRs(:,slot_number+1)=lte_SNRPerOFDMSymbol(txLteSignal,rxLteSignal,Nrb,cyclicPrefix,frame,slot_number,0);
    end
else
    SNRs=zeros(N_dl_symb,1);
    
    
    
    Nsamples_per_frame  = enb.samplesPerFrame;
    N_cp_l_0            = enb.cp_0_length;
    N_cp_l_else         = enb.cp_else_length;
    
    FFT_size            = enb.FFT_size;
    
    
    frame_lte_td_tx=lte_get_frame_lte_td(txLteSignal,Nsamples_per_frame,frame);
    frame_lte_td_rx=lte_get_frame_lte_td(rxLteSignal,Nsamples_per_frame,frame);
    
    
    
    
    ofdm_symbols_td_tx=zeros(FFT_size,N_dl_symb);  % ofdm symbols in time domain
    ofdm_symbols_td_rx=zeros(FFT_size,N_dl_symb);  % ofdm symbols in time domain
    
    
    slot_lte_td_tx = lte_get_slot_ofdma_td_from_frame_lte(frame_lte_td_tx,slot,N_cp_l_0,N_cp_l_else,N_dl_symb,FFT_size);
    slot_lte_td_rx = lte_get_slot_ofdma_td_from_frame_lte(frame_lte_td_rx,slot,N_cp_l_0,N_cp_l_else,N_dl_symb,FFT_size);
    
    
    for i=0:N_dl_symb-1
        ofdm_symbols_td_tx(:,i+1) = ...
            lte_get_symb_ofdm_td_from_slot_lte(...
            slot_lte_td_tx,i,N_cp_l_0,N_cp_l_else,FFT_size); %time domain
        
        ofdm_symbols_td_rx(:,i+1) = ...
            lte_get_symb_ofdm_td_from_slot_lte(...
            slot_lte_td_rx,i,N_cp_l_0,N_cp_l_else,FFT_size); %time domain
        
        sym_td_tx   = ofdm_symbols_td_tx(:,i+1);
        sym_td_rx   = ofdm_symbols_td_rx(:,i+1);
        noise       = sym_td_tx - sym_td_rx;
        SNRs(i+1)   = 10*log10(sum(abs(sym_td_rx).^2)/sum(abs(noise).^2));
    end
    %% plots
    if(plotQAMsymbols)
        ofdm_symbols_fd_tx=fft(ofdm_symbols_td_tx);
        ofdm_symbols_fd_rx=fft(ofdm_symbols_td_rx);
        set(0,'DefaultAxesFontSize', 14);
        figure(201);
        for i=0:N_dl_symb-1
            %subplot(2,2,mod(i,4)+1);
            subplot(2,4,i+1);
            plot(real(ofdm_symbols_fd_rx(:,i+1)),...
                imag(ofdm_symbols_fd_rx(:,i+1)),'.r');
            hold on;
            plot(real(ofdm_symbols_fd_tx(:,i+1)),...
                imag(ofdm_symbols_fd_tx(:,i+1)),'+b');
            hold off;
            %ylim([-1 1]);xlim([-1 1]);
            evm=lte_evm(ofdm_symbols_fd_rx(:,i+1),ofdm_symbols_fd_tx(:,i+1));
            title(sprintf('OFDM symbol %d, slot %d\nEVM: %.2f %%',i,slot,evm*100));
        end
        
    end
end
end