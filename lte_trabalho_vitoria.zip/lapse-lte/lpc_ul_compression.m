% This scripts perform compression of uplink signals after the channel.
% UE -> CH -> RRU -> COMP -> DECOMP ->
% The EVM is calculats at DECOMP output.

clear; close all;
addpath('../lapse-lte/');
addpath('../compression-utils/');
addpath('../lte_dpcm/');
%% Simulations configurations

% Number of LTE frames of training sequence
Nframes_tr = 10;

% Number of LTE frames of testing sequence
Nframes_te = 1;

% Set the reference channel for UEs. It is the same for both UEs. See
% Annex A of TS 36.104 for more details of each Reference Channel. 
frc_name    = 'A1-3';
% Number of available resource blocks with the chosen reference channel
Nrb         = 25;
% Number of used resource blocks (lower or equals than Nrb)
frc_nrbs    = 25;
% Cyclic prefix type
cptype      = 'normal';

% Channel parameters
% Time domain SNR related. Thus, the noise power is calculated based on 
% power of attenuated signal.
SNRdB = 5;

% Attenuation of channel
att_dB = 31.3;


% Select if you want to use a LTE model channel or an AWGN flatChannel
% 1- LTE Channel model
% 0- AWGN flat channel�
% TODO: Not totally implemented yet. Set 0 for the time being
useLTEChannelModel = 0;

chcfg.NRxAnts = 1;               % Number of receive antenna
chcfg.DelayProfile = 'EPA';      % Delay profile
chcfg.DopplerFreq = 5.0;         % Doppler frequency    
chcfg.MIMOCorrelation = 'Low';   % MIMO correlation
chcfg.Seed = 100;                % Channel seed    
chcfg.NTerms = 16;               % Oscillators used in fading model
chcfg.ModelType = 'GMEDS';       % Rayleigh fading model type 
chcfg.InitPhase = 'Random';      % Random initial phases
chcfg.NormalizePathGains = 'On'; % Normalize delay profile power
chcfg.NormalizeTxAnts = 'On';    % Normalize for transmit antennas
     

% TODO: This number must be changed every subframe, in order to be a
% continuosly changing channel. as shown in
% http://www.mathworks.com/help/lte/examples/pusch-throughput-conformance-test.html.
% Thus, the lteFadingChannel function must me called for each subframe
chcfg.InitTime = 0;

% Number of bits used on quantizer of compressor
Nbits       = [6:7];

% Predictor oreder in LPC algorithm
predictorOrder=6;

% When enable_asymptotic_gain = 1, all the gains are found and then
enable_asymptotic_gain = 0;

%Quantizer loading factor
% 1 - quantizer loading factor is calculated from training
% 0 - the quantizer loading factor is set by quantizer_lf
get_qlf_from_training = 0;

% When get_qlf_from_training =0, you must provide a quantizer loading
% factor
quantizer_lf = 5;
%%

% training signal
[x_tr_withcp,ul_frc_tr,ul_bits_tr]=lte_ul_frc_signal_generator(Nframes_tr,frc_nrbs,frc_name);

% testing signal
[x_te_withcp,ul_frc_te,ul_bits_te]=lte_ul_frc_signal_generator(Nframes_te,frc_nrbs,frc_name);

if 0
   [x_te_withcp,tmp_grid,ul_frc_te] = lteRMCULTool(frc_name,ul_bits_te,...
       'FDD',10*Nframes_te);
end

info = lteSCFDMAInfo(ul_frc_te);

% x_tr is the training sequence fot training compressor and Huffman
% dictionary
x_tr = lte_ofdm_remove_cp(x_tr_withcp,Nrb,cptype);

x_tr_re = real(x_tr);
x_tr_im = imag(x_tr);

% Testing signal wihtout channel 
x_te = lte_ofdm_remove_cp(x_te_withcp,Nrb,cptype);

x_te_re  = real(x_te);
x_te_im  = imag(x_te);

N_OFDM_syms_tr = size(x_tr,2);

%% Channel and RRU reception

att = 10^(-att_dB/20);
SNR = 10^(SNRdB/10);

if useLTEChannelModel
    
    chcfg.SamplingRate = info.SamplingRate;
    
    %noisePower = 1/(SNR*sqrt(double(info.Nfft)))/sqrt(2.0); 
    
    
    %TODO: add channel attenuation
    % Fading channel
    rxWaveform_ch = lteFadingChannel(chcfg, [x_te_withcp; zeros(100,1)]);
    
    noisePower = sqrt(mean(abs(rxWaveform_ch(:)).^2)/(2*SNR)); 
    
    % additive white gausssian noise
    v = noisePower*complex(randn(size(rxWaveform_ch)), randn(size(rxWaveform_ch)));
    rxWaveform_awgn_ch = rxWaveform_ch + v;
    
    % At reception, find time offset
    offset = lteULFrameOffset(ul_frc_te,ul_frc_te.PUSCH, rxWaveform_awgn_ch);
    
    x_withcp = rxWaveform_awgn_ch(offset+1:offset+length(x_te_withcp));
else
    % Using flat fading channel
    noisePower = (mean(abs(att*x_te_withcp(:)).^2)/SNR); 
    v = sqrt(noisePower/2)*complex(randn(size(x_te_withcp)), randn(size(x_te_withcp)));
    x_withcp = att*x_te_withcp+v;
end

% x is the input of compressor
x        = lte_ofdm_remove_cp(x_withcp,Nrb,cptype);

x_re    = real(x);
x_im    = imag(x);
%% Calculate CRC and EVM for signal without compression
% only channel distortions

[~,finalDrsEVM_only_ch,emissions_only_ch,tmp,crcs_only_ch] =...
    lte_hPUSCHEVM(ul_frc_te,x_withcp(:));
crcs_only_ch_low     = crcs_only_ch(1:2:end);
crcs_only_ch_high    = crcs_only_ch(2:2:end);

% Throughput without compression (only channel)
throughput_only_ch = 100*(1-mean(crcs_only_ch_high(:)));

symbols_only_ch = lte_ul_getQAMSymbols(x_te_withcp,x_withcp,ul_frc_te);
finalEVM_only_ch = lteEVM(symbols_only_ch.rxSymbols(:),symbols_only_ch.txSymbols(:));

% Average SNR per subcarrier without compression (only channel)
SNR_per_sc_only_ch = mean(abs(symbols_only_ch.txSymbols).^2,2)./...
    mean(abs(symbols_only_ch.txSymbols-symbols_only_ch.rxSymbols).^2,2);

% Calculate geometric SNR with channel only (no compression)
SNR_gm_fd_only_ch = my_geomean(SNR_per_sc_only_ch);
%% estimate predictor and quantizer limits
[A,e]       = ak_estimatePredictor([x_tr_re x_tr_im],predictorOrder);
[xmin_dusc,xmax_dusc]=ak_getPredictionErrorDynamicRange([x_tr_re x_tr_im],A);

% Full scale of quantizer, i. e., the range of quantizer is [-fs_adpcm : fs_adpcm]
fs_adpcm = max(abs([xmin_dusc xmax_dusc]));

%% Initialization of Variables
EVMs_per_bit       = {};
drsEVMs_per_bit    = {};
emissions_per_bit  = {};
xq_per_bit         = zeros(length(x_withcp),length(Nbits));
avg_huffman_lengths = zeros(length(Nbits),1);
crcs_per_bit       = {};
SNR_compression_per_bit = zeros(length(Nbits),1);

% Geometric SNR for each number of bits on compression
SNR_geomeans       = zeros(length(Nbits),1);
%% compression
for i =1:length(Nbits)
    number_of_bits  = Nbits(i);
    disp(sprintf('Comprssion for P=%d b=%d...',predictorOrder,number_of_bits));
    %% compression Training
    % Getting indices for training of Huffman dictionary 
    [xq_tr_re_im,xq_tr_ind_re_im,xq_tr_hist_re_im,e_clp_tr_re_im,G_tr] =...
                ak_lteADPCM([x_tr_re x_tr_im],A,number_of_bits,fs_adpcm,10,1);
    
    %% Training of Huffman dictionary
    % Find the probability of quantization levels
    p_levels = xq_tr_hist_re_im/sum(xq_tr_hist_re_im);
    
    % Find the huffman dictionay given the levels and theirs pmf from
    % training sequence
    [dict_dusq,avglen_dusq] = huffmandict([0:2^number_of_bits-1],...
        p_levels);
    
    %% compression of testing seuquences
    if(enable_asymptotic_gain)
        % Find the asympotic gain
        [tmp1_re,tmp2_re,tmp3_re,tmp4_re,asymptotic_gains_re]=...
            ak_lteADPCM([x_re],A,number_of_bits,fs_adpcm,quantizer_lf);
        [tmp1_im,tmp2_im,tmp3_im,tmp4_im,asymptotic_gains_im]=...
            ak_lteADPCM([x_im],A,number_of_bits,fs_adpcm,quantizer_lf);
        
        [xq_te_re,xq_te_ind_re,xq_te_hist_re,e_clp_re,gain_re]=...
            ak_lteADPCM([x_re],A,number_of_bits,fs_adpcm,quantizer_lf,asymptotic_gains_re(end,:));
        [xq_te_im,xq_te_ind_im,xq_te_hist_im,e_clp_im,gain_im]=...
            ak_lteADPCM([x_im],A,number_of_bits,fs_adpcm,quantizer_lf,asymptotic_gains_im(end,:));
        
        
    else
        [xq_te_re,xq_te_ind_re,xq_te_hist_re,e_clp_re,gain_re]=...
            ak_lteADPCM([x_re],A,number_of_bits,fs_adpcm,quantizer_lf);
        [xq_te_im,xq_te_ind_im,xq_te_hist_im,e_clp_im,gain_im]=...
            ak_lteADPCM([x_im],A,number_of_bits,fs_adpcm,quantizer_lf);
    end
            
    if 0
        [xq_dpcm_x_tr_re_im,xq_dpcm_x_tr_ind_re_im,hist_dpcm_x_tr_re_im]=...
            ak_lteDPCM([x_tr_re x_tr_im],A,number_of_bits,xmin_dusc,xmax_dusc);
    end  
    
    %% Average number of bits per IQ component after Huffman coding
    
    [number_of_cws_dusq,nothing] = size(dict_dusq);
    cw_index_dusq   = 0:number_of_cws_dusq-1;
    cws_length      = zeros(number_of_cws_dusq,1);
    for cw_index=1:number_of_cws_dusq
        cws_length(cw_index)  = length(cell2mat(dict_dusq(cw_index,2)));
    end
    
    valid_ind_re = xq_te_ind_re(predictorOrder+1:end,:);
    valid_ind_im = xq_te_ind_im(predictorOrder+1:end,:);
    
    bits_per_sample_x_te_re   = cws_length(valid_ind_re(:)+1);
    bits_per_sample_x_te_im   = cws_length(valid_ind_im(:)+1);
    
    avg_len_huffman =...
        sum([bits_per_sample_x_te_re(:) ; bits_per_sample_x_te_im(:)])/...
        length([valid_ind_re(:) ; valid_ind_im(:)]);
    
    %% insert CP and find EVM and SNR
    
    xq_adpcm = complex(xq_te_re,xq_te_im);
    xq_adpcm_withcp = lte_ul_insert_cp(xq_adpcm,Nrb,cptype);
    
    % Calculates EVM
    [~,finalDrsEVM,emissions,tmp,crcs] = ...
        lte_hPUSCHEVM(ul_frc_te,xq_adpcm_withcp(:));
    
    % Find compression noise and time domain SNR
    compressionNoise = x_withcp(:)-xq_adpcm_withcp(:);
    SNR_compression = mean(abs(x_withcp(:)).^2)/...
        mean(abs(compressionNoise(:)).^2);
    
    symbols = lte_ul_getQAMSymbols(x_te_withcp(:),xq_adpcm_withcp(:),ul_frc_te);
    finalEVM = lteEVM(symbols.rxSymbols(:),symbols.txSymbols(:));
    
    % Average SNR per subcarrier without compression (only channel)
    SNR_per_sc = mean(abs(symbols.txSymbols).^2,2)./...
        mean(abs(symbols.txSymbols-symbols.rxSymbols).^2,2);
    
    % Calculate geometric SNR
    SNR_gm_fd = my_geomean(SNR_per_sc);
    
    
    %% save information for this number of bits
    EVMs_per_bit       = [EVMs_per_bit finalEVM];
    drsEVMs_per_bit    = [drsEVMs_per_bit finalDrsEVM];
    emissions_per_bit  = [emissions_per_bit emissions];
    avg_huffman_lengths(i)= avg_len_huffman;
    xq_per_bit(:,i)    = xq_adpcm_withcp(:);
    crcs_per_bit       = [crcs_per_bit crcs];
    SNR_compression_per_bit(i) = SNR_compression;
    SNR_geomeans(i)     = SNR_gm_fd;
    disp(sprintf('Comprssion for P=%d b=%d done.',predictorOrder,number_of_bits));
end
%% Rates calculaiton

Qs =15;
factor_due_cp = 1.0703125;
enb_param = lte_DLPHYparam(Nrb,'normal');
N=enb_param.FFT_size;
P=predictorOrder;

% Calculate the average number of bits per IQ component after compression
actual_rate_huffman = ((N-P)*avg_huffman_lengths+P*Qs)/(factor_due_cp*N);
%% Suggestion name for saving file
disp(sprintf('aslpc_results_from_%d_to_%d_bits_P%d_%dframes_att%ddB',...
    Nbits(1),Nbits(end),predictorOrder,Nframes_te,round(att_dB)));
%% results
% EVMs after Channel, compression and decompression
evms_rms = [];

% EVM RMS without compression, only channel. 
evm_rms_only_ch = finalEVM_only_ch.RMS*100;
% Throughput after channel, compression and decompression
throughput = zeros(length(Nbits),1);
for i=1:length(Nbits)
    evms_rms    = [evms_rms; 100*EVMs_per_bit{i}.RMS];
    tmp_crc = crcs_per_bit{i};
    
    % hPUSCHEVM calculates two CRCs, one for low edge EVM (more cyclic 
    % prefix is included demodulation) and other for high edge EVM (less 
    % CP is included on demodulation). the CRCs for low edge EVM are placed
    % on odd indexes and high edge EVM are placed on even indexes.
    tmp_crc_low     = tmp_crc(1:2:end);
    tmp_crc_high    = tmp_crc(2:2:end);
    throughput(i)   = 100*(1-mean(tmp_crc_high));
end
%% display
disp(sprintf('Number of allocated RBs: %d',frc_nrbs));
disp(sprintf('Channel Attenuation: %.2f dB',att_dB));
disp(sprintf('SNR in time domain: %.2f dB',SNRdB));
disp(sprintf('Nbits\tbits(IorQ)\tEVM RMS(%%)\tSNRg\tThroughput(%%)'));
disp(sprintf('%4d\t   %.2f   \t  %.2f%%  \t%.2f \t%9d%%\n',...
    transpose([Nbits(:) actual_rate_huffman(:) ...
    evms_rms(:) SNR_geomeans(:) round(throughput(:))])))
disp(sprintf('  Only Channel\t\t  %.2f%%  \t%.2f \t%9d%%\n',...
    finalEVM_only_ch.RMS*100,SNR_gm_fd_only_ch,throughput_only_ch));


%% plots
set(0,'DefaultAxesFontSize', 24);
lineWidth = 2;
MarkerSize = 12;

plot(actual_rate_huffman,evms_rms,'-xg','lineWidth',lineWidth+2,'MarkerSize',MarkerSize+2);
hold on;
ylim([0 10]);
xlim([2 8]);
x_tmp=[0:16];
line_QPSK =17.5*ones(length(x_tmp),1);
line_16QAM=12.5*ones(length(x_tmp),1);
line_64QAM=8*ones(length(x_tmp),1);
plot(x_tmp,line_16QAM,'--m',...
     x_tmp,line_64QAM,'--b','LineWidth',lineWidth);
    
    text(6,8.3,'\color{blue}max EVM for 64QAM','FontSize',18);
    text(6,13,'\color{magenta}max EVM for 16QAM','FontSize',18);
line_nocompression = finalEVM_only_ch.RMS*100*ones(length(x_tmp),1);
plot(x_tmp,line_nocompression,'--r','LineWidth',lineWidth);
text(6,finalEVM_only_ch.RMS*100+0.25,'\color{red}EVM without compression','FontSize',18);
hold off;
ylabel('EVM RMS (%)');
xlabel('Bits per component sample (R)');
title(sprintf('Compression of a uplink LTE signal with SNR: %d dB',SNRdB));