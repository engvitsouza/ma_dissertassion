%%
%
% This file creates lte signals from Reference measurement Channels (RMC),
% defined in Annex A.3 of 3GPP TS36.101.
%
% created in 28/10/2014
% author Leonardo Ramalho
%%
clear;
%% config parameters
rmc_reference = 'R.11';
number_of_frames = 10;

file_bin_path           = 'D:\lapse\git\compression\LTEsignals\str_r11_arb5\';
file_output_name        = 'lte_dl_R11_str_arb_5';

save_signal_in_a_file   = 1;

Ncodewords = 1;

%% 
%channel bandwidth options
lte_param.bw                = [1.4 3 5 10 15 20];
lte_param.samples_per_slot  = [960 1920 3840 7680 11520 15360];
% Number of resource block options
lte_param.Nrb               = [6 15 25 50 75 100];

% The downlink RMC  are defined in Annex A.3 of TS36.101
rmc     = lteRMCDL(rmc_reference); % reference measurement channel
if 0
    rmc.NDLRB           = 100;
    rmc.PDSCH.PRBSet    = [0:(rmc.NDLRB-1)].';
    rmc                 = lteRMCDL(rmc,Ncodewords); % reference measurement channel
end
if 1
    rmc.NCellID = randi([0 503],1);
    rmc         = lteRMCDL(rmc,Ncodewords); % reference measurement channel
end
if 0
    rmc.PDSCH.Modulation = '64QAM';
    rmc     = lteRMCDL(rmc,Ncodewords); % reference measurement channel
end
if 1   
    %Active resource blocks in a subframe (min = 0  max = rmc.NDLRB-1)
    prbset                  = [0:4].';
    
    % Tranport block size indexes from Table 7.1.7.1-1.
    if strcmpi(rmc.PDSCH.Modulation,'QPSK')
        tbsIndexes  = [0:9];
    elseif strcmpi(rmc.PDSCH.Modulation,'16QAM')
        tbsIndexes  = [9:15];
    elseif strcmpi(rmc.PDSCH.Modulation,'64QAM')
        tbsIndexes  = [15:26];
    else
        error('Invalid modulation');
    end
    
    % first find the tranport block size without modifing the RMC.
    % +1 to transfrom in 1 based indexes
    tbsSizes_tmp = lteTBS(length(rmc.PDSCH.PRBSet));
    
    % Sub-Frames 1,2,3,4,6,7,8,9 have the same size according to  Annex A of
    % 36.101
    Itbs_1based = find(tbsSizes_tmp == rmc.PDSCH.TrBlkSizes(2));
    Itbs_0based = Itbs_1based-1;
    
    
    % Number of Active Resource blocks
    NPRBs                   = length(prbset);
    rmc.PDSCH.PRBSet        = prbset;
    
    %TODO: check TBS for 1th (subframe #0) and 6th subframe (subframe #1)
    TrBlkSizes      = repmat(lteTBS(NPRBs,Itbs_0based),1,10);
    IwhereItisZero  = find(rmc.PDSCH.TrBlkSizes == 0);
    TrBlkSizes(IwhereItisZero) = 0;
    rmc.PDSCH.TrBlkSizes = TrBlkSizes;
    
    %TODO: improve calculation of transport block size, according to the
    % physical resource blocks available. 
    %rmc.PDSCH.TrBlkSizes    = rmc.PDSCH.TrBlkSizes*NPRBs/rmc.NDLRB;
    rmc  = lteRMCDL(rmc,Ncodewords); % rupdate RMC
end
%if(0==rmc.PDSCH.TrBlkSizes(6))
if (0)
    % This has no effect for 6th subframe
    
    % If the 6th subframe was configured to carry no information bits 
    % from higher layers, it is modified to transport the same amount as in
    % the first subframe. 
    % The 1th and 6th subframe are similiar becaus both contain the 
    % synchronitization symbols. However the 1th subframe contais the PBCH
    % in slot 1 of subframe  0 and subframe 5 (6th subframe) 
    % does not contains PBCH.   
    rmc.PDSCH.TrBlkSizes(6)         = rmc.PDSCH.TrBlkSizes(1);
    rmc.PDSCH.CodedTrBlkSizes(6)    = rmc.PDSCH.CodedTrBlkSizes(1);
    rmc     = lteRMCDL(rmc,Ncodewords); % reference measurement channel
end

rmc = lteRMCDL(rmc,Ncodewords);

bits_per_frame = sum(rmc.PDSCH.TrBlkSizes); % sum of all bits per subframe 
Nant    = rmc.CellRefP;     % number of antennas

option = find(lte_param.Nrb==rmc.NDLRB);

if(isempty(option))
    error('A invalid number of Resource blocks was selected');
end

% TODO: use lte_DLPHYparam to find number of samples per frame
samples_per_frame= 20*lte_param.samples_per_slot(option);

waveform_frames=zeros(samples_per_frame*number_of_frames,Nant);

% generate random bits
input_bits = randi([0 1], bits_per_frame, number_of_frames);
if 0
    for i=1:number_of_frames
        
        % update frame number
        rmc.NFrame= i-1;
        
        % create 1 frame of a LTE RMC signal
        [waveform,rgrid,rmccFgOut] = lteRMCDLTool(rmc,input_bits(:,i));
        % concatenate frames
        waveform_frames((i-1)*samples_per_frame+1: i*samples_per_frame,:)=...
            waveform;
        
    end
else
    rmc.TotSubframes                    = 10*number_of_frames;
    [waveform_frames,rgrid,rmccFgOut]   = lteRMCDLTool(rmc,input_bits(:)); 
end

if(Nant>1)
    % waveform_frames is composed of
    % [all_real_ant1 all_real_ant2 all_real_ant3 all_real_ant4]
    % +
    % j([all_imag_ant1 all_imag_ant2 all_imag_ant3 all_imag_ant4])
    waveform_frames_for_file = reshape(waveform_frames,1,[]);
else
    waveform_frames_for_file = waveform_frames;
end

%% remove cyclic prefix
waveform_frames_cpless_for_file = lte_ofdm_remove_cp(...
     waveform_frames_for_file,rmc.NDLRB,rmc.CyclicPrefix);

%% prepare files names
file_output_name_mat        = [file_bin_path file_output_name];
file_output_name_bin_real   = [file_bin_path file_output_name '_real.dat'];
file_output_name_bin_imag   = [file_bin_path file_output_name '_imag.dat'];
file_output_cpless_name_re  = [file_bin_path file_output_name 'cpless_real.dat'];
file_output_cpless_name_im  = [file_bin_path file_output_name 'cpless_imag.dat'];
%% save signal
if (1==save_signal_in_a_file)
        
    save(file_output_name_mat);
    
    fp_real         = fopen(file_output_name_bin_real,'wb');
    fp_imag         = fopen(file_output_name_bin_imag,'wb');    
    fp_cpless_re    = fopen(file_output_cpless_name_re,'wb');
    fp_cpless_im    = fopen(file_output_cpless_name_im,'wb');
    
    fwrite(fp_real,real(waveform_frames_for_file),'float');
    fwrite(fp_imag,imag(waveform_frames_for_file),'float');
    fwrite(fp_cpless_re,real(waveform_frames_cpless_for_file(:)),'float');
    fwrite(fp_cpless_im,imag(waveform_frames_cpless_for_file(:)),'float');
    
    fclose(fp_real);
    fclose(fp_imag);
    fclose(fp_cpless_re);
    fclose(fp_cpless_im);
end
%%
% prints
disp('---------------------------------------------------------------');
rmccFgOut
rmccFgOut.PDSCH