% This code is a modified version of the codes in links below:
% http://www.mathworks.com/help/lte/examples/lte-downlink-channel-estimation-and-equalization.html
% http://www.sharetechnote.com/html/lte_toolbox/Matlab_LteToolbox_TimeDomain.html
%
% Version note:
% This script do not create a real LTE signal, yet. Currently the physical
% signals(PSS, SSS and RS) are created and mpped to their respective
% resource elements. All other resource elements are filled with a QAM
% symbol.
close all; clear;
%% General settings
% Create a LTE signal with NsubFrames
NFrames = 100;

file_bin_path   = 'D:\LAPS_LASSE\svn\Lasse\compression\msvq\gsvq\2015-01-29\out_quant_all_slots_filled\';
file_output_name= 'lte_dl';

save_signal_in_a_file = 0;

%% Cell-Wide Settings
enb.NDLRB           = 6;                  % Number of resource blocks
enb.CellRefP        = 1;               % One transmit antenna port
enb.NCellID         = 0;                % Cell ID
enb.CyclicPrefix    = 'Normal';    % Normal cyclic prefix
enb.NFrame          = 0
enb.NSubframe       = 0

% Windowing default is 4 (TODO: check if 4 is correct). The spectrum of an 
% OFDM signal shows spectral spikes that are caused by the discontinuity 
% between two OFDM symbols during signal generation. Windowinfg avoid these
% spikes. See: http://www.rohde-schwarz.com/en/applications/smooth-your-lte-signal-application-card_56279-4745.html
enb.Windowing=4;
enb.DuplexMode = 'FDD';         % FDD

Modulation = 'QPSK';
%% Subframe Resource Grid Size

gridsize = lteDLResourceGridSize(enb);
K = gridsize(1);    % Number of subcarriers
L = gridsize(2);    % Number of OFDM symbols in one subframe
P = gridsize(3);    % Number of transmit antenna ports

%% Payload data generation 
if      (strcmpi('QPSK',Modulation))
    bitsPerRE = 2;
elseif  (strcmpi('16QAM',Modulation))
    bitsPerRE = 4;
elseif  (strcmpi('64QAM',Modulation))
    bitsPerRE = 6;
else
    error(sprintf('%s is not valid. Select a valid modulation: QPSK | 16QAM | 64QAM',...
        Modulation));
end

% Number of bits needed is size of resource grid (K*L*P) * number of bits
% per Resource Element (2 for QPSK, 4 for 16QAM and 6 for 64QAM)
numberOfBits = (K*L*P*bitsPerRE)*NFrames;

% Create random bit stream
inputBits = randi([0 1], numberOfBits, 1);

% Modulate input bits
inputSym = lteSymbolModulate(inputBits,Modulation);

%% Frame Generation


txGrid = [];

% For all subframes within the frame + 1 (10 subframes + 1 subframe)
% When the OFDM modulated time domain waveform is passed through a channel 
% the waveform will experience a delay. To avoid any samples being missed 
% due to this delay an extra subframe is generated, therefore 11 subframes 
% are generated in total. 
for sf = 0:NFrames*10-1

    % Set subframe number
    enb.NSubframe = mod(sf,10);

    % Set Frame number
    NFrame      = fix(sf/10);
    enb.NFrame  = NFrame;
    
    % Generate empty subframe
    subframe = lteDLResourceGrid(enb);

    % Map input symbols to grid
    % Number of resource elements
    NREs    = length(subframe(:));
    inputSymInd = (NFrame*NREs)+1 : (NFrame+1)*NREs;
    subframe(:) = inputSym(inputSymInd);

    % Generate synchronizing signals
    % Note that the Primary Synchronization Signal (PSS) and Secondary 
    % Synchronization Signal (SSS) only occur in subframes 0 and 5, but the
    % LTE System Toolbox takes care of generating empty signals and indices
    % in the other subframes so that the calling syntax here can be
    % completely uniform across the subframes.
    pssSym = ltePSS(enb);
    sssSym = lteSSS(enb);
    pssInd = ltePSSIndices(enb);
    sssInd = lteSSSIndices(enb);

    % Map synchronizing signals to the grid
    subframe(pssInd) = pssSym;
    subframe(sssInd) = sssSym;

    % Generate cell specific reference signal symbols and indices
    % For each subframe the Cell-Specific Reference Signal (Cell RS) is 
    % added.
    cellRsSym = lteCellRS(enb);
    cellRsInd = lteCellRSIndices(enb);

    % Map cell specific reference signal to grid
    subframe(cellRsInd) = cellRsSym;

    % Append subframe to grid to be transmitted
    txGrid = [txGrid subframe]; %#ok

end
%% OFDM Modulation

% txWaveform is the resulting time domain waveform. Each column contains 
% the time domain signal for each antenna port.
[txWaveform,info] = lteOFDMModulate(enb,txGrid);

%% save signal in a file
if (1==save_signal_in_a_file)
    file_output_name_mat        = [file_bin_path file_output_name];
    file_output_name_bin_real   = [file_bin_path file_output_name '_real.dat'];
    file_output_name_bin_imag   = [file_bin_path file_output_name '_imag.dat'];
  
    % save .mat
    save(file_output_name_mat);
    
    fp_real=fopen(file_output_name_bin_real,'wb');
    fp_imag=fopen(file_output_name_bin_imag,'wb');
    fwrite(fp_real,real(txWaveform),'float');
    fwrite(fp_imag,imag(txWaveform),'float');
    fclose(fp_real);
    fclose(fp_imag);
end

%% plots
lte_plotOFDMSymbols(txWaveform,enb.NDLRB,'Normal',0,0);