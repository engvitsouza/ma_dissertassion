% lteDLPHYparam returns an object with the parameters given the number of
% resource blocks.
%
%   Nrb:            [6 15 25 50 75 100];
%   CyclicPrefix:   'normal' or 'extended'
%
% It returns only for normal CP length.
%
% Author: Leonardo Ramalho
% 05/01/2014
%
function enb=lteDLPHYparam(Nrb,CyclicPrefix)

    % Number of resource block options
    NrbOptions 		= [6 15 25 50 75 100];
    
    %channel bandwidth options
    bwOptions		= [1.4 3 5 10 15 20];

    % Sampling rate options
    FsMHzOptions 	= [1.92 3.84 7.68 15.36 23.04 30.72];

    % (I)FFT size options
    FFT_size 		= [128 256 512 1024 1536 2048];

    T_CP_us 		= [5.2 ;4.7];
    
    T_CP_us_extended = [16.6667];
    
    cp_length=round(T_CP_us*FsMHzOptions);
    %disp(cp_length);
    option=find(NrbOptions==Nrb);
    if(isempty(option))
        err_str= sprintf('%s%s','Nrb is not a valid number or resource block: ', ...
            num2str(NrbOptions));
        error(err_str );
    end
    
    
    
    Fs_MHz          = FsMHzOptions(option);
    
    
    if(strcmpi(CyclicPrefix,'extended'))
        cp_ext_len      = round(T_CP_us_extended*Fs_MHz);
        N_cp_l_0        = cp_ext_len;
        N_cp_l_else     = cp_ext_len;
        
        % Number of subcarriers per resource block
        N_sc_rb         = 12;
        %Number of OFDM symbols per slot
        N_dl_symb       = 6;
    elseif(strcmpi(CyclicPrefix,'normal'))
        N_cp_l_0        = cp_length(1,option);
        N_cp_l_else     = cp_length(2,option);
        
        % Number of subcarriers per resource block
        N_sc_rb         = 12;
        
        %Number of OFDM symbols per slot
        N_dl_symb       = 7;
        
    else
        % TODO: implement Extended CP with subcarrier spacing of 7.5 KHz
        error('Select a valid CyclicPrefix: normal or extended');
    end
    
    enb.bw_MHz      = bwOptions(option);
    enb.Fs_MHz      = Fs_MHz;
    
    enb.FFT_size    = FFT_size(option);
    
    % number of subcarrier per OFDM symbol
    enb.Nsc         = Nrb*N_sc_rb; 
    
    % With extended CP, all OFDM symbols has the same amount of CP
    enb.samplesPerSlot  = (N_cp_l_0+enb.FFT_size)+(N_dl_symb-1)*(N_cp_l_else+enb.FFT_size);
    
    enb.samplesPerFrame = enb.samplesPerSlot*20;
    enb.cp_0_length     = N_cp_l_0;
    enb.cp_else_length  = N_cp_l_else;
    enb.N_dl_symb       = N_dl_symb;

    enb.Nrb             = Nrb;
    enb.SymbolPerFrame  = N_dl_symb*20;

end