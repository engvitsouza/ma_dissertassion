% This function inserts cyclic prefix (CP) in each OFDM symbol that do not 
% contains CP. 
% Usage:
% x_with_cp = lte_ofdm_insert_cp(ofdm_symbols_cpless,Nrb,CyclicPrefixType)
%
% OFDM_SYMBOLS_CPLESS is a matrix where each collumn is ofdm symbol.
% NRB is the number of resource block of signal. It can be one of the
% following options: 6   15   25   50   75  100
% CYCLICPREFIXTYPE is 'normal' or 'extended'
%
% x_with_cp is a row with all OFDM symbols and their cyclic prefix
function x_with_cp = lte_ofdm_insert_cp(ofdm_symbols_cpless,Nrb,CyclicPrefixType)

[fft_size,Nofdm_syms]=size(ofdm_symbols_cpless);
x=ofdm_symbols_cpless;

lte_param = lte_DLPHYparam(Nrb,CyclicPrefixType);

% Number of samples in CP in the symbol first symbol of slot
cp0_len     = lte_param.cp_0_length;

% Number of samples in CP in the symbol that are not the first symbol in
% slot
cp_else_len = lte_param.cp_else_length;

% Number of symbols per OFDM symbol
N_dl_symb   = lte_param.N_dl_symb;

if (fft_size~=lte_param.FFT_size)
    error('Nrb or number of samples per ofdm symbol invalid');
end

ind = 0;
for i=1:Nofdm_syms
    if (rem(i,N_dl_symb)==1)
        % If this is the first symbol in slot
        x_with_cp(ind + 1:ind+cp0_len) = ofdm_symbols_cpless(fft_size-cp0_len+1:end,i);
        ind = ind + cp0_len;
        x_with_cp(ind + 1:ind+fft_size) = ofdm_symbols_cpless(:,i);
        ind = ind + fft_size;
    else
        x_with_cp(ind + 1:ind+cp_else_len) = ofdm_symbols_cpless(fft_size-cp_else_len+1:end,i);
        ind = ind + cp_else_len;
        x_with_cp(ind + 1:ind+fft_size) = ofdm_symbols_cpless(:,i);
        ind = ind + fft_size;
    end
end


end