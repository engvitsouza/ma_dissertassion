lpcdl_evm = [290.2280  242.5578    4.4353    2.1374    1.0518    0.5218    0.2608];
lpcdl_rate = [1.5075    2.4392    3.1026    3.6624    4.4652    5.3650    6.2919];

lpcul_evm_Gain1ByAtt=[33.3480    1.8405    0.9054    0.4492];
lpcul_rate_Gain1ByAtt = [3.2356    3.9268    4.7826    5.6985];

lpcul_evm_GainAsymptotic = [4296.5979 4.4719 1.2167  0.5672];
lpcul_rate_GainAsymptotic = [2.8746  3.4877   4.5033  5.45942];

figure;
plot(lpcul_rate_Gain1ByAtt,lpcul_evm_Gain1ByAtt,'-xb',...
    lpcul_rate_GainAsymptotic,lpcul_evm_GainAsymptotic,'-sg',...
    lpcdl_rate(2:end),lpcdl_evm(2:end),...
    '-or','Linewidth',3,'MarkerSize',15);

ylim([0 10]);
xlim([2 8]);

xlabel('Bits per IQ component');
ylabel('EVM (%)');

figure;
plot(asymptotic_gains_re);
hold on;
plot(ones(2048,1)*(1/att),'--r','LineWidth',2);
hold off; 
xlabel('n');ylabel('G[n]');
axis tight;
text(1400,1/att+2,'1/att','Color','red','FontSize',25);