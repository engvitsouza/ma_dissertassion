% lte_EVMPerOFDMSymbol calculates the EVM of received LTE signals.
%
% WARNING: This function DO NOT perform equalization. It assumes that the
% signal in time domain has only noise inserted. It is pratical to test
% compression schemes.
%
% Usage1:
% EVMs=lte_EVMPerOFDMSymbol(txLteSignal,rxLteSignal,Nrb,cyclicPrefix,frame)
%
% txLteSginal and rxLteSignalis are complex lte signals in time domain with
% a number of frame greater or equals than specified by frame.
% Nrb is the number of resource blocks used by enb.
% frame is the frame to display.
% cyclicPrefix is 'normal' or 'extended'
% frame is the selected frame to
% slot is the slot to display within the frame specified. It is a number
% between  0-19
%
% Usage2:
% EVMs=lte_EVMPerOFDMSymbol(txLteSignal,rxLteSignal,Nrb,cyclicPrefix,frame,slot,plotQAMsymbols)
%
% Return the EVM of a single lte slot. The parameters are the same plus two:
% slot, number of the derised slot
% plotQAMsymbols, to plot the qam symbols of the specified slot.
%
function EVMs=lte_EVMPerOFDMSymbol(txLteSignal,rxLteSignal,Nrb,cyclicPrefix,frame,slot,plotQAMsymbols)

enb         = lte_DLPHYparam(Nrb,cyclicPrefix);
N_dl_symb   = enb.N_dl_symb;
if(nargin<=5)
    % if slot is not given in parameter, The SNR of all the ofdm symbols is
    % calculated, ofdm symbols of 1 slot per time.
    EVMs=zeros(N_dl_symb,20);
    for slot_number=0:19
        EVMs(:,slot_number+1)=lte_EVMPerOFDMSymbol(txLteSignal,rxLteSignal,Nrb,cyclicPrefix,frame,slot_number,0);
    end
else
    EVMs=zeros(N_dl_symb,1);
    
    Nsamples_per_frame  = enb.samplesPerFrame;
    N_cp_l_0            = enb.cp_0_length;
    N_cp_l_else         = enb.cp_else_length;
    FFT_size            = enb.FFT_size;
    
    % select one frame
    frame_lte_td_tx=lte_get_frame_lte_td(txLteSignal,Nsamples_per_frame,frame);
    frame_lte_td_rx=lte_get_frame_lte_td(rxLteSignal,Nsamples_per_frame,frame);
    
    if (plotQAMsymbols)
        % Initialize the OFDM symbols in frequency domain. 
        % They are used only in plots
        ofdm_symbols_fd_tx=zeros(FFT_size,N_dl_symb);
        ofdm_symbols_fd_rx=zeros(FFT_size,N_dl_symb);
    end
    
    % select one slot
    slot_lte_td_tx = lte_get_slot_ofdma_td_from_frame_lte(frame_lte_td_tx,slot,N_cp_l_0,N_cp_l_else,N_dl_symb,FFT_size);
    slot_lte_td_rx = lte_get_slot_ofdma_td_from_frame_lte(frame_lte_td_rx,slot,N_cp_l_0,N_cp_l_else,N_dl_symb,FFT_size);
    
    % Select the OFDM symbols in time domain, without CP
    for i=0:N_dl_symb-1
        ofdm_symb_td_tx = ...
            lte_get_symb_ofdm_td_from_slot_lte(...
            slot_lte_td_tx,i,N_cp_l_0,N_cp_l_else,FFT_size); %time domain
        
        ofdm_symb_td_rx = ...
            lte_get_symb_ofdm_td_from_slot_lte(...
            slot_lte_td_rx,i,N_cp_l_0,N_cp_l_else,FFT_size); %time domain
        
        % OFDM symbols in frequency domain
        ofdm_symb_fd_tx = fft(ofdm_symb_td_tx);
        ofdm_symb_fd_rx = fft(ofdm_symb_td_rx);
        
        % calculate the EVM
        EVMs(i+1)= lte_evm(ofdm_symb_fd_rx(:),ofdm_symb_fd_tx(:));
        
        if (plotQAMsymbols)
            ofdm_symbols_fd_tx(:,i+1)=ofdm_symb_fd_tx(:);
            ofdm_symbols_fd_rx(:,i+1)=ofdm_symb_fd_rx(:);
        end
    end    
    %% plots
    if(plotQAMsymbols)
        set(0,'DefaultAxesFontSize', 14);
        figure(201);
        for i=0:N_dl_symb-1
            %subplot(2,2,mod(i,4)+1);
            subplot(2,4,i+1);
            plot(real(ofdm_symbols_fd_rx(:,i+1)),...
                imag(ofdm_symbols_fd_rx(:,i+1)),'.r');
            hold on;
            plot(real(ofdm_symbols_fd_tx(:,i+1)),...
                imag(ofdm_symbols_fd_tx(:,i+1)),'+b');
            hold off;
            %ylim([-1 1]);xlim([-1 1]);
            title(sprintf('OFDM symbol %d, slot %d\nEVM: %.2f %%',...
                i,slot,EVMs(i+1)*100));
        end
        
    end
end
end