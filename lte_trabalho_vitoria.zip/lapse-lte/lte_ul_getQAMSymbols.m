% lte_ul_getQAMSymbols demodulates a LTE signal recovers the QAM symbols of
% transmission and reception.
%
% Usage:
% txWaveform - transmitted time domain LTE signal. Signal before channel.
% rxWaveform - received time domain LTE signal.
% ue - UE specific settings
% plotConstellation - flag to plot (or not) constellation of received
% signal. 0- no plot.  1- plot.
%
%
% qamSymbols - a struct with transmitted symbols and received symbols
function qamSymbols = lte_ul_getQAMSymbols(txWaveform,rxWaveform,ue,plotConstellation)
%% Some parameters
totSubframes    = ue.TotSubframes;
NsubFrame       = ue.NSubframe;

% Channel estimation is performed as described in TS 36.101, Annex F for 
% the purposes of transmitter EVM testing
if 0
cec.PilotAverage = 'TestEVM';   
cec.Reference = 'Antennas';
else
cec.FreqWindow = 25;
cec.TimeWindow = 15;
cec.InterpType = 'linear';
cec.PilotAverage = 'UserDefined';
cec.Reference =  'Layers';
end
% symbols per subframe. Note that if extend CP is used, this must be 12.
% TODO: Check if it is normal or extend CP
symsPerSf   = 14; 
%%
% Calculate sample offset
%offset = lteULFrameOffset(ue,ue.PUSCH, rxWaveform);
% it is assumed that the offset is already 0.
offset = 0;

txGrid = lteSCFDMADemodulate(ue, txWaveform);
rxGrid = lteSCFDMADemodulate(ue, rxWaveform(1+offset:end, :));

%% Channel and noise power spectral density estimation for each subframe
estChannelGrid  = zeros(size(rxGrid));
eqGrid_mmse     = [];
eqGrid          = [];
txSymGrid       = [];
rxSymGrid       = [];
tmp_debug = [];
ue.NSubframe = 0;
for i=0:totSubframes-1
    fromSymbol  = i*symsPerSf+1;
    toSymbol    = (i+1)*symsPerSf;
    if 1
        rxGridSf    = rxGrid(:,fromSymbol:toSymbol);
    else
        samplesPerSf    = 7680;
        fromSample      = i*samplesPerSf+1;
        toSample        = i*samplesPerSf+samplesPerSf;
        rx_sf = rxWaveform(offset+fromSample:toSample);
        % Frequency offset estimation and correction for this subframe
        delta_f_tilde = lteFrequencyOffset(ue, rx_sf, 0);
        
        rxSubframeFreqCorrected = lteFrequencyCorrect( ...
            ue, rx_sf, delta_f_tilde);
        
        rxGridSf = lteSCFDMADemodulate(ue, rxSubframeFreqCorrected);
    end
    txGridSf    = txGrid(:,fromSymbol:toSymbol);
    [estChannelGridSf, noiseEstSf] = lteULChannelEstimate(...
        ue,ue.PUSCH, cec, rxGridSf,txGridSf);
    
    
    
    %Get indices of LTE grid
    ind = ltePUSCHIndices(ue, ue.PUSCH);
    [rxSym,hestSym,txSym] = lteExtractResources(ind, rxGridSf, estChannelGridSf,txGridSf);
    
    % Perform equalization for this subframe
    %eqGridSf_mmse    = lteEqualizeMMSE(rxGridSf,estChannelGridSf, noiseEstSf);
    eqGridSf    = lteEqualizeZF(rxSym,hestSym);
    
    tmp_error_power = mean(abs(eqGridSf-txSym).^2);
    
    tmp_debug =[tmp_debug tmp_error_power];
    
    estChannelGrid(:,fromSymbol:toSymbol)   = estChannelGridSf;
    %eqGrid_mmse      = [eqGrid_mmse eqGridSf_mmse(:,[1:3 5:10 12:14])];
    eqGrid           = [eqGrid reshape(eqGridSf,12*length(ue.PUSCH.PRBSet),[])];
    txSymGrid        = [txSymGrid reshape(txSym,12*length(ue.PUSCH.PRBSet),[])];
    rxSymGrid        = [rxSymGrid reshape(rxSym,12*length(ue.PUSCH.PRBSet),[])];
    ue.NSubframe = mod(ue.NSubframe+1,10);
end

[ifft_size,~] = size(txSymGrid);
rxSymbols   = ifft(eqGrid)*sqrt(ifft_size);
txSymbols   = ifft(txSymGrid)*sqrt(ifft_size);

%break; % temporary break for debugging
%%
% for i = 1:140
%     plot(rxSymbols(:,i),'+');
%     title(sprintf('sym= %d',i));
%     pause(0.5);
% end
if(nargin>=4)
    if (1==plotConstellation)
        plot_slot = 0;
        pusch_syms_per_sf = 12;
        figure;
        for i=0:pusch_syms_per_sf/2-1
            subplot(2,3,i+1);
            plot_Symbol  = plot_slot*pusch_syms_per_sf+1+i;
            
            % the fourth symbol of each slot are not DFT-encoded.
            plot((rxSymbols(:,plot_Symbol)),'.r','MarkerSize',5);
            hold on;
            plot((txSymbols(:,plot_Symbol)),'+','MarkerSize',10);
            hold off;
            
        end
    end
end
qamSymbols.txSymbols   = txSymbols;
qamSymbols.rxSymbols   = rxSymbols;
end