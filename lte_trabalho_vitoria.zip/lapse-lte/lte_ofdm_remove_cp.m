% lte_ofdm_remove_cp remove the cyclic prefix (CP) of OFDM symbols and 
% returns a matrix with each OFDM symbol.
% 
% Usage:
% lte_signal_cp_less = lte_ofdm_remove_cp(ofdm_signal,Nrb,CyclicPrefix)
%
% OFDM_SIGNAL is a row signal with the LTE signal. All OFDM symbols have
% cyclic prefix.
% NRB is the number of resource blocks. Options: : 6   15   25   50   75  100
% CYCLICPREFIX is 'normal' or 'extended'
%
% The output LTE_SIGNAL_CP_LESS is a matrix where each column is a OFDM
% symbol in time domain without cyclic prefix.
%
function lte_signal_cp_less = lte_ofdm_remove_cp(ofdm_signal,Nrb,CyclicPrefix)

% make it a vector
ofdm_signal = ofdm_signal(:);

lte_signal_param        = lte_DLPHYparam(Nrb,CyclicPrefix);
fft_size                = lte_signal_param.FFT_size;
OFDM_symbols_per_Slot   = lte_signal_param.N_dl_symb;
samples_per_slot        = lte_signal_param.samplesPerSlot;       

signal_len = length(ofdm_signal);
if (0==signal_len)
    error('There is no elements in ofdm_signal');
end

% Verify if there is a multiple of
if(0~=rem(signal_len,samples_per_slot))
    error(['The length of input signal must be multiple of number of '...
    ' samples in a slot']);
end

number_of_slots = signal_len/samples_per_slot;

lte_signal_cp_less      = zeros(fft_size,number_of_slots);

for slot_number=1:number_of_slots;
    
    % Get the slot from lte signal
    lte_slot = lte_get_slot_ofdma_td_from_frame_lte(...
        ofdm_signal,slot_number-1,lte_signal_param.cp_0_length,...
        lte_signal_param.cp_else_length,OFDM_symbols_per_Slot,fft_size);
    
    % Calculate the indexes of each OFDM symbol
    ind_ofdm_from   = (slot_number-1)*OFDM_symbols_per_Slot+1;
    ind_ofdm_to     = (slot_number-1)*OFDM_symbols_per_Slot+OFDM_symbols_per_Slot;
    % disp(['from ' num2str(ind_ofdm_from) ' to ' num2str(ind_ofdm_to)]);
    
    lte_signal_cp_less(:,ind_ofdm_from:ind_ofdm_to)=...
        lte_get_symbols_ofdm_td_from_slot_lte(lte_slot,Nrb,CyclicPrefix);
end
end