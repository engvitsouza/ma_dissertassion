% This script simulates compresion of uplink LTE signals. The scenario
% includes two User Equipments with distinct flat fading channel. The same
% noise is added to signal at recepction (after channel). The compression
% and decompression is performed and EVM and rate are evaluated.
% Diagram below shows a summary of simulation
% 
%       Noise ->->->-> |
%                      |
% UE1 -> att1 -> |     |
%                +->-> + -> |Compression| -> |Decompression| ->  |evaluate results| 
% UE2 -> att2 -> |   
%
% Compression is based on adaptive scaling + LPC + Huffman
%
clear; close all;
addpath('../lapse-lte/');
addpath('../compression-utils/');
addpath('../lte_dpcm/');
%% Simulation configuration

%Number of LTE Frames for testing. With Nframes = 1. Simulation is faster.
Nframes = 1;

%Number of LTE Frames for training
Nframes_tr =1;

% Set the reference channel for UEs. It is the same for both UEs. See
% Annex A of TS 36.104 for more details of each Reference Channel.
RC = 'A1-3';

% Set the Resource blocks (RB) that each UE will use. Note that the sum 
% must not be higher than the maximum number of REsource blocks. For 
% example, with A1-3, the bandwidth is 5 MHz, that is, the number of 
% avilable RBs is 25, so the total number of resource block allocated for 
% all UEs must be lower or equals than 25.
ue1_PRBSet = transpose([0:14]);
ue2_PRBSet = transpose([15:24]);

% Set the transport block size (TBS) for each UE. Note that TBS is
% proportional to the number of allocated resource blocks and the adopted
% Modulation and coding scheme(MCS).
% For more details of relation between Transport block size and Number of 
% resource blocks, see 3GPP 36.213, Table 7.1.7.2.1-1: Transport block size 
% table.
ue1_TrBlkSize = 1320;
ue2_TrBlkSize = 872;

numSubframes = 10*Nframes;

% Channel parameters: Attenuation for each UE and UE1's SNR 
attdB_ue1 = 31.3-3;
attdB_ue2 = 6.8; % 3dB above reference level

% This is the time domain SNR related to UE1. Thus, the noise power is 
% calculated based on power of attenuated signal of UE1.
SNRdB = 5;

% Compression parameters: Number of bits of quantizer, predictor Order and
% Quantizer loading factor
% Number of bits used on quantizer of compressor. It can be a vector to 
% simulates various rate per IQ component.
Nbits           = [6:8];
%predictor order of LPC algorithm
predictorOrder  = 6;

%Quantizer loading factor
% 1 - quantizer loading factor is calculated from training
% 0 - the quantizer loading factor is set by quantizer_lf
get_qlf_from_training = 0;

% When get_qlf_from_training =0, you must provide a quantizer loading
% factor
quantizer_lf = 5;
%% Compute parameters

% Same configurations for each UE
rmc         = lteRMCUL(RC);
rmc.TotSubframes = numSubframes;
% Override the PUSCH information. lteRMCUL returns recomputed PUSCH 
% transport block sizes and physical channel capacities to maintain the 
% coding rate 
rmc.PUSCH.PRBSet     = ue1_PRBSet(:);
rmc.PUSCH.TrBlkSizes = ue1_TrBlkSize*ones(1,10);
rmc.CyclicShift = 0;
rmc.SeqGroup = 0;
rmc.RNTI = 1;
ue1 = lteRMCUL(rmc,1);

% Override the PUSCH information. lteRMCUL returns recomputed PUSCH 
% transport block sizes and physical channel capacities to maintain the 
% coding rate 
rmc.PUSCH.PRBSet     = ue2_PRBSet(:);
rmc.PUSCH.TrBlkSizes = ue2_TrBlkSize*ones(1,10);

% TODO: maybe we have to change theses parameters to create real distinct
% uplink signals
rmc.CyclicShift = 0;
rmc.SeqGroup = 0;
rmc.RNTI = 2;
ue2 = lteRMCUL(rmc,1);


ue1_pusch   = ue1.PUSCH;
ue2_pusch   = ue2.PUSCH;

trBlkSize_ue1 = ue1_pusch.TrBlkSizes(1);
trBlkSize_ue2 = ue2_pusch.TrBlkSizes(1);

ue1_bits  = randi([0 1],numSubframes*trBlkSize_ue1,1);
ue2_bits  = randi([0 1],numSubframes*trBlkSize_ue2,1);

Nrb     = rmc.NULRB;
cptype  = rmc.CyclicPrefixUL;

info = lteSCFDMAInfo(rmc);

%% Signal generation

% waveout_ue1 and waveout_ue2 stores the time domain LTE signal for UE1 and
% UE2
waveout_ue1 = [];
waveout_ue2 = [];
for nsf = 1:numSubframes
    
    % Create resource grid
    ue1.NSubframe = mod(nsf-1,10);
    ue2.NSubframe = mod(nsf-1,10);
    
    txgrid_ue1 = lteULResourceGrid(ue1);
    txgrid_ue2 = lteULResourceGrid(ue2);
    
    % Generate the symbols for Demodulaon Reference Signals
    [DMRSSym_ue1,infoDMRS_ue1,layerseqDMRS_ue1] = ltePUSCHDRS(ue1,ue1_pusch);
    [DMRSSym_ue2,infoDMRS_ue2,layerseqDMRS_ue2] = ltePUSCHDRS(ue2,ue2_pusch);
    
    % Generate user data
    trblkin_ue1 = ue1_bits(ue1.NSubframe*trBlkSize_ue1+1: (ue1.NSubframe+1)*trBlkSize_ue1);
    trblkin_ue2 = ue2_bits(ue2.NSubframe*trBlkSize_ue2+1: (ue2.NSubframe+1)*trBlkSize_ue2);
    
    [cwout_ue1,chinfo_ue1] = lteULSCH(ue1,ue1_pusch,trblkin_ue1);
    [cwout_ue2,chinfo_ue2] = lteULSCH(ue2,ue2_pusch,trblkin_ue2);
    
    puschSym_ue1 = ltePUSCH(ue1,ue1_pusch,cwout_ue1);
    puschSym_ue2 = ltePUSCH(ue2,ue2_pusch,cwout_ue2);
    
    % Generate indices for PUSCH and DRS
    puschIndices_ue1     = ltePUSCHIndices(ue1,ue1_pusch);
    puschIndices_ue2     = ltePUSCHIndices(ue2,ue2_pusch);
    
    dmrsIndices_ue1      = ltePUSCHDRSIndices(ue1,ue1_pusch);
    dmrsIndices_ue2      = ltePUSCHDRSIndices(ue2,ue2_pusch);
    
    txgrid_ue1(puschIndices_ue1)    = puschSym_ue1;
    txgrid_ue2(puschIndices_ue2)    = puschSym_ue2;
    
    txgrid_ue1(dmrsIndices_ue1)     = DMRSSym_ue1;
    txgrid_ue2(dmrsIndices_ue2)     = DMRSSym_ue2;
    
    % SC-FDMA modulation
    txwave_sf_ue1 = lteSCFDMAModulate(ue1,txgrid_ue1);
    txwave_sf_ue2 = lteSCFDMAModulate(ue2,txgrid_ue2);
    
    waveout_ue1 = [waveout_ue1;txwave_sf_ue1];
    waveout_ue2 = [waveout_ue2;txwave_sf_ue2];
end
%%
ue1.NSubframe=0;
ue2.NSubframe=0;
%[finalEVM_ue1,finalDrsEVM_ue1,emissions_ue1] = hPUSCHEVM(ue1,waveout_ue1);
%[finalEVM_ue2,finalDrsEVM_ue2,emissions_ue2] = hPUSCHEVM(ue2,waveout_ue2);

%% Channel

att_ue1 = 10^(-attdB_ue1/20);
att_ue2 = 10^(-attdB_ue2/20);
SNR = 10^(SNRdB/10);
% Using flat fading channel
% Find noise power for a given SNR
noisePower = (mean(abs(att_ue1*waveout_ue1(:)).^2)/SNR); 
% Noise
v = sqrt(noisePower/2)*complex(randn(size(waveout_ue1)), randn(size(waveout_ue1)));

% Baseband LTE signal at RRU before compressor
rxwave  = att_ue1*waveout_ue1+att_ue2*waveout_ue2+v;

snr_td_ue1 = mean(abs(att_ue1*waveout_ue1).^2)/mean(abs(v).^2);
snr_td_ue2 = mean(abs(att_ue2*waveout_ue2).^2)/mean(abs(v).^2);

% Demodulate LTE signal without compression (only channel)
[~,ch_DrsEVM_ue1,ch_emissions_ue1,tmp,ch_crc_ue1] = ...
    lte_hPUSCHEVM(ue1,rxwave);
[~,ch_DrsEVM_ue2,ch_emissions_ue2,tmp,ch_crc_ue2] = ...
    lte_hPUSCHEVM(ue2,rxwave);

% Get transmitted QAM Symbols and received QAM symbols after channel 
% equalization
symbols_ue1_ch = lte_ul_getQAMSymbols(waveout_ue1,rxwave,ue1);
symbols_ue2_ch = lte_ul_getQAMSymbols(waveout_ue2,rxwave,ue2);

ch_EVM_ue1 = lteEVM(symbols_ue1_ch.rxSymbols(:),symbols_ue1_ch.txSymbols(:));
ch_EVM_ue2 = lteEVM(symbols_ue2_ch.rxSymbols(:),symbols_ue2_ch.txSymbols(:));

% Average SNR per subcarrier without compression (only channel) for UE1
snr_per_sc_ch_ue1 = mean(abs(symbols_ue1_ch.txSymbols).^2,2)./...
    mean(abs(symbols_ue1_ch.txSymbols-symbols_ue1_ch.rxSymbols).^2,2);

% Average SNR per subcarrier without compression (only channel) for UE2
snr_per_sc_ch_ue2 = mean(abs(symbols_ue2_ch.txSymbols).^2,2)./...
    mean(abs(symbols_ue2_ch.txSymbols-symbols_ue2_ch.rxSymbols).^2,2);

snr_gm_ue1_only_ch = my_geomean(snr_per_sc_ch_ue1);
snr_gm_ue2_only_ch = my_geomean(snr_per_sc_ch_ue2);
%% Compression



[x_tr_withcp,ul_frc_tr,ul_bits_tr]=...
    lte_ul_frc_signal_generator(Nframes_tr,rmc.NULRB,rmc.RC);

% Remove cp 
x_tr = lte_ofdm_remove_cp(x_tr_withcp,ul_frc_tr.NULRB,ul_frc_tr.CyclicPrefixUL);

x_tr_re = real(x_tr);
x_tr_im = imag(x_tr);

rxwave_cpless = lte_ofdm_remove_cp(rxwave,rmc.NULRB,rmc.CyclicPrefixUL);

x_re = real(rxwave_cpless);
x_im = imag(rxwave_cpless);
%% estimate predictor and quantizer limits
[A,e]       = ak_estimatePredictor([x_tr_re x_tr_im],predictorOrder);
[xmin_dusc,xmax_dusc]=ak_getPredictionErrorDynamicRange([x_tr_re x_tr_im],A);

% Full scale of ADPCM
fs_adpcm = max(abs([xmin_dusc xmax_dusc]));
%% init before loops
EVMs_per_bit_ue1        = {};
EVMs_per_bit_ue2        = {};
drsEVMs_per_bit_ue1     = {};
drsEVMs_per_bit_ue2     = {};
emissions_per_bit_ue1   = {};
emissions_per_bit_ue2   = {};
crcs_per_bit_ue1        = [];
crcs_per_bit_ue2        = [];
xq_per_bit              = zeros(info.SamplingRate*Nframes/100,length(Nbits));
avg_huffman_lengths     = zeros(length(Nbits),1);

% Geometric SNR 
snr_geomeans_ue1        = zeros(length(Nbits),1);
snr_geomeans_ue2        = zeros(length(Nbits),1);
%% compression
for i =1:length(Nbits)
    number_of_bits  = Nbits(i);
    disp(sprintf('Comprssion for P=%d b=%d...',predictorOrder,number_of_bits));
    %% compression Training
    % Getting indices for training of Huffman dictionary 
    [xq_tr_re_im,xq_tr_ind_re_im,xq_tr_hist_re_im,e_clp_tr_re_im,G_tr] =...
                ak_lteADPCM([x_tr_re x_tr_im],A,number_of_bits,fs_adpcm,10,1);
    if (get_qlf_from_training)
        quantizer_lf = fs_adpcm/rms(e_clp_tr_re_im(:));
    end
            
    %% Training of Huffman dictionary
    % Find the probability of quantization levels
    p_levels = xq_tr_hist_re_im/sum(xq_tr_hist_re_im);
    
    % Find the huffman dictionay given the levels and theirs pmf from
    % training sequence
    [dict_dusq,avglen_dusq] = huffmandict([0:2^number_of_bits-1],...
        p_levels);
    
    %% compression of testing seuquences
    [xq_te_re,xq_te_ind_re,xq_te_hist_re]=...
                ak_lteADPCM([x_re],A,number_of_bits,fs_adpcm,quantizer_lf);
    [xq_te_im,xq_te_ind_im,xq_te_hist_im]=...
                ak_lteADPCM([x_im],A,number_of_bits,fs_adpcm,quantizer_lf);
    
    if 0
        [xq_dpcm_x_tr_re_im,xq_dpcm_x_tr_ind_re_im,hist_dpcm_x_tr_re_im]=...
            ak_lteDPCM([x_tr_re x_tr_im],A,number_of_bits,xmin_dusc,xmax_dusc);
    end  
    
    %% Average number of bits per IQ component after Huffman coding
    
    [number_of_cws_dusq,nothing] = size(dict_dusq);
    cw_index_dusq   = 0:number_of_cws_dusq-1;
    cws_length      = zeros(number_of_cws_dusq,1);
    for cw_index=1:number_of_cws_dusq
        cws_length(cw_index)  = length(cell2mat(dict_dusq(cw_index,2)));
    end
    
    valid_ind_re = xq_te_ind_re(predictorOrder+1:end,:);
    valid_ind_im = xq_te_ind_im(predictorOrder+1:end,:);
    
    bits_per_sample_x_te_re   = cws_length(valid_ind_re(:)+1);
    bits_per_sample_x_te_im   = cws_length(valid_ind_im(:)+1);
    
    avg_len_huffman =...
        sum([bits_per_sample_x_te_re(:) ; bits_per_sample_x_te_im(:)])/...
        length([valid_ind_re(:) ; valid_ind_im(:)]);
    
    %% insert CP, CRC and EVM calculation
    
    xq_adpcm = complex(xq_te_re,xq_te_im);
    xq_adpcm_withcp = lte_ul_insert_cp(xq_adpcm,Nrb,cptype);
    
    % Calculates EVM and CRC for each UE
    [~,drsEVM_comp_ue1,emissions_compr_ue1,tmp,crcs_ue1] = ...
        lte_hPUSCHEVM(ue1,xq_adpcm_withcp(:));
    [~,drsEVM_comp_ue2,emissions_compr_ue2,tmp,crcs_ue2] = ...
        lte_hPUSCHEVM(ue2,xq_adpcm_withcp(:));
    
    symbols_ue1 = lte_ul_getQAMSymbols(waveout_ue1,xq_adpcm_withcp(:),ue1);
    symbols_ue2 = lte_ul_getQAMSymbols(waveout_ue2,xq_adpcm_withcp(:),ue2);
    
    evm_comp_ue1 = lteEVM(symbols_ue1.rxSymbols(:),symbols_ue1.txSymbols(:));
    evm_comp_ue2 = lteEVM(symbols_ue2.rxSymbols(:),symbols_ue2.txSymbols(:));
    
    snr_per_sc_ue1 = mean(abs(symbols_ue1.txSymbols).^2,2)./...
        mean(abs(symbols_ue1.txSymbols-symbols_ue1.rxSymbols).^2,2);
    
    snr_per_sc_ue2 = mean(abs(symbols_ue2.txSymbols).^2,2)./...
        mean(abs(symbols_ue2.txSymbols-symbols_ue2.rxSymbols).^2,2);
    
    % Calculate the geometric SNR
    snr_gm_fd_ue1 = my_geomean(snr_per_sc_ue1);
    snr_gm_fd_ue2 = my_geomean(snr_per_sc_ue2);
    
    %% save information for this number of bits
    EVMs_per_bit_ue1        = [EVMs_per_bit_ue1 evm_comp_ue1];
    EVMs_per_bit_ue2        = [EVMs_per_bit_ue2 evm_comp_ue2];
    drsEVMs_per_bit_ue1     = [drsEVMs_per_bit_ue1 drsEVM_comp_ue1];
    drsEVMs_per_bit_ue2     = [drsEVMs_per_bit_ue2 drsEVM_comp_ue2];
    emissions_per_bit_ue1   = [emissions_per_bit_ue1 emissions_compr_ue1];
    emissions_per_bit_ue2   = [emissions_per_bit_ue1 emissions_compr_ue2];
    crcs_per_bit_ue1        = [crcs_per_bit_ue1 crcs_ue1];
    crcs_per_bit_ue2        = [crcs_per_bit_ue2 crcs_ue2];
    avg_huffman_lengths(i)  = avg_len_huffman;
    xq_per_bit(:,i)         = xq_adpcm_withcp(:);
    snr_geomeans_ue1(i)     = snr_gm_fd_ue1;
    snr_geomeans_ue2(i)     = snr_gm_fd_ue2;
    disp(sprintf('Comprssion for P=%d b=%d done.',predictorOrder,number_of_bits));
end
%% Rates calculaiton

Qs =15;
factor_due_cp = 1.0703125;
enb_param = lte_DLPHYparam(Nrb,'normal');
N=enb_param.FFT_size;
P=predictorOrder;

% Calculate the average number of bits per IQ component after compression
actual_rate_huffman = ((N-P)*avg_huffman_lengths+P*Qs)/(factor_due_cp*N);
%% Suggestion name for saving file
disp(sprintf('aslpc_2ues_results_from_%d_to_%d_bits_P%d_%dframes_Attue1-%ddB_Attue2-%ddB',...
    Nbits(1),Nbits(end),predictorOrder,Nframes,round(attdB_ue1),round(attdB_ue2)));
%% results

% EVM after Channel, compression and decompression
evms_rms_ue1 = [];
evms_rms_ue2 = [];
for i=1:length(Nbits)
    evms_rms_ue1 = [evms_rms_ue1; 100*EVMs_per_bit_ue1{i}.RMS];
    evms_rms_ue2 = [evms_rms_ue2; 100*EVMs_per_bit_ue2{i}.RMS];
end

% EVM with distortions of channel only
evm_rms_ue1_only_ch = ch_EVM_ue1.RMS*100;
evm_rms_ue2_only_ch = ch_EVM_ue2.RMS*100;

% Throughput after channel, compression and decompression
throughput_ue1 = 100*[(1-mean(crcs_per_bit_ue1))];
throughput_ue2 = 100*[(1-mean(crcs_per_bit_ue2))];

% Throughput after channel only
throughput_ue1_only_ch = 100*[(1-mean(ch_crc_ue1))];
throughput_ue2_only_ch = 100*[(1-mean(ch_crc_ue2))];
%% displays
% Informations of simulation

disp(sprintf('RBs allocated to UE1: %d',length(ue1_PRBSet)));
disp(sprintf('RBs allocated to UE2: %d',length(ue2_PRBSet)));
disp(sprintf('Attenuation for UE1: %.2f dB',attdB_ue1));
disp(sprintf('Attenuation for UE2: %.2f dB',attdB_ue2));
disp(sprintf('SNR in time domain for UE1: %.2f dB',10*log10(snr_td_ue1)));
disp(sprintf('SNR in time domain for UE2: %.2f dB',10*log10(snr_td_ue2)));
% Table with Results
disp(sprintf('Nbits\tbits(IorQ)\tUE1-EVM(%%)\tUE1-SNRg\tUE1-Thru(%%)\tUE2-EVM(%%)\tUE2-SNRg\tUE2-Thru(%%)'));
disp(sprintf('%5d\t   %.2f   \t  %.2f%% \t   %.2f  \t%9d%%\t  %.2f%%  \t%.2f \t%9d%%\n',...
    transpose([Nbits(:) actual_rate_huffman(:) ...
    evms_rms_ue1(:) snr_geomeans_ue1(:)  round(throughput_ue1(:)) ...
    evms_rms_ue2(:) snr_geomeans_ue2(:) round(throughput_ue2(:))])))
disp(sprintf('  Only Channel\t\t  %.2f%%\t   %.2f  \t%9d%%\t  %.2f%% \t%.2f\t%9d%%\n',...
    evm_rms_ue1_only_ch,snr_gm_ue1_only_ch,round(throughput_ue1_only_ch),...
    evm_rms_ue2_only_ch,snr_gm_ue2_only_ch,round(throughput_ue2_only_ch)));
%% plots

set(0,'DefaultAxesFontSize', 24);
lineWidth = 2;
MarkerSize = 12;

figure;
plot(actual_rate_huffman,evms_rms_ue1,'-xg','lineWidth',lineWidth+2,'MarkerSize',MarkerSize+2);
hold on;
plot(actual_rate_huffman,evms_rms_ue2,'-ob','lineWidth',lineWidth+2,'MarkerSize',MarkerSize+2);
ylim([0 10]);
xlim([2 8]);
x_tmp=[0:16];
line_QPSK =17.5*ones(length(x_tmp),1);
line_16QAM=12.5*ones(length(x_tmp),1);
line_64QAM=8*ones(length(x_tmp),1);
plot(x_tmp,line_16QAM,'--m',...
     x_tmp,line_64QAM,'--b','LineWidth',lineWidth);
    
    text(6,8.3,'\color{blue}max EVM for 64QAM','FontSize',18);
    text(6,13,'\color{magenta}max EVM for 16QAM','FontSize',18);
hold off;
legend({sprintf('UE1 %.1f dBm',-62.2-attdB_ue1),sprintf('UE2: %.1f dBm',-62.2-attdB_ue2)});
ylabel('EVM RMS (%)');
xlabel('Bits per component sample (R)');
