#!/bin/sh

# Download dependencies
cd ..
git clone http://www.laps.ufpa.br/gitlab/lte-signal-compression/compression-utils.git
git clone http://www.laps.ufpa.br/gitlab/lte/lapse-lte.git
git clone http://www.laps.ufpa.br/gitlab/lte-signal-compression/lte_dpcm.git
cd ltelte-lpc-ul
