% LTE_GET_SYMB_OFDM_TD_FROM_SLOT_LTE returns a ofdm symbol from a slot lte
%
% X a slot lte
% SYMB the number of desired OFDM symbol
% N_CP_L_0 Number of samples in first OFDM symbol
% N_CP_L_ELSE Number of samples in CP of the remaining OFDM symbol
% FFT_SIZE Number of samples in a OFDM symbol without CP
%
% see lte_DLPHYparam to get the parameters listed above
%
function [symb_ofdm_td] = lte_get_symb_ofdm_td_from_slot_lte(x,symb,N_cp_l_0,N_cp_l_else,FFT_size)

if(symb==0)
    from_sample = N_cp_l_0+1;
    to_sample   = N_cp_l_0+FFT_size;
else
    from_sample =   (N_cp_l_0+FFT_size)+(symb-1)*(FFT_size+N_cp_l_else)+N_cp_l_else+1;
    to_sample   =   (N_cp_l_0+FFT_size)+(symb)*(FFT_size+N_cp_l_else);
end

symb_ofdm_td = x(from_sample:to_sample);