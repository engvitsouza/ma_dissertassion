%lte_evm calculates the error vector magnitude RMS and returns it as a
%   linear value (not in %). 
% lte_evm(RX_EQ,TX) calculate the EVM rms based on equalized received
% symbols and the transmitted symbols.
function evm=lte_evm(rx_eq,tx)
    
    % Take into account only symbols different of zero (very low numbers 
    % are considered quantization error and are not considered). 
    ind_gt0 = find(abs(tx)>1e-7);
    if(isempty(ind_gt0))
        evm = 0;
        return;
    end
    %ind_gt0 = 1:length(tx);
    
    % calculate the error vectors
    evs         = rx_eq(ind_gt0) - tx(ind_gt0);
    % Mean Power of transmitted symbols
    tx_power    = mean(abs(tx(ind_gt0)).^2);
    if(0==tx_power)
        tx_power=1;
    end 
    error_power = mean(abs(evs).^2);
    evm = sqrt(error_power/tx_power);
end