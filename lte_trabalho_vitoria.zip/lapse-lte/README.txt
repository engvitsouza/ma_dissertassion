================================================================================
How to create a LTE signal
================================================================================

The LTE signal can be created with lte_dl_signal_generator2.m.
This script creates waveforms in time-domain with and wihtou cyclic prefix.
This script creates 5 files:

1 file for real and 1 file for imag. component of LTE signal without Cyclic 
prefix (cpless in filename)
1 file for real and 1 file for imag. component of LTE signal with Cyclic prefix
1 file with .mat (all variables)

================================================================================
Parameters in lte_dl_signal_generator2.m
================================================================================
In lte_dl_signal_generator2.m set the following variables:

% Create a LTE signal with NFrames
% Number of LTE frames
NFrames = 1;

% Choose file path of the output files
file_bin_path   = '..\LTEsignals\s0\';

% The complex time domain signal is saved in four files. 
% 1 file for real and 1 file for imag. component of LTE signal without 
% Cyclic prefix (cpless in filename)
% 1 file for real and 1 file for imag. component of LTE signal with Cyclic 
% prefix
% 1 .mat file with all variables
% FILE_OUTPUT_NAME is the prefix of files.
% For example, with *file_output_name= 's_64QAM_20MHz'*, the output files 
% are named: (Without CP) s_64QAM_20MHz_cpless_real.dat and
% s_64QAM_20MHz_cpless_imag.dat, (With CP) s_64QAM_20MHz_real and
% s_64QAM_20MHz_imag.dat, and (all variables) s_64QAM_20MHz.mat.
file_output_name= 's_64QAM_20MHz';

% Select if the signal must be saved, 0=>do not save, 1=>save files 
save_signal_in_a_file = 1;

% Modulation used in each RE of PDSCH
% 'QPSK', '16QAM' or '64QAM'
Modulation = '64QAM';

% Select the number of resource block (Bandwidth)
enb.NDLRB           = 100;

% Number of filled resource blocks, or physical resource blocks. When N_RB
% is lower than enb.NDLRB, cell load can be considered lower.
N_RB = enb.NDLRB; % all resource block filled with data
