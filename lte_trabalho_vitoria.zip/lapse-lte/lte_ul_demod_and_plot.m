%% This script perform demodulation of a uplink LE signal and show constellation.
% TODO: display the EVM
clear;close all;
%% Signal creation and channel configuration.
[ul_signal,ul_frc,ul_bits]=lte_ul_frc_signal_generator(1,100,'A3-7');
info = lteSCFDMAInfo(ul_frc);

% Channel Model. It will be removed in final function
chcfg.NRxAnts = 1;               % Number of receive antenna
chcfg.DelayProfile = 'EPA';      % Delay profile
chcfg.DopplerFreq = 5.0;         % Doppler frequency    
chcfg.MIMOCorrelation = 'Low';   % MIMO correlation
chcfg.Seed = 100;                % Channel seed    
chcfg.NTerms = 16;               % Oscillators used in fading model
chcfg.ModelType = 'GMEDS';       % Rayleigh fading model type 
chcfg.InitPhase = 'Random';      % Random initial phases
chcfg.NormalizePathGains = 'On'; % Normalize delay profile power
chcfg.NormalizeTxAnts = 'On';    % Normalize for transmit antennas
chcfg.SamplingRate = info.SamplingRate;     

% TODO: This number must be changed every subframe, in order to be a
% continuosly changing channel. as shown in
% http://www.mathworks.com/help/lte/examples/pusch-throughput-conformance-test.html.
% Thus, the lteFadingChannel function must me called for each subframe
chcfg.InitTime = 0;

ul_param = lte_DLPHYparam(ul_frc.NULRB,ul_frc.CyclicPrefixUL);

SNRdB = 20;
SNR = 10^(SNRdB/20);
N = 1/(SNR*sqrt(double(info.Nfft)))/sqrt(2.0); 

txWaveform = ul_signal(:);
%rxWaveform = txWaveform;
%rxWaveform = 0.5*ul_signal(:)+0.01*complex(randn(size(ul_signal(:))),randn(size(ul_signal(:))));
rxWaveform_ch = lteFadingChannel(chcfg, [txWaveform; zeros(100,1)]);

v = N*complex(randn(size(rxWaveform_ch)), randn(size(rxWaveform_ch)));
rxWaveform = rxWaveform_ch+v;


%% RX demodulation

results = lte_ul_plot_tx_vs_rx(txWaveform,rxWaveform,ul_frc);
[finalEVM,finalDrsEVM,emissions] = hPUSCHEVM(ul_frc,rxWaveform);
