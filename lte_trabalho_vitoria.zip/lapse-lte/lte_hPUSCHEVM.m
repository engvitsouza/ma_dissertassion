% This is a modified version of hPUSCHEVM from LTE toolbox, such that it 
% also returns the CRC
%hPUSCHEVM EVM and in-band emission measurements
%   [FINALEVM,FINALDRSEVM,EMISSIONS,PLOTS] = hPUSCHEVM(FRC,CEC,RXWAVEFORM,ALG)
%   calculates the error vector magnitude FINALEVM, demodulation reference
%   signal error vector magnitude FINALDRSEVM and in-band emissions
%   EMISSIONS given a fixed reference channel FRC, channel estimator
%   configuration structure CEC, received waveform RXWAVEFORM and
%   algorithmic configuration structure ALG. All measurements are as per TS
%   36.101 Annex F. PLOTS is an array of objects for the plots produced in
%   this function.
%
%   This is a modified version of hPUSCHEVM
%
%   Copyright 2010-2015 The MathWorks, Inc.
%
function [finalEVM,finalDrsEVM,emissions,plots,crcs] = lte_hPUSCHEVM(frc,varargin)

if (nargin>3)
    alg = varargin{3};
else
    alg = struct();
end

% Control over receiver corrections to be performed:

% IQ offset correction with estimation of the mean of the signal in the
% time domain; estimation/correction applies to the whole waveform.
if(~isfield(alg,'CorrectIQOffsetMean'))
    alg.CorrectIQOffsetMean = true;
end

% Frequency offset correction with estimation in the time domain based
% on cyclic prefix correlation; estimation/correction applies to each
% subframe.
if(~isfield(alg,'CorrectFreqOffsetCPCorr'))
    alg.CorrectFreqOffsetCPCorr = true;
end

% Frequency offset correction with estimation in the frequency domain
% based on the phase shift between channel estimate REs in the
% locations of successive PUSCH Demodulation Reference Signal (DRS)
% symbols; estimation/correction applies to each subframe. This
% estimator is more accurate for small frequency offsets than
% estimation in the time domain.
if(~isfield(alg,'CorrectFreqOffsetPUSCHDRS'))
    alg.CorrectFreqOffsetPUSCHDRS = true;
end

% IQ offset correction with estimation assisted by the channel
% estimate; estimation/correction applies to each subframe. This
% estimator is more accurate for small IQ offsets than estimation in
% the time domain.
if(~isfield(alg,'CorrectIQOffsetChEst'))
    alg.CorrectIQOffsetChEst = true;
end

if (~isfield(alg,'EnablePlotting'))
    %alg.EnablePlotting = 'On';
    alg.EnablePlotting = 'Off'; % LLR
end

% Channel estimator configuration
if (nargin==2)
    rxWaveform = varargin{1};
    cec = struct;
    cec.PilotAverage = 'TestEVM';
    cec.Reference = 'Antennas';
else
    cec = varargin{1};
    rxWaveform = varargin{2};
end
% Compute some parameters
info = lteSCFDMAInfo(frc);
samplesPerSlot = info.SamplingRate/2000;
nSlots = floor(size(rxWaveform,1)/samplesPerSlot);
nFrames = floor(nSlots/20);
W = getEVMWindow(frc);
if (mod(W, 2)==0)
    alpha = 0;
else
    alpha = 1;
end

cpLength=double(info.CyclicPrefixLengths(2));

gridDims = lteResourceGridSize(frc);
L = gridDims(2);
nDeltaRB = frc.NULRB - size(frc.PUSCH.PRBSet, 1);
rbs = (0:frc.NULRB-1).';
rbs(frc.PUSCH.PRBSet(:, 1)+1)=[];
rbs(rbs<frc.PUSCH.PRBSet(1, 1)) = ...
    rbs(rbs<frc.PUSCH.PRBSet(1, 1))- frc.PUSCH.PRBSet(1, 1);
rbs(rbs>frc.PUSCH.PRBSet(end, 1)) = ...
    rbs(rbs>frc.PUSCH.PRBSet(end, 1))-frc.PUSCH.PRBSet(end, 1);
emissions.DeltaRB = rbs;

% Perform IQ offset correction for large offsets; smaller offsets can
% be more accurately estimated in the frequency domain but larger
% offsets need to be removed so as not to affect time-domain frequency
% offset estimation
if (alg.CorrectIQOffsetMean)
    iqoffset = mean(rxWaveform);
    if (any(abs(iqoffset)>(0.05*std(rxWaveform))))
        rxWaveform = rxWaveform - ...
            repmat(iqoffset, size(rxWaveform, 1), 1);
    end
end

% Pad on the tail to allow for CP correlation
rxWaveform = [rxWaveform; zeros(info.Nfft, size(rxWaveform,2))];

% For each slot:
evm = repmat(lteEVM([]), 2, nSlots);
evmdrs = repmat(lteEVM([]), 2, nSlots);
emissions.Absolute = zeros(nDeltaRB, nSlots);
emissions.Relative = zeros(nDeltaRB, nSlots);

% Setup plots
if (strcmpi(alg.EnablePlotting,'On'))
    [evmGridFigure,evmSymbolPlot,evmSubcarrierPlot,evmRBPlot] = hEVMPlots();
    if (nSlots>0)
        evmSymbolPlot.TimeSpan = (L/2*nSlots)-1;
    end
end

% For each subframe
rxSubframe = zeros(2*samplesPerSlot,size(rxWaveform,2));

frameEVM = repmat(lteEVM([]), 1, max(nFrames,1));
frameDrsEVM = repmat(lteEVM([]), 1, max(nFrames,1));
evmGridLow = [];
evmGridHigh = [];
crcs    = [];
for i = 0:nSlots-1
    
    % On first slot of a subframe, clear subframe buffer
    slotIndex = mod(i, 2);
    
    % Extract this slot
    rxSlot = rxWaveform(i*samplesPerSlot+(1:samplesPerSlot), :);
    
    % Build slot into subframe
    rxSubframe(samplesPerSlot*slotIndex+1: ...
        samplesPerSlot*(slotIndex+1),:) = rxSlot;
    
    % For completed subframe:
    if (slotIndex==1)
        
        % Frequency offset estimation and correction for this subframe
        if (alg.CorrectFreqOffsetCPCorr)
            delta_f_tilde = lteFrequencyOffset(frc, rxSubframe, 0);
        else
            delta_f_tilde = 0; %#ok<UNRCH>
        end
        rxSubframeFreqCorrected = lteFrequencyCorrect( ...
            frc, rxSubframe, delta_f_tilde);
        
        % Additional PUSCH DRS-based frequency offset
        % estimation and correction
        if (alg.CorrectFreqOffsetPUSCHDRS)
            rxGrid = lteSCFDMADemodulate(frc, rxSubframeFreqCorrected);
            delta_f_tilde_drs = ...
                frequencyOffsetPUSCHDRS(frc, frc.PUSCH, cec, rxGrid);
            rxSubframeFreqCorrected = lteFrequencyCorrect( ...
                frc, rxSubframeFreqCorrected, delta_f_tilde_drs);
        end
        
        % Get positions of PUSCH and PUSCH DRS
        ind = ltePUSCHIndices(frc, frc.PUSCH);
        drsInd = ltePUSCHDRSIndices(frc, frc.PUSCH);
        
        if (any(frc.PUSCH.CodedTrBlkSizes(:,frc.NSubframe+1)~=0))
            
            % For low edge EVM, high edge EVM and in-band emissions
            for e=1:3
                
                % compute EVM window edge position; standard defines this
                % in samples, the Toolbox requires it as a fraction of the
                % cyclic prefix length.
                if (e==1)
                    cpFraction = (cpLength/2+alpha-floor(W/2))/cpLength;
                    edge = 'Low';
                end
                if (e==2)
                    cpFraction = (cpLength/2+floor(W/2))/cpLength;
                    edge = 'High';
                end
                if (e==3)
                    cpFraction = 0.5;
                end
                
                % OFDM demodulation
                rxGrid = lteSCFDMADemodulate(...
                    frc, rxSubframeFreqCorrected, cpFraction);
                
                if (e==3)
                    % In-band emissions measurement
                    
                    % Remove allocated RBs
                    Y = rxGrid;
                    Y([ind; drsInd]) = [];
                    Y = reshape(Y, numel(Y)/L,L);
                    
                    % Compute absolute and relative emissions in
                    % unallocated RBs for each slot
                    for k=0:1
                        scPower = sum(abs(Y(:, (L/2)*k+(1:(L/2)))).^2,2);
                        rbPower = sum( ...
                            reshape(scPower, saLteNscRB(), nDeltaRB).', 2);
                        emissions.Absolute(:, i+k) = rbPower/(L/2);
                        emissions.Relative(:, i+k) = ...
                            emissions.Absolute(:, i+k)/ ...
                            mean(emissions.Absolute(:, i+k));
                    end
                else
                    % EVM measurement
                    
                    for r=1:2
                        % Channel estimation
                        if (r==1)
                            % First estimation from DRS only
                            Hest = lteULChannelEstimate( ...
                                frc, frc.PUSCH, cec, rxGrid);
                            refGrid = NaN(size(rxGrid));
                        else
                            % IQ offset estimation and correction based on
                            % channel estimate
                            if (alg.CorrectIQOffsetChEst)
                                
                                % Create IQ offset estimation reference
                                % waveform
                                refWaveform = ...
                                    iqOffsetChEstWaveform(frc, ...
                                    frc.PUSCH, rxGrid, refGrid);
                                
                                % Estimate IQ offset by taking the mean of
                                % the difference between the reference
                                % waveform and the received waveform
                                iqoffset2 = ...
                                    mean(rxSubframeFreqCorrected - ...
                                    refWaveform);
                                
                                % Correct IQ offset
                                rxSubframeIQCorrected = ...
                                    rxSubframeFreqCorrected - ...
                                    repmat(iqoffset2, ...
                                    size(rxSubframeFreqCorrected,1),1);
                                
                                % Redo frequency synchronisation
                                if (alg.CorrectFreqOffsetPUSCHDRS)
                                    rxGrid = lteSCFDMADemodulate(frc, ...
                                        rxSubframeIQCorrected, cpFraction);
                                    delta_f_tilde_drs2 = ...
                                        frequencyOffsetPUSCHDRS(frc, ...
                                        frc.PUSCH, cec, rxGrid);
                                    rxSubframeIQCorrected = ...
                                        lteFrequencyCorrect(frc, ...
                                        rxSubframeIQCorrected, ...
                                        delta_f_tilde_drs2);
                                end
                                
                                % Redo OFDM demodulation
                                rxGrid = lteSCFDMADemodulate(frc, ...
                                    rxSubframeIQCorrected, cpFraction);
                            end
                            
                            % Second estimation assisted using known
                            % data symbols if available; for multiple
                            % antennas, the transmitted PUSCH SC-FDMA
                            % symbols will interfere and therefore are
                            % not suitable for use as reference symbols
                            if (frc.NTxAnts>1)
                                refGrid(:) = NaN;
                            end
                            Hest = lteULChannelEstimate( ...
                                frc, frc.PUSCH, cec, rxGrid, refGrid);
                        end
                        
                        % PUSCH equalization and demodulation
                        % demodLayers contains target signal for EVM
                        % calculation demodBits are to be used to create
                        % reference signal for EVM.
                        [rxSym,hestSym] = lteExtractResources(ind, rxGrid, Hest);
                        eqSymbols = lteEqualizeZF(rxSym, hestSym);
                        ulschInfo = lteULSCHInfo(frc, frc.PUSCH, ...
                            frc.PUSCH.TrBlkSizes(:,frc.NSubframe+1),'chsconcat');
                        [demodBits, demodSymbols] = ltePUSCHDecode( ...
                            frc, ulschInfo, eqSymbols);
                        demodLayers = lteLayerMap(frc.PUSCH, demodSymbols);
                        
                        if (r==1)
                            % Decode, recode, and remodulate/demodulate
                            % demodBits to give remodLayers, a matrix of
                            % reference symbols for EVM calculation.
                            % retxSymbols are used as reference
                            % symbols to aid channel estimation.
                            [decodedBits, crc] = lteULSCHDecode( ...
                                frc, ulschInfo, ...
                                frc.PUSCH.TrBlkSizes(:,frc.NSubframe+1), demodBits);
                            crcs = [crcs; crc];
                            disp(sprintf('i=%d, e= %d, r=%d',i,e,r));
                            if (crc)
                                warning(['CRC failed on decoded data;', ...
                                    ' EVM will be inaccurate!']);
                            end
                            recodedBits = lteULSCH( ...
                                frc, frc.PUSCH, decodedBits);
                            retxSymbols = ltePUSCH(frc, frc.PUSCH, recodedBits);
                            [~,remodSymbols] = ltePUSCHDecode( ...
                                frc, ulschInfo, retxSymbols);
                            remodLayers = lteLayerMap(frc.PUSCH, remodSymbols);
                            refGrid(ind) = retxSymbols;
                        else
                            % PUSCH DRS equalization
                            % eqDrsSymbols contains target signal for EVM
                            % calculation
                            [rxDrsSym,hestDrsSym] = ...
                                lteExtractResources(drsInd, rxGrid, Hest);
                            eqDrsSymbols = lteEqualizeZF( ...
                                rxDrsSym, hestDrsSym);
                        end
                    end
                    
                    % Create DRS reference symbols for EVM calculation
                    refDrsSymbols = ltePUSCHDRS(frc, frc.PUSCH);
                    
                    % Compute EVM (per slot)
                    evm(e, i+(0:1)) = getPerSlotEVM(demodLayers, remodLayers);
                    for k=0:1
                        fprintf('%s edge PUSCH EVM, slot %d: %0.3f%%\n',edge,(frc.NSubframe*2)+k,evm(e,i+k).RMS*100);
                    end
                    evmdrs(e, i+(0:1)) = getPerSlotEVM(eqDrsSymbols, refDrsSymbols);
                    for k=0:1
                        fprintf('%s edge DRS EVM, slot %d: %0.3f%%\n',edge,(frc.NSubframe*2)+k,evmdrs(e,i+k).RMS*100);
                    end
                end
                
            end
            
        else
            ind = ltePUSCHIndices(frc, setfield(frc.PUSCH,'PRBSet',[])); %#ok<SFLD>
            drsInd = ltePUSCHDRSIndices(frc, setfield(frc.PUSCH,'PRBSet',[])); %#ok<SFLD>
        end
        
        % update EVM plots
        if (strcmpi(alg.EnablePlotting,'On'))
            updateEVMPlots();
        end
        
        % update subframe number.
        frc.NSubframe = mod(frc.NSubframe+1,10);
        
        % for each completed set of 20 slots, or at the end of a signal
        % shorter than 20 slots
        if (mod(i, 20)==19 || (nFrames==0 && i==nSlots-1))
            if (nFrames==0)
                slotrange = 1:nSlots;
                nFrame = 1;
            else
                slotrange = i-18:i+1;
                nFrame = floor((i+1)/20);
            end
            [frameEVM(nFrame), lowAvg, highAvg] = getFrameAverageEVM(evm(:, slotrange));
            if (lowAvg.RMS>highAvg.RMS)
                frameDrsEVM(nFrame) = lteEVM( ...
                    cat(1, evmdrs(1, slotrange).EV));
            else
                frameDrsEVM(nFrame) = lteEVM( ...
                    cat(1, evmdrs(2, slotrange).EV));
            end
            if (nFrames~=0)
                fprintf('Averaged low edge PUSCH EVM, frame %d: %0.3f%%\n', nFrame-1, lowAvg.RMS*100);
                fprintf('Averaged high edge PUSCH EVM, frame %d: %0.3f%%\n', nFrame-1, highAvg.RMS*100);
                fprintf('Averaged PUSCH EVM frame %d: %0.3f%%\n', nFrame-1, frameEVM(nFrame).RMS*100);
                fprintf('Averaged DRS EVM frame %d: %0.3f%%\n', nFrame-1, frameDrsEVM(nFrame).RMS*100);
            end
        end
    end
    
end

finalEVM = lteEVM(cat(1, frameEVM(1:end).EV));
fprintf('Averaged overall PUSCH EVM: %0.3f%%\n',finalEVM.RMS*100);
finalDrsEVM = lteEVM(cat(1,frameDrsEVM(1:end).EV));
fprintf('Averaged overall DRS EVM: %0.3f%%\n',finalDrsEVM.RMS*100);

% create array of plots
if (strcmpi(alg.EnablePlotting,'On'))
    plots = {evmSymbolPlot,evmSubcarrierPlot,evmRBPlot,evmGridFigure};
else
    plots = {};
end

    function updateEVMPlots()
        % build low and high edge EVM resource grids across all
        % subframes (for plotting)
        evmSubframeLow = lteULResourceGrid(frc,1);
        includeUnallocated = true; % include unallocated RBs in plots
        if (includeUnallocated)
            unallocRB = setdiff((0:frc.NULRB-1).',frc.PUSCH.PRBSet);
            unallocInd = ltePUSCHIndices(frc, setfield(frc.PUSCH,'PRBSet',unallocRB)); %#ok<SFLD>
            evmSubframeLow(unallocInd(:,1)) = abs(sum(rxGrid(unallocInd),2))*100;
            unallocDrsInd = ltePUSCHDRSIndices(frc, setfield(frc.PUSCH,'PRBSet',unallocRB)); %#ok<SFLD>
            evmSubframeLow(unallocDrsInd(:,1)) = abs(sum(rxGrid(unallocDrsInd),2))*100;
        end
        evmSubframeHigh = evmSubframeLow;
        evmSubframeLow(ind(:,1)) = abs(cat(1,evm(1,i+(0:1)).EV))*100;
        evmSubframeHigh(ind(:,1)) = abs(cat(2,evm(1,i+(0:1)).EV))*100;
        evmSubframeLow(drsInd(:,1)) = abs(cat(1,evmdrs(1,i+(0:1)).EV))*100;
        evmSubframeHigh(drsInd(:,1)) = abs(cat(2,evmdrs(1,i+(0:1)).EV))*100;
        evmGridLow = cat(2, evmGridLow, evmSubframeLow);
        evmGridHigh = cat(2, evmGridHigh, evmSubframeHigh);
        % the low or high edge timing is chosen for plotting
        % automatically based on whichever has the largest RMS across
        % all subframes
        evmMaxLow = max([evm(1,:).RMS]);
        evmMaxHigh = max([evm(2,:).RMS]);
        if (evmMaxLow > evmMaxHigh)
            evmGrid = evmGridLow;
            evmSubframe = evmSubframeLow;
        else
            evmGrid = evmGridHigh;
            evmSubframe = evmSubframeHigh;
        end
        % maximum EVM, used for plot limits scaling
        maxEVM = max(evmGrid(:));
        if (maxEVM==0)
            maxEVM = 1;
        end
        % plot EVM versus OFDM symbol
        evmSymbolRMS = sqrt(sum(evmSubframe.^2,1)./sum(evmSubframe~=0,1)).';
        evmSymbolPeak = (max(evmSubframe,[],1)./any(evmSubframe~=0,1)).';
        step(evmSymbolPlot,[evmSymbolRMS evmSymbolPeak]);
        evmSymbolPlot.YLimits = [0 maxEVM*1.1];
        % plot EVM versus subcarrier
        evmSubcarrierRMS = sqrt(sum(evmGrid.^2,2)./sum(evmGrid~=0,2));
        evmSubcarrierPeak = max(evmGrid,[],2)./any(evmGrid~=0,2);
        step(evmSubcarrierPlot,[evmSubcarrierRMS evmSubcarrierPeak]);
        evmSubcarrierPlot.YLimits = [0 maxEVM*1.1];
        % plot EVM versus resource block
        evmRBRMS = zeros(frc.NULRB,1);
        evmRBPeak = evmRBRMS;
        for rb = 0:frc.NULRB-1
            rbGrid = evmGrid(rb*12 + (1:12),:,:);
            evmRBRMS(rb+1) = sqrt(sum(rbGrid(:).^2)./sum(rbGrid(:)~=0));
            evmRBPeak(rb+1) = max(rbGrid(:))./any(rbGrid(:)~=0);
        end
        step(evmRBPlot,[[evmRBRMS; evmRBRMS(end)] [evmRBPeak; evmRBPeak(end)]]);
        evmRBPlot.YLimits = [0 maxEVM*1.1];
        % plot EVM resource grid
        evmGridFigure = hEVMPlots(evmGridFigure, evmGrid);
        evmGridFigure.CurrentAxes.ZLim = [0 maxEVM*1.1];
    end

end

%getPerSlotEVM EVM per slot
%   EVM = getPerSlotEVM(X,R) is the EVM per slot
%   given a subframe worth of received symbols X and reference symbols R

function evm = getPerSlotEVM(x,r)

evm = repmat(lteEVM([]), 1, 2);
mid = length(x)/2;
for k = 0:1
    if (k==0)
        % Calculate EVM of first slot
        evm(k+1) = lteEVM(x(1:mid,:), r(1:mid,:));
    else
        % Calculate EVM of second slot
        evm(k+1) = lteEVM(x(mid+1:end,:), r(mid+1:end,:));
    end
end

end

%getFrameAverageEVM Frame averaged EVM
%   [EVMOUT,LOWAVG,HIGHNAVG] =
%   getFrameAverageEVM(EVMIN) provides the
%   averaged error vector in three structures given a
%   structure array containing normalized error vectors:
%     LOWAVG is the low edge EVM average.
%     HIGHAVG is the high edge EVM average.
%     EVMOUT is the largest of the two.
%   EVMIN is a structure array containing the low and high edge normalized
%   error vectors.

function [evmout,lowavg,highnavg] = getFrameAverageEVM(evmin)

lowavg = lteEVM(cat(1, evmin(1, :).EV));    % Low edge average
highnavg = lteEVM(cat(1, evmin(2, :).EV));  % High edge average

% EVMOUT is the greater of the high and low edge averages
if (lowavg.RMS > highnavg.RMS)
    evmout = lowavg;
else
    evmout = highnavg;
end

end

%getEVMWindow EVM window
%   W = getEVMWindow(FRC) is the error vector
%   magnitude window, W, for a fixed reference channel, FRC.
%
%   NOTE: W for bandwidth 15MHz has been scaled because the LTE System
%   Toolbox(TM) uses 2048-point FFT for 15MHz rather than 1536-point.

function w = getEVMWindow(frc)

% Numbers of uplink resource blocks
nrbs = [6 15 25 50 75 100];

% EVM window lengths W for normal CP
Ws = [5 12 32 66 136 136];

% EVM window lengths W for extended CP
if (isfield(frc, 'CyclicPrefixUL'))
    if(strcmpi(frc.CyclicPrefixUL, 'Extended'))
        Ws = [28 58 124 250 504 504];
    end
else
    frc.CyclicPrefixUL='Normal';
end

% Get corresponding EVM window length for NULRB; if NULRB is
% non-standard, use FFT size to determine the EVM window length
if (isempty(find(frc.NULRB==nrbs,1)))
    Nffts = [128 256 512 1024 2048];
    scfdmaInfo = lteSCFDMAInfo(frc);
    w = Ws(double(scfdmaInfo.Nfft)==Nffts);
else
    w = Ws(frc.NULRB==nrbs);
end

end

% Estimates the average frequency offset by means of estimation of the
% phase shift between channel estimate REs in the locations of successive
% PUSCH Demodulation Reference Signal (DRS) symbols.  The approach used
% follows Equation 14 of Speth, M.; Fechtel, S.; Fock, G.; Meyr, H.,
% "Optimum receiver design for OFDM-based broadband transmission .II. A
% case study," Communications, IEEE Transactions on , vol.49, no.4,
% pp.571,578, Apr 2001. Note that the splitting of the estimate into left
% and right halfs is not performed, as the PUSCH resource allocation is not
% guaranteed to be symmetrical; this means that the resulting frequency
% offset estimate maybe be biased by any sampling clock offset present, but
% the effect is expected to be small.
function foffset = frequencyOffsetPUSCHDRS(ue,pusch,cec,rxgrid)

% If the 'TestEVM' channel estimator is specified, use 1x1 pilot
% averaging instead. The 'TestEVM' channel estimator gives the same
% channel estimate across all SC-FDMA symbols which makes it
% unsuitable, because the technique here relies on an estimate of the
% phase shift across SC-FDMA symbols.
if (strcmpi(cec.PilotAverage,'TestEVM'))
    cec.PilotAverage = 'UserDefined';
    cec.FreqWindow = 1;
    cec.TimeWindow = 1;
    cec.Reference = 'Antennas';
    cec.InterpType = 'cubic';
end

% perform channel estimation
hest = lteULChannelEstimate(ue,pusch,cec,rxgrid);

% set some housekeeping variables
dims = lteULResourceGridSize(ue);
L = dims(2);
nsf = floor(size(hest,2)/L);
startsf = ue.NSubframe;

% for each receive antenna:
for r = 1:size(hest,3)
    
    % for each transmit antenna:
    for p = 1:size(hest,4)
        
        % for each subframe:
        for i = 0:nsf-1
            
            xsf = [];
            ue.NSubframe = mod(startsf+i,10);
            
            % extract the current subframe of the channel estimate
            hsubframe = hest(:,(i*L)+(1:L),r,p);
            
            % extract the channel estimate REs in the location of the
            % PUSCH demodulation reference signal
            drsind = ltePUSCHDRSIndices(setfield(ue,'NTxAnts',1),pusch); %#ok<SFLD>
            hdrs = hsubframe(drsind);
            
            % establish the set of frequency indices 'kset' occupied by
            % the PUSCH demodulation reference signal
            drssub = ltePUSCHDRSIndices(setfield(ue,'NTxAnts',1),pusch,'sub'); %#ok<SFLD>
            kset = double(unique(drssub(:,1)));
            
            % for each frequency index:
            for kidx = 1:length(kset)
                
                % calculate the correlation 'x' between the two
                % occurrences of the PUSCH demodulation reference
                % signal in this frequency index and store it in the
                % vector 'xsf' of all correlations for this subframe.
                % The spacing in SC-FDMA symbols 'delta_l' is also
                % calculated.
                k = kset(kidx);
                thisidx = (drssub(:,1)==k);
                thisl = drssub(thisidx,2);
                delta_l = double(diff(thisl));
                h = hdrs(thisidx);
                x = h(2)*conj(h(1));
                xsf = [xsf x]; %#ok<AGROW>
                
            end
            
        end
        
    end
    
end

% compute SC-FDMA symbol length 'N' and cyclic prefix length 'Ng'
scfdmaInfo = lteSCFDMAInfo(ue);
N = double(scfdmaInfo.Nfft);
Ng = double(scfdmaInfo.CyclicPrefixLengths(2));

% compute frequency offset estimate based on the phase shift across the
% number of SC-FDMA symbols give by 'delta_l'.
delta_f_tilde = 1/(2*pi*delta_l*(1+Ng/N))*(angle(sum(xsf)));
foffset = delta_f_tilde*15000;

end

% Creates a reference waveform for IQ offset estimation by creating a
% channel estimate which removes the majority of the influence of the DC
% offset and applying this channel estimate to the known reference symbols
% and then generating the corresponding time-domain waveform. The DC offset
% adds a bias to all subcarriers due to the DFT spreading, but the effect
% is concentrated around the center of the spectrum, so here the central 2
% resource blocks are removed from the channel estimate and this region is
% linearly interpolated. This should result in a channel estimate that is
% close to the true channel and has most of the effect of the DC offset
% removed. After SC-FDMA modulation of the reference symbols multiplied by
% this channel estimate, the output 'refWaveform' should be very similar to
% the received signal but with the DC offset removed and therefore we can
% subtract 'refWaveform' from the received signal and calculate the mean in
% order to estimate the DC offset.
function refwaveform = iqOffsetChEstWaveform(ue,pusch,rxgrid,refgrid)

% Create a channel estimator configuration that uses linear
% interpolation and does not internally generate DRS reference symbols.
cec.PilotAverage = 'UserDefined';
cec.FreqWindow = 3;
cec.TimeWindow = 29;
cec.InterpType = 'linear';
cec.Reference = 'None';

% Create the PUSCH DRS and its indices.
refDrsSymbols = ltePUSCHDRS(ue, pusch);
drsInd = ltePUSCHDRSIndices(setfield(ue,'NTxAnts',1), pusch); %#ok<SFLD>

for p = 1:size(refDrsSymbols,2)
    % Create channel estimate by removing reference symbols near DC and
    % then interpolating across them; this removes the majority of the
    % influence of the DC offset.
    refgridNoOffset = refgrid(:,:,p);
    refgridNoOffset(drsInd) = refDrsSymbols(:,p);
    refgridNoOffset(size(refgrid,1)/2 + (-11:12),:) = NaN;
    Hest = lteULChannelEstimate(ue, pusch, cec, rxgrid(:,:,p), refgridNoOffset);
    
    % Create reference signal by modulating reference symbols with
    % channel estimate that has DC offset removed
    refgridNoOffset = refgrid(:,:,p);
    refgridNoOffset(drsInd) = refDrsSymbols(:,p);
    refgridNoOffset(isnan(refgridNoOffset)) = 0;
    refwaveform(:,p) = lteSCFDMAModulate(ue, refgridNoOffset.*Hest); %#ok<AGROW>
end

end
