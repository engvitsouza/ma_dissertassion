function indexes = lte_range_of_REs(Nrb)

% Number of resource block options
NrbOptions 		= [6 15 25 50 75 100];

% (I)FFT size options
FFT_size_Options 		= [128 256 512 1024 1536 2048];

option=find(NrbOptions==Nrb);
if(isempty(option))
    err_str= sprintf('%s%s','Nrb is not a valid number or resource block: ', ...
        num2str(NrbOptions));
    error(err_str );
end

% fft_size

fft_size = FFT_size_Options(option);

% Number of subcarriers per resource block
N_sc_rb         = 12;

% number of subcarrier per OFDM symbol
Nsc         = Nrb*N_sc_rb;

% DC is not used by LTE
% half of Resource ELements (REs) are located below DC
% and half of REs are located above DC
% so index 1 (DC) is not used
% fomr fft_size-(Nsc/2)+1:fft_size (Negative bins)
% from 2 until Nsc/2 (positive bins)
indexes = [fft_size-(Nsc/2)+1:fft_size 2:(Nsc/2+1)];

end