% lte_plot_tx_vs_rx shows some result of EVM, SNR and PSD of TX ans RX
% signal.
%
% usage: lte_plot_tx_vs_rx(signal,signal_rx,Nrb,cp_type,frame_to_plot,slot_to_plot)
% 
% SIGNAL is the tx signal
% SIGNAL_RX is the rx signal
% NRB number of resource block of the signal: 6, 15, 25, 50, 75  or 100
% FRAME_TO_PLOT some plots show the EVM and SNR of the given frame, put 0
% if you are not sure which is the value
% SLOT_TO_PLOT some plots show the EVM and SNR of the given frame, put 0
% if you are not sure which is the value
function lte_plot_tx_vs_rx(signal,signal_rx,Nrb,cp_type,frame_to_plot,slot_to_plot)
%% LTE plots
% Nrb=100;            % Number of resource block of signal: [6 15 25 50 75 100]
% cp_type = 'normal'; % Cyclic prefix type: 'normal' or extended
% 
% frame_to_plot   = 0;
% slot_to_plot    = 0;

enb=lte_DLPHYparam(Nrb,cp_type);
number_of_frames = length(signal)/enb.samplesPerFrame;

%% plots configs
plot_colors     = ['rgbkymcr'];
plot_markers    = ['o+*sxdv.'];
set(0,'DefaultAxesFontSize', 18);
lineWidth = 2;
MarkerSize = 12;

%% calculations and plots

if 1 %This block uses the matlab lte toolbox
    enb_param.NDLRB         = enb.Nrb;
    enb_param.CyclicPrefix  = cp_type;
    lte_tx_grid = lteOFDMDemodulate(enb_param,signal(:));
    lte_rx_grid = lteOFDMDemodulate(enb_param,signal_rx(:));
    evms        = lte_evm_annexE_36104(lte_rx_grid,lte_tx_grid);
    
    figure;
    plot(evms(:)*100);
    ylabel('EVM(%)');
    xlabel('Number of subframe-resourseblock');
    
    figure;
    plot(evms*100);
    ylabel('EVM(%)');
    xlabel('Resource block number (Frequency)');
    title('EVM per resource block. Each line is a subframe');
    
    delta_evm_hist = (max(evms(:))*100 - min(evms(:)*100))/100;
    [N_evms,C_evms]=hist(evms(:)*100,min(evms(:)*100):delta_evm_hist:max(evms(:)*100));
    figure;
    plot(C_evms,N_evms,'LineWidth',lineWidth);
    xlabel('EVM (%)');
    %ylabel('Count');
    title(sprintf('Histogram of %d EVMs',sum(N_evms)));
end %This is the end of block that uses the matlab lte toolbox

if 1
    EVMs_all=zeros(enb.N_dl_symb,20,number_of_frames);
    SNRs_all=zeros(enb.N_dl_symb,20,number_of_frames);
    for i=1:number_of_frames
        EVMs_all(:,:,i) = lte_EVMPerOFDMSymbol(signal(:),signal_rx(:),Nrb,cp_type,i-1);
        SNRs_all(:,:,i) = lte_SNRPerOFDMSymbol(signal(:),signal_rx(:),Nrb,cp_type,i-1);
    end
end

%%
%this will plot the EVM of first slot
lte_SNRPerOFDMSymbol(signal,signal_rx,Nrb,cp_type,frame_to_plot,slot_to_plot,1);

ofdm_symbols = 0:enb.SymbolPerFrame-1;

% Get SNR and EVM of each OFDM symbols
lteSNRs_td  = lte_SNRPerOFDMSymbol(signal,signal_rx,Nrb,cp_type,frame_to_plot);
EVMs        = lte_EVMPerOFDMSymbol(signal,signal_rx,Nrb,cp_type,frame_to_plot);
lteSNRs_freq_domain = 20*log10(1./EVMs(:));

figure;
plot(ofdm_symbols,EVMs(:)*100,'LineWidth',lineWidth,'MarkerSize', MarkerSize)
xlabel('OFDM symbol');
ylabel('EVM(%)');
title(sprintf('EVMs of QAM symbols (Freq. domain). Frame %d',frame_to_plot));
set(gca,'xtick',[0:enb.N_dl_symb:enb.SymbolPerFrame]);
grid on;

figure;
plot(ofdm_symbols,lteSNRs_td(:),'LineWidth',lineWidth,'MarkerSize', MarkerSize)
xlabel('OFDM symbol');
ylabel('SNR(dB)');
title(sprintf('SNR of time domain samples. Frame %d',frame_to_plot));
set(gca,'xtick',[0:enb.N_dl_symb:enb.SymbolPerFrame]);
grid on;

figure;
plot(ofdm_symbols,lteSNRs_freq_domain,'LineWidth',lineWidth,'MarkerSize', MarkerSize)
xlabel('OFDM symbol');
ylabel('SNR(dB)');
title(sprintf('SNR of frequency domain. Frame %d',frame_to_plot));
set(gca,'xtick',[0:enb.N_dl_symb:enb.SymbolPerFrame]);
grid on;
%% PSD calculation
noise = signal-signal_rx;
f = [-enb.FFT_size/2 : enb.FFT_size/2-1]*enb.Fs_MHz/enb.FFT_size;
[psd_signal,w]  = pwelch(signal,enb.FFT_size);
[psd_yquant,]   = pwelch(signal_rx,enb.FFT_size);
[psd_noise,]    = pwelch(noise,enb.FFT_size);
SNRfd_from_psd  = psd_signal./psd_noise;

lte_signal_mask = zeros(enb.FFT_size,1);
lte_signal_mask(:) = -80;
lte_signal_mask([1:enb.Nsc/2]+1)=-50;
lte_signal_mask(enb.FFT_size-enb.Nsc/2:end)=-50;

figure;
plot(f,10*log10(fftshift(psd_signal)),'-b',...
    f,10*log10(fftshift(psd_yquant)),'--g',...
    f,10*log10(fftshift(psd_noise)),'-r',...
    f,fftshift(lte_signal_mask),'--k',...
    'LineWidth',lineWidth,'MarkerSize', MarkerSize);

xlim([f(1) f(end)]);
xlabel('Frequency (MHz)');
ylabel('PSD (dB/Hz)');
title('Power Spectral Density estimation');
legend('LTE signal','LTE signal quantized','Quantization noise','OFDMA (LTE) mask');

%% prints
disp('------------------------EVM as in Annex E 36.104');
disp(sprintf('%30s: %.4f','maximun EVM Annex E 36.104',max(evms(:))*100));
disp(sprintf('%30s: %.4f','average EVM Annex E 36.104',mean(evms(:))*100));
disp(sprintf('%30s: %.4f','minimum EVM Annex E 36.104',min(evms(:))*100));
disp('------------------------------------------------');
disp('------------------------EVM Per OFDM symbol');
disp(sprintf('%30s: %.4f','maximun EVM per OFDM symbol',max(EVMs_all(:))*100));
disp(sprintf('%30s: %.4f','average EVM per OFDM symbol',mean(EVMs_all(:))*100));
disp(sprintf('%30s: %.4f','minimum EVM per OFDM symbol',min(EVMs_all(:))*100));
disp('------------------------------------------------');
disp('------------------------SNR Per OFDM symbol');
disp(sprintf('%30s: %.4f','maximun SNR per OFDM symbol',max(SNRs_all(:))));
disp(sprintf('%30s: %.4f','average SNR per OFDM symbol',mean(SNRs_all(:))));
disp(sprintf('%30s: %.4f','minimum SNR per OFDM symbol',min(SNRs_all(:))));
disp('------------------------------------------------');
end