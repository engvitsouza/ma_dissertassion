% This code is a modified version of the codes in links below:
% http://www.mathworks.com/help/lte/examples/lte-downlink-channel-estimation-and-equalization.html
% http://www.sharetechnote.com/html/lte_toolbox/Matlab_LteToolbox_TimeDomain.html
% [1] http://www.mathworks.com/help/lte/examples/lte-waveform-modeling-using-downlink-transport-and-physical-channels.html
%
% This code requires the LTE toolbox of MATLAB
%
%
close all; clear;
%% General settings
% Create a LTE signal with NFrames
% Number of LTE frames
NFrames = 4;

% Choose file path of the output files
file_bin_path   = '../LTEsignals/s_25RBs/';

% The complex time domain signal is saved in four files. 
% 1 file for real and 1 file for imag. component of LTE signal without 
% Cyclic prefix (cpless in filename)
% 1 file for real and 1 file for imag. component of LTE signal with Cyclic 
% prefix
% Besides these fou files, one .mat file with all variables is also saved
% For example, with *file_output_name= 's_64QAM_20MHz'*, the output files 
% are named: (Without CP) s_64QAM_20MHz_cpless_real.dat and
% s_64QAM_20MHz_cpless_imag.dat, (With CP) s_64QAM_20MHz_real and
% s_64QAM_20MHz_imag.dat, and (all variables) s_64QAM_20MHz.mat.
file_output_name= 's_25RBs';

% Select if the signal must be saved, 0=>do not save, 1=>save files 
save_signal_in_a_file = 1;
%% Cell-Wide Settings

% Modulation used in each RE of PDSCH
% 'QPSK', '16QAM' or '64QAM'
Modulation = 'QPSK';

% Select the number of resource block (Bandwidth)
% 100   : BW=  20 MHz : Fs= 30.72 MHz
% 75    : BW=  15 MHz : Fs= 23.04 MHz
% 50    : BW=  10 MHz : Fs= 15.36 MHz
% 25    : BW=   5 MHz : Fs=  7.68 MHz
% 15    : BW=   3 MHz : Fs=  3.84 MHz
% 6     : BW= 1.4 MHz : Fs=  1.92 MHz
enb.NDLRB           = 25;          % Number of resource blocks


enb.CellRefP        = 1;            % One transmit antenna port
enb.NCellID         = 0;%randi([0 503],1);            % Cell ID
enb.CyclicPrefix    = 'Normal';     % Normal cyclic prefix
enb.CFI             = 1;
enb.Ng              = 'Sixth';
enb.PHICHDuration   = 'Normal';
enb.NFrame          = 0;
enb.NSubframe       = 0;
enb.DuplexMode      = 'FDD';

% Windowing default is 4. The spectrum of an 
% OFDM signal shows spectral spikes that are caused by the discontinuity 
% between two OFDM symbols during signal generation. Windowinfg avoid these
% spikes, but the tx signal is distorced from ideal (QAM points are
% distorced). 
% See: http://www.rohde-schwarz.com/en/applications/smooth-your-lte-signal-application-card_56279-4745.html
enb.Windowing=0;

% Number of filled resource blocks, or physical resource blocks. When N_RB
% is lower than enb.NDLRB, cell load can be considered lower.
N_RB = enb.NDLRB; % all resource block filled with data
%N_RB = 10; % only 10 Resource block out of enb.NDLRB.
%% Frame Generation

% TODO: compare this code with [1]

txGrid = [];

% For all subframes within the frame + 1 (10 subframes + 1 subframe)
% When the OFDM modulated time domain waveform is passed through a channel 
% the waveform will experience a delay. To avoid any samples being missed 
% due to this delay an extra subframe is generated, therefore 11 subframes 
% are generated in total. 
for sf = 0:NFrames*10-1

    % Set subframe number
    enb.NSubframe = mod(sf,10);

    % Set Frame number
    NFrame      = fix(sf/10);
    enb.NFrame  = NFrame;
    
    % Generate empty resource grid fot one subframe
    sf_resourceGrid = lteDLResourceGrid(enb);
    
    % Now populate all the information in DCI field as you like. 
    % Understanding details of DCI is also pretty huge topics. 
    
    % Select an arbitrary IMCS according to the modulation and "
    % Table 7.1.7.1-1: Modulation and TBS index table for PDSCH" of 3GPP 36.213
    % I_TBS is proportional to I_MCS as indicated in the table
    if strcmpi(Modulation,'256QAM')
        % for 256 QAM the range is 20 to 27, see table 7.1.7.1-1A of 36.213
        % Release 12
        % TODO: Note that for using 256 QAM, other parameters of higher 
        % layers must be edited in order to PHY layer send data from higher
        % layers properly
        I_MCS = 24;
        I_TBS = 30; 
    elseif strcmpi(Modulation,'64QAM')
        % for 64 QAM the range is 17 to 28, see table 7.1.7.1-1 of 36.213
        I_MCS = 21;
        I_TBS = I_MCS -2; 
    elseif strcmpi(Modulation,'16QAM')
        % for 16 QAM the range is 10 to 16, see table 7.1.7.1-1 of 36.213
        I_MCS = 13;
        I_TBS = I_MCS -1;
    elseif strcmpi(Modulation,'QPSK')
        % for QPSK the range is 10 to 16, see table 7.1.7.1-1 of 36.213
        I_MCS = 6;
        I_TBS = I_MCS;
    else
        error('Select a valid modulation scheme');
    end
    
    % Select which RB is the first (from 0 to enb.NDLRB-1)
    START_RB    = 0;
    dciFormat   = 'Format1A';   
    %TODO: check the following function
    riv         = lte_calc_riv(enb.NDLRB,N_RB,START_RB,dciFormat); 
    
    dci.NDLRB = enb.NDLRB;
    dci.DCIFormat = dciFormat;
    dci.AllocationType = 0;
    dci.Allocation.RIV = riv; 
    dci.ModCoding = I_MCS;
    dci.HARQNo = 0;
    dci.NewData = 0;
    dci.TPCPUCCH = 0;
    dci.DuplexMode = 'FDD';
    dci.NTxAnts = 1;
    
    % once you defined all the detailed fields of DCI, just pass it to 
    % lteDCI() function with eNB info as follows, then you will get the bit
    % stream for the DCI.
    [dciMessage,dciMessageBits] = lteDCI(enb,dci);
    %disp(sprintf('%d',dciMessageBits));
    %disp('\n');
    
    % for this step, you need to set a couple of additional parameters as 
    % shown below.
    % C_RNTI will be XORed to CRC bits
    % PDCCHFormat will determined Aggregation Level.
    %          PDCCHFormat 0 indicate Aggregation Level 1
    %          PDCCHFormat 1 indicate Aggregation Level 2
    %          PDCCHFormat 2 indicate Aggregation Level 4
    %          PDCCHFormat 3 indicate Aggregation Level 8
    C_RNTI = 100;
    pdcchConfig.RNTI = C_RNTI;
    pdcchConfig.PDCCHFormat = 0;
    
    % then pass dciMessageBits and pdcchConfig to lteDCIEncode, then you
    % would get the encoded bitstream.
    codedDciBits = lteDCIEncode(pdcchConfig, dciMessageBits);
    
    % If you pass the enb into ltePDCCHInfo() function, it will give you 
    % the amount of resources that can be allocated for PDCCH allocation. 
    % This is not the amount of resource for only one DCI. It will give you 
    % the total/maximum amount of the resources that can be allocated for 
    % PDCCH.
    pdcchDims = ltePDCCHInfo(enb);
    
    % With ltePDCCHSpace, you can get the list of all the possible spaces 
    % that can carry PDCCH.
    % In this example, the space were shown in the unit of bits.
    pdcchBits = -1*ones(pdcchDims.MTot, 1);
    
    % generate an array with the length that can accommodate all the 
    % possible PDCCH bits.
    candidates = ltePDCCHSpace(enb, pdcchConfig, {'bits', '1based'});
    
    % select one of the candidate bitSection and assign the codedDcitBits. 
    % You can select any candidate bit section, but in this example, 
    % I selected the first candidate section.
    pdcchBits ( candidates(1, 1) : candidates(1, 2) ) = codedDciBits;
    
    % if pass the encodedBits into ltePDCCH(), it will generate the 
    % modulated physical layer symbols.
    pdcch_sym = ltePDCCH(enb, pdcchBits);
    pdcch_sym_ind = ltePDCCHIndices(enb,{'1based','re'});
    pdcch_sym_arrayIndex = 0:length(pdcch_sym)-1;
    
    % Now we set various parameters defining PDSCH channel. 
    % (In real transmission, you would need to create a dci that is 
    % corresponding the configuration here. But in this example, I will go 
    % without defining DCI)
    pdsch.NTxAnts = 1;
    pdsch.NLayers = 1;
    pdsch.TxScheme = 'Port0';
    pdsch.Modulation = Modulation;
    pdsch.RV = 0;
    pdsch.RNTI = C_RNTI;
    
    
    
    pdsch_prbs = (START_RB:(START_RB+N_RB-1)).';
    
    % Find the transport block size according to the table 7.1.7.2.1-1 of 
    % 3GPP 36.213
    transportBlkSize = lteTBS(N_RB,I_TBS);
    
    % Now we have to generate a bit sequence which would exactly fit to the 
    % number of resource elements that are allocated for PDSCH for this 
    % specific subframe.
    % To figure out exact Resource Element information, unlike in other 
    % channel processing, I would run ltePDSCHIndices() first. As you see 
    % in the following code, ltePDSCHIndices() returns the information that
    % would give you the size of transport block size in the unit of bits.
    [pdsch_sym_ind,pdschIndInfo] = ltePDSCHIndices(enb,pdsch,pdsch_prbs,{'1based','re'});
    % pdschIndInfo.G is the total available PDSCH bits
    codedTrBlkSize = pdschIndInfo.G;
    
    % TODO: create uncoded bits and code them with lte_DLSCH. See [1].
    % TODO: Comparing this with [1], I think the line below is wrong. The
    % codedTrBlkSize is much higher than TrBlkSize.
    % Now I would create a bit array that carries the user data. In this 
    % example, I generated randomly but in real situation, this would carry
    % your user data (e.g, image, movie, files etc)
    dlschTransportBlk = round(rand(1,transportBlkSize));
    
    % now if you pass all the information to lteDLSCH), it will generate 
    % the encoded codeword data for the transport block you defined.
    codeword = lteDLSCH(enb,pdsch,codedTrBlkSize,dlschTransportBlk);
    
    % now if you pass the encoded data (codeword) with eNB and pdsch config 
    % to ltePDSCH(), you can generate physical layer symbols for 
    % the encoded data.
    pdsch_sym = ltePDSCH(enb,pdsch,codeword);
    pdsch_sym_arrayIndex = 0:length(pdsch_sym)-1;
    
    % Following is to create an empty resource grid for one subframe.
    %resourceGrid = lteDLResourceGrid(enb);
    
    % Create symbols for Cell Specific Reference Signal 
    % and make a list of resource index for the reference signal.
    rsAnt0 = lteCellRS(enb,0);
    indAnt0 = lteCellRSIndices(enb,0);
    sf_resourceGrid(indAnt0) = rsAnt0;
    
    % Create symbols for PBCH and make a list of resource index for the 
    % signal (channel).
    mib_bits = lteMIB(enb);
    bch_cw = lteBCH(enb,mib_bits);
    
    pbch_sym = ltePBCH(enb,bch_cw);
    pbch_sym_arrayIndex = 0:length(pbch_sym)-1;
    pbch_sym_ind = ltePBCHIndices(enb,{'1based','re'});
    
    % Create symbols for PSS and make a list of resource index for the signal
    pss = ltePSS(enb);
    pss_arrayIndex = 0:length(pss)-1;
    pss_sym_ind = ltePSSIndices(enb,0,{'1based','re'});
    
    % Create symbols for SSS and make a list of resource index for the signal
    sss = lteSSS(enb);
    sss_arrayIndex = 0:length(sss)-1;
    sss_sym_ind = lteSSSIndices(enb,0,{'1based','re'});
    
    % Create symbols for PCFICH and make a list of resource index for the signal
    cfi_cw = lteCFI(enb);
    pcfich_sym = ltePCFICH(enb,cfi_cw);
    pcfich_sym_arrayIndex = 0:length(pcfich_sym)-1;
    pcfich_sym_ind = ltePCFICHIndices(enb,{'1based','re'});
    
    % Create symbols for PHICH and make a list of resource index for the signal
    PHICH_Group_Index = 0;
    PHICH_Sequence_Index = 1;
    HARQ_Indicator_Value = 0; % 0 = NACK, 1 = ACK
    
    phich_sym = ltePHICH(enb,[PHICH_Group_Index,PHICH_Sequence_Index,HARQ_Indicator_Value]);
    phich_sym_arrayIndex = 0:length(phich_sym)-1;
    phich_sym_ind = ltePHICHIndices(enb,{'1based','re'});
    
    % Following part is filling the resource grid with each of the signal.. but if you see carefully I didn't fill this
    % with real symbol number, I just filled it with a constant that I arbitrarily set. This is just for visualization..
    % just to allocate constant/outstanding color for each signal. When you  use this resource grid for real
    % transmission (not for visualization), fill the resourceGrid with real symbol value you generated above.
    if 0
        pss_scale = 0.2;
        sss_scale = 0.4;
        phich_scale = 0.7;
        pcfich_scale = 0.5;
        pbch_scale = 0.7;
        pdcch_scale = 0.9;
        pdsch_scale = 0.6;
    else
        pss_scale       = 1;
        sss_scale       = 1;
        phich_scale     = 1;
        pcfich_scale    = 1;
        pbch_scale      = 1;
        pdcch_scale     = 1;
        pdsch_scale     = 1;
    end
    
    sf_resourceGrid(pss_sym_ind)    = pss_scale .* pss;
    sf_resourceGrid(sss_sym_ind)    = sss_scale .* sss;
    sf_resourceGrid(pcfich_sym_ind) = pcfich_scale .* pcfich_sym;
    sf_resourceGrid(phich_sym_ind)  = phich_scale .* phich_sym;
    sf_resourceGrid(pbch_sym_ind)   = pbch_scale .* pbch_sym(1:length(pbch_sym_ind));
    sf_resourceGrid(pdcch_sym_ind)  = pdcch_scale .* pdcch_sym;
    sf_resourceGrid(pdsch_sym_ind)  = pdsch_scale .* pdsch_sym;
    

    % Append subframe to grid to be transmitted
    % Note that when using e.g. 25 RBs (BW = 5 MHz), the dimension of
    % sf_resourceGrid � 300 x 14, corresponding to 300 subcarriers
    % for this subframe, and each subframe has 2 slots, with 7 symbols each
    txGrid = [txGrid sf_resourceGrid]; %#ok

end
%% OFDM Modulation

% txWaveform is the resulting time domain waveform. Each column contains 
% the time domain signal for each antenna port.
[txWaveform,info] = lteOFDMModulate(enb,txGrid);

%% remove CP
lte_signal_param        = lte_DLPHYparam(enb.NDLRB,enb.CyclicPrefix);
fft_size                = lte_signal_param.FFT_size;
Number_of_OFDM_symbol   = NFrames*lte_signal_param.SymbolPerFrame;
OFDM_symbols_per_Slot   = lte_signal_param.N_dl_symb;
lte_signal_cp_less      = zeros(fft_size,Number_of_OFDM_symbol);

for slot_number=1:20*NFrames; %20 slots per frame: 10 subframes, with 2 slots per subframe

% Get the slot from lte signal
slot = lte_get_slot_ofdma_td_from_frame_lte(...
    txWaveform,slot_number-1,lte_signal_param.cp_0_length,...
    lte_signal_param.cp_else_length,OFDM_symbols_per_Slot,fft_size);

% Calculate the indexes of each OFDM symbol
ind_ofdm_from   = (slot_number-1)*OFDM_symbols_per_Slot+1;
ind_ofdm_to     = (slot_number-1)*OFDM_symbols_per_Slot+OFDM_symbols_per_Slot;
% disp(['from ' num2str(ind_ofdm_from) ' to ' num2str(ind_ofdm_to)]);

lte_signal_cp_less(:,ind_ofdm_from:ind_ofdm_to)=...
     lte_get_symbols_ofdm_td_from_slot_lte(slot,enb.NDLRB,enb.CyclicPrefix);
end
%% save signal in a file
if (1==save_signal_in_a_file)
    file_output_name_mat        = [file_bin_path file_output_name];
    file_output_name_bin_real   = [file_bin_path file_output_name '_real.dat'];
    file_output_name_bin_imag   = [file_bin_path file_output_name '_imag.dat'];
    file_output_cpless_name_bin_real   = [file_bin_path file_output_name '_cpless_real.dat'];
    file_output_cpless_name_bin_imag   = [file_bin_path file_output_name '_cpless_imag.dat'];
    
    if ~exist(file_bin_path, 'dir')
        mkdir(file_bin_path);
    end

    % save .mat
    save(file_output_name_mat);
    
    fp_real=fopen(file_output_name_bin_real,'wb');
    fp_imag=fopen(file_output_name_bin_imag,'wb');
    fp_cpless_real=fopen(file_output_cpless_name_bin_real,'wb');
    fp_cpless_imag=fopen(file_output_cpless_name_bin_imag,'wb');
    
    fwrite(fp_real,real(txWaveform),'float');
    fwrite(fp_imag,imag(txWaveform),'float');
    fwrite(fp_cpless_real,real(lte_signal_cp_less(:)),'float');
    fwrite(fp_cpless_imag,imag(lte_signal_cp_less(:)),'float');

    fclose(fp_real);
    fclose(fp_imag);
    fclose(fp_cpless_real);
    fclose(fp_cpless_imag);
    
    disp(['Wrote files in ' file_bin_path]);
end
%% plots
lte_plotOFDMSymbols(txWaveform,enb.NDLRB,enb.CyclicPrefix,0,0);