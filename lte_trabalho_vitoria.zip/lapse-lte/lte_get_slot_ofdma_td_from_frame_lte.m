% LTE_GET_SLOT_OFDMA_TD_FROM_FRAME_LTE return a given slot of a frame LTE.
%
% lte_get_slot_ofdma_td_from_frame_lte(...
% x,slot_number,N_cp_l_0,N_cp_l_else,N_dl_symb,FFT_size)
%
% X is a LTE frame
% SLOT_NUMBER  number of slot greater or equals to zero
% N_CP_L_0 Number of samples in first OFDM symbol
% N_CP_L_ELSE Number of samples in CP of the remaining OFDM symbol
% N_DL_SYMB Number of OFDM symbols in a slot
% FFT_SIZE Number of samples in a OFDM symbol without CP
%
% see lte_DLPHYparam to get the parameters listed above
%
function slot_ofdma = lte_get_slot_ofdma_td_from_frame_lte(x,slot_number,N_cp_l_0,N_cp_l_else,N_dl_symb,FFT_size);

slot_length=(N_cp_l_0+FFT_size)+(N_dl_symb-1)*(N_cp_l_else+FFT_size);

from_sample = slot_number*slot_length+1;
to_sample   = (slot_number+1)*slot_length;
%disp(sprintf(' %d - %d',from_sample,to_sample));
slot_ofdma=x(from_sample:to_sample);
