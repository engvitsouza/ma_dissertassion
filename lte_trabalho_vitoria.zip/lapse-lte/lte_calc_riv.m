% This function calculates the  resource indication value (RIV). For more
% Information see 7.1.6.3 of 36.213
%
% N_DL_RB  number of Resource blocks available for current BW. One of
% the following values: 6 15 25 50 75 100
%
% L_CRBS number of continuos virtually contiguously allocated resource
% blocks
%
% RB_START where the first RB must be positioned. A number between 0 and
% N_DL_RB-L_CRBS
%
% dciFormat is 'Format1A', 'Format1B', 'Format1C' or 'Format1D'
%
function riv= lte_calc_riv(N_DL_RB,L_CRBS,RB_START,dciFormat)
    if(RB_START+L_CRBS> N_DL_RB)
        error('RB_START + L_CRBS have to be smaller or equal to system rb (N_DL_RB)');
    end
    
    if strcmpi(dciFormat,'Format1A') || strcmpi(dciFormat,'Format1B') || ...
            strcmpi(dciFormat,'Format1C') || strcmpi(dciFormat,'Format1D')
        if ( (L_CRBS-1) <= floor(N_DL_RB/2) )
            riv = N_DL_RB*(L_CRBS-1)+RB_START;
        else
            riv = N_DL_RB*(N_DL_RB-L_CRBS+1) +(N_DL_RB-1-RB_START);
        end
    else
        error('Function not implemented yet for other DCI formats')
    end
end