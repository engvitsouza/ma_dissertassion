%This function takes the transmitted QAM symbols and the received QAM
% symbols and plot them in a given slot.
%
% Usage:
% lte_ShowConstellationsDL(txGrid,rxGrid,frame,slot,cp_type)
% 
% txGrid Grid of transmitted REs, where the rows are the subcarriers and 
% columns are OFDM symbols
% rxGrid Grid of received REs, where the rows are the subcarriers and 
% columns are OFDM symbols
% frame Number of frame to plot, from 0 to ...
% slot Number of slot to plot, from 0 to ...
% cp_type 'normal' or 'extended'
%
function lte_ShowConstellationsDL(txGrid,rxGrid,frame,slot,cp_type)

%TODO: check if is using extended or normal CP
if(strcmpi(cp_type,'extended'))
    N_dl_symb=6;
elseif(strcmpi(cp_type,'normal'))
    N_dl_symb=7;
else
    error('select a valid cp_type: ''normal'' or ''extended'' ');
end
%% plots
figure(201);
for i=0:N_dl_symb-1
    %subplot(2,2,mod(i,4)+1);
    subplot(2,4,i+1);
    ind=slot*N_dl_symb+1+i;
    plot(real(rxGrid(:,ind)),imag(rxGrid(:,ind)),'r.');
    hold on;
    plot(real(txGrid(:,ind)),imag(txGrid(:,ind)),'b+','MarkerSize',14,...
        'LineWidth',2);
    hold off;
    %ylim([-1 1]);xlim([-1 1]);
    title(sprintf('ofdm symbol %d, slot %d',i,slot));
end

end