

%% config

% Same configurations for each 
rmc         = lteRMCUL('A1-3');

% Override the PUSCH information. lteRMCUL returns recomputed PUSCH 
% transport block sizes and physical channel capacities to maintain the 
% coding rate 

rmc.PUSCH.PRBSet     = transpose([0:14]);

% For more details of relation between Transport block size and Number of 
% resource blocks, see 3GPP 36.213, Table 7.1.7.2.1-1: Transport block size 
% table
rmc.PUSCH.TrBlkSizes = 1320*ones(1,10);
%rmc.PUSCH.Modulation ='16QAM';
rmc.CyclicShift = 0;
rmc.SeqGroup = 0;
rmc.RNTI = 1;
ue1 = lteRMCUL(rmc,1);

% Override the PUSCH information. lteRMCUL returns recomputed PUSCH 
% transport block sizes and physical channel capacities to maintain the 
% coding rate 
rmc.PUSCH.PRBSet     = transpose([15:24]);

% For more details of relation between Transport block size and Number of 
% resource blocks, see 3GPP 36.213, Table 7.1.7.2.1-1: Transport block size 
% table
rmc.PUSCH.TrBlkSizes = 872*ones(1,10);

% TODO: maybe we have to change theses parameters to create real distinct
% uplink signals
rmc.CyclicShift = 0;
rmc.SeqGroup = 0;
rmc.RNTI = 2;
ue2 = lteRMCUL(rmc,1);



Nframes = 1;
numSubframes = 10*Nframes;

% TODO: Change RNTI for each UE
ue1_pusch   = ue1.PUSCH;
ue2_pusch   = ue2.PUSCH;

trBlkSize_ue1 = ue1_pusch.TrBlkSizes(1);
trBlkSize_ue2 = ue2_pusch.TrBlkSizes(1);

ue1_bits  = randi([0 1],numSubframes*trBlkSize_ue1,1);
ue2_bits  = randi([0 1],numSubframes*trBlkSize_ue2,1);

txACK =1;

usersPUCCHindices = [2 1 7 14];

%% Signal generation
rxwave_ue1 = [];
rxwave_ue2 = [];
for nsf = 1:numSubframes
    
    % Create resource grid
    ue1.NSubframe = mod(nsf-1,10);
    ue2.NSubframe = mod(nsf-1,10);
    
    txgrid_ue1 = lteULResourceGrid(ue1);
    txgrid_ue2 = lteULResourceGrid(ue2);
    
    % Configure resource index for this user
    % TODO: change here to add more one ue1
    %pucch.ResourceIdx = usersPUCCHindices(1);

    
    % Generate PUCCH 1 and its DRS
    % Different users have different relative powers
    % TODO: change here to add more one ue1
    %pucch1Sym           = ltePUCCH1(ue1,pucch,txACK);
    %pucch1DRSSym        = ltePUCCH1DRS(ue1,pucch);
    
    [DMRSSym_ue1,infoDMRS_ue1,layerseqDMRS_ue1] = ltePUSCHDRS(ue1,ue1_pusch);
    [DMRSSym_ue2,infoDMRS_ue2,layerseqDMRS_ue2] = ltePUSCHDRS(ue2,ue2_pusch);
    
    % Generate user data
    % TODO: update for frames
    % TODO: change here to add more one ue1
    trblkin_ue1 = ue1_bits(ue1.NSubframe*trBlkSize_ue1+1: (ue1.NSubframe+1)*trBlkSize_ue1);
    trblkin_ue2 = ue2_bits(ue2.NSubframe*trBlkSize_ue2+1: (ue2.NSubframe+1)*trBlkSize_ue2);
    
    [cwout_ue1,chinfo_ue1] = lteULSCH(ue1,ue1_pusch,trblkin_ue1);
    [cwout_ue2,chinfo_ue2] = lteULSCH(ue2,ue2_pusch,trblkin_ue2);
    
    puschSym_ue1 = ltePUSCH(ue1,ue1_pusch,cwout_ue1);
    puschSym_ue2 = ltePUSCH(ue2,ue2_pusch,cwout_ue2);
    
    % Generate indices for PUCCH 1 and its DRS
    %pucch1Indices       = ltePUCCH1Indices(ue1,pucch);
    %pucch1DRSIndices    = ltePUCCH1DRSIndices(ue1,pucch);
    puschIndices_ue1     = ltePUSCHIndices(ue1,ue1_pusch);
    puschIndices_ue2     = ltePUSCHIndices(ue2,ue2_pusch);
    
    dmrsIndices_ue1      = ltePUSCHDRSIndices(ue1,ue1_pusch);
    dmrsIndices_ue2      = ltePUSCHDRSIndices(ue2,ue2_pusch);
    
    %txgrid_ue1(pucch1Indices)   = pucch1Sym;
    %txgrid_ue1(pucch1DRSIndices)= pucch1DRSSym;
    txgrid_ue1(puschIndices_ue1)    = puschSym_ue1;
    txgrid_ue2(puschIndices_ue2)    = puschSym_ue2;
    
    txgrid_ue1(dmrsIndices_ue1)     = DMRSSym_ue1;
    txgrid_ue2(dmrsIndices_ue2)     = DMRSSym_ue2;
    
    % SC-FDMA modulation
    txwave_ue1 = lteSCFDMAModulate(ue1,txgrid_ue1);
    txwave_ue2 = lteSCFDMAModulate(ue2,txgrid_ue2);
    
    rxwave_ue1 = [rxwave_ue1;txwave_ue1];
    rxwave_ue2 = [rxwave_ue2;txwave_ue2];
end

rxwave  = rxwave_ue1+rxwave_ue2;
%%
ue1.NSubframe=0;
ue2.NSubframe=0;
[finalEVM_ue1,finalDrsEVM_ue1,emissions_ue1] = hPUSCHEVM(ue1,rxwave_ue1);
[finalEVM_ue2,finalDrsEVM_ue2,emissions_ue2] = hPUSCHEVM(ue2,rxwave_ue2);
