% LTE_GET_FRAME_LTE_TD gives return a given frame of a lte signal
% 
% lte_get_frame_lte_td(x,Nsamples_per_frame,frame_number)
% 
% X the lte signal
% NSAMPLES_PER_FRAME Number of samples for the lte signal configuration.
% FRAME_NUMBER Frame number. An integer number from 0 to ...
%
% see lte_DLPHYparam to get the parameters listed above
%
function frame_lte_td=lte_get_frame_lte_td(x,Nsamples_per_frame,frame_number)
    frame_lte_td= zeros(Nsamples_per_frame,1);
    from_index  = frame_number*Nsamples_per_frame+1;
    to_index    = (frame_number+1)*Nsamples_per_frame;
    frame_lte_td=x(from_index:to_index);
end