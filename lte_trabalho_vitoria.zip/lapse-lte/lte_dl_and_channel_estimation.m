% This code is a modified version of the code in link below:
% http://www.mathworks.com/help/lte/examples/lte-downlink-channel-estimation-and-equalization.html
close all; clear;
%% Cell-Wide Settings
enb.NDLRB = 15;                 % Number of resource blocks
enb.CellRefP = 1;               % One transmit antenna port
enb.NCellID = 0;               % Cell ID
enb.CyclicPrefix = 'Normal';    % Normal cyclic prefix
enb.DuplexMode = 'FDD';         % FDD

%% SNR Configuration

SNRdB = 50;%22;             % Desired SNR in dB
SNR = 10^(SNRdB/20);    % Linear SNR
%rng('default');         % Configure random number generators

%% Channel Model Configuration

cfg.Seed = 1;                  % Random channel seed
cfg.NRxAnts = 1;               % 1 receive antenna
cfg.DelayProfile = 'EVA';      % EVA delay spread
cfg.DopplerFreq = 120;         % 120Hz Doppler frequency
cfg.MIMOCorrelation = 'Low';   % Low (no) MIMO correlation
cfg.InitTime = 0;              % Initialize at time zero
cfg.NTerms = 16;               % Oscillators used in fading model
cfg.ModelType = 'GMEDS';       % Rayleigh fading model type
cfg.InitPhase = 'Random';      % Random initial phases
cfg.NormalizePathGains = 'On'; % Normalize delay profile power
cfg.NormalizeTxAnts = 'On';    % Normalize for transmit antennas

%% Channel Estimator Configuration

cec.FreqWindow = 9;               % Frequency averaging window in
                                  % Resource Elements (REs)
cec.TimeWindow = 9;               % Time averaging window in REs
cec.InterpType = 'Cubic';         % Cubic interpolation
cec.PilotAverage = 'UserDefined'; % Pilot averaging method
cec.InterpWinSize = 3;            % Interpolate up to 3 subframes
                                  % simultaneously
cec.InterpWindow = 'Centred';     % Interpolation windowing method

%% Subframe Resource Grid Size

gridsize = lteDLResourceGridSize(enb);
K = gridsize(1);    % Number of subcarriers
L = gridsize(2);    % Number of OFDM symbols in one subframe
P = gridsize(3);    % Number of transmit antenna ports

%% Payload data generation 

% Number of bits needed is size of resource grid (K*L*P) * number of bits
% per symbol (2 for QPSK)
numberOfBits = K*L*P*2;

% Create random bit stream
inputBits = randi([0 1], numberOfBits, 1);

% Modulate input bits
inputSym = lteSymbolModulate(inputBits,'QPSK');

%% Frame Generation


txGrid = [];

% For all subframes within the frame + 1 (10 subframes + 1 subframe)
% When the OFDM modulated time domain waveform is passed through a channel 
% the waveform will experience a delay. To avoid any samples being missed 
% due to this delay an extra subframe is generated, therefore 11 subframes 
% are generated in total. 
for sf = 0:10

    % Set subframe number
    enb.NSubframe = mod(sf,10);

    % Generate empty subframe
    subframe = lteDLResourceGrid(enb);

    % Map input symbols to grid
    subframe(:) = inputSym;

    % Generate synchronizing signals
    % Note that the Primary Synchronization Signal (PSS) and Secondary 
    % Synchronization Signal (SSS) only occur in subframes 0 and 5, but the
    % LTE System Toolbox takes care of generating empty signals and indices
    % in the other subframes so that the calling syntax here can be
    % completely uniform across the subframes.
    pssSym = ltePSS(enb);
    sssSym = lteSSS(enb);
    pssInd = ltePSSIndices(enb);
    sssInd = lteSSSIndices(enb);

    % Map synchronizing signals to the grid
    subframe(pssInd) = pssSym;
    subframe(sssInd) = sssSym;

    % Generate cell specific reference signal symbols and indices
    % For each subframe the Cell-Specific Reference Signal (Cell RS) is 
    % added.
    cellRsSym = lteCellRS(enb);
    cellRsInd = lteCellRSIndices(enb);

    % Map cell specific reference signal to grid
    subframe(cellRsInd) = cellRsSym;

    % Append subframe to grid to be transmitted
    txGrid = [txGrid subframe]; %#ok

end

%% OFDM Modulation

% Windowing default is 4 (TODO: check if 4 is correct). The spectrum of an 
% OFDM signal shows spectral spikes that are caused by the discontinuity 
% between two OFDM symbols during signal generation. Windowinfg avoid these
% spikes. See: http://www.rohde-schwarz.com/en/applications/smooth-your-lte-signal-application-card_56279-4745.html
enb.Windowing=4;

% txWaveform is the resulting time domain waveform. Each column contains 
% the time domain signal for each antenna port.
[txWaveform,info] = lteOFDMModulate(enb,txGrid);
x=txWaveform;
% txGrid stores only the 140 OFDM symbols (20 (slots) * 7 (symbols/slot))
txGrid = txGrid(:,1:140);

%% channel
cfg.SamplingRate = info.SamplingRate;

% Pass data through the fading channel model
rxWaveform = lteFadingChannel(cfg,txWaveform);
 
% Calculate noise gain
% The noise added before OFDM demodulation will be amplified by the FFT. 
% Therefore to normalize the SNR at the receiver (after OFDM demodulation) 
% the noise must be scaled. 
N0 = 1/(sqrt(2.0*enb.CellRefP*double(info.Nfft))*SNR);

% Create additive white Gaussian noise
noise = N0*complex(randn(size(rxWaveform)),randn(size(rxWaveform)));

% Add noise to the received time domain waveform
rxWaveform = rxWaveform + noise;

%% receiver

% Perform synchronization using the PSS and SSS.  
% offset indicates the number of samples from the start of the waveform to 
% the position in that waveform where the first frame begins
offset = lteDLFrameOffset(enb,rxWaveform);
rxWaveform = rxWaveform(1+offset:end,:);

% OFDM Demodulation (time domain to frequency domain)
rxGrid = lteOFDMDemodulate(enb,rxWaveform);

% Channel estimation
enb.NSubframe = 0;
[estChannel, noiseEst] = lteDLChannelEstimate(enb,cec,rxGrid);

% Channel equalization
eqGrid = lteEqualizeMMSE(rxGrid, estChannel, noiseEst);

%% Analysis

% Calculate error between transmitted and equalized grid
eqError = txGrid - eqGrid;
rxError = txGrid - rxGrid;

% Compute EVM across all input values
% EVM of pre-equalized receive signal
preEqualisedEVM = lteEVM(txGrid,rxGrid);
fprintf('Percentage RMS EVM of Pre-Equalized signal: %0.3f%%\n', ...
        preEqualisedEVM.RMS*100);
% EVM of post-equalized receive signal
postEqualisedEVM = lteEVM(txGrid,eqGrid);
fprintf('Percentage RMS EVM of Post-Equalized signal: %0.3f%%\n', ...
        postEqualisedEVM.RMS*100);

%% plots

% plot constellations 
plotSlot = 0;
lte_ShowConstellationsDL(txGrid, eqGrid, enb, plotSlot);

% Plot the received and equalized resource grids
hDownlinkEstimationEqualizationResults(rxGrid, eqGrid);
