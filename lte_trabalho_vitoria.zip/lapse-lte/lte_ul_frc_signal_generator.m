function [ultxWaveform,frc,bits_to_be_transmitted] = lte_ul_frc_signal_generator(nframes,nrbs,channel,seedval)
% generate lte uplink signal of a fixed reference channel, see TS36104
% output:
%   frc - lte uplink struct
%   ultxWaveform - uplink signal
% input:
%   nframes - number of lte frames, default = 1
%   nrbs - number of resource blocks, default = 100
%   channel - label of FRC, see TS36104, default = 'A5-7' (BW20MHz)
%   seedval - random seed to random number generator

%% From example LTE Uplink EVM and In-Band Emissions Measurements
% Copyright 2010-2014 The MathWorks, Inc.

%%  Transmitter
% To generate the RMC the function <matlab:doc('lteRMCUL') lteRMCUL>
% creates a configuration structure for given UE settings specific to a
% given Fixed Reference Channel (FRC). This structure is used by
% <matlab:doc('lteRMCULTool') lteRMCULTool> to generate a UE transmission
% with random PUSCH data.

if nargin==0
    nframes=1;
    nrbs=100;
    channel='A5-7';
    seedval=0;
else
    if nargin ==1 
        if (nframes<=0 || nframes>10), nframes=1, end
        nrbs=100; channel='A5-7'; seedval=0;
    end
    if nargin ==2
        if (nframes<=0 || nframes>10), nframes=1, end
        if (nrbs>100 || nrbs<0), nrbs=100, end
        channel='A5-7'; seedval=0;
    end
    if nargin ==3 
        if (nframes<=0 || nframes>10), nframes=1, end
        if (nrbs>100 || nrbs<0), nrbs=100, end
        if strcmp(channel,''), channel='A5-7' , end  
        seedval=0;
    end
    if nargin ==4 
        if (nframes<=0 || nframes>10), nframes=1, end
        if (nrbs>100 || nrbs<0), nrbs=100, end
        if strcmp(channel,''), channel='A5-7' , end    
        if seedval<0 || seedval>=2^32, seedval=0, end
    end
end

nsubframes = 10*nframes;
disp('generating uplink signal')
fprintf('%d subframes\n',nsubframes)
fprintf('%d rbs\n',nrbs)
fprintf('%s channel\n', channel)
fprintf('%d random seed\n', seedval)

% Set the seeds of random number generators used to 0. 
% TODO: maybe we must use rng('shuffle')
%rng(seedval);
rng('shuffle');

% UE Configuration, TS36.101 FRC
frc = lteRMCUL(channel); % See TS36.104 to info about FRCs. A5-7 is BW20MHz
frc.PUSCH.RVSeq = 0;    % Redundancy version
frc.TotSubframes = nsubframes;  % Total number of subframes to generate
%TODO: maybe we could get this array from parameters, instead of total
%value, such tat we have more flexibility where to populate the RBs.
frc.PUSCH.PRBSet = (0:nrbs-1).';  % Subframe resource allocation

% Number of bits required for all subframes
Ntot_bits               = nframes*sum(frc.PUSCH.TrBlkSizes);
bits_to_be_transmitted  = randi([0 1],Ntot_bits, 1);

% Create UE transmission with random PUSCH data
ultxWaveform = lteRMCULTool(frc,bits_to_be_transmitted);
end
