function populacao = vit_elitismo(populacao_ord,numInd )
populacao = populacao_ord(1:numInd,:,:);
end