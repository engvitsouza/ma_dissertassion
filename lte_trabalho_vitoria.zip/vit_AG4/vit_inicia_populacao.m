function [pop_x, pop_y] = vit_inicia_populacao(popx,popy)

pop_x  = popx; 
pop_y  = popy; 

end
