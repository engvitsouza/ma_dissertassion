clear;
addpath('../lapse-lte/');
addpath('../compression-utils/');
%% Files with LTE signals

%signal_filePath   = '.\s5\';
%signal_filePath   = '.\lte_signal\s1\';
%signal_filePath   = '.\lte_signal_paper\';
signal_filePath   = '..\LTEsignals\s_25RBs\';

signal_real_filename    = [signal_filePath 's_25RBs_real.dat'];
signal_imag_filename    = [signal_filePath 's_25RBs_imag.dat'];

save_signals_in_a_file = 1;

signal_txout_filename_real = [signal_real_filename '.res'];
signal_txout_filename_imag = [signal_imag_filename '.res'];

fn_signal_norm_values_real      = [signal_real_filename '.norm'];
fn_signal_norm_values_imag      = [signal_imag_filename '.norm'];
fn_signal_max_values_real      = [signal_real_filename '.max'];
fn_signal_max_values_imag      = [signal_imag_filename '.max'];

file_output_name_mat = 'resampled.mat';

if 1
    % read signal from files
    signal      = read_cplx_signal(signal_real_filename,signal_imag_filename);
else
    % read signal from .mat
    tmp_mat = load('../lte-lpc-ul/x_ul_sim.mat');
    signal  = tmp_mat.x_withcp;
end


%% LTE parameters
% Number of resource blocks in a lte signal
Nrb = 25; 
cp_type = 'Normal';

% The lte parameters below at LTE demodulation. Note that NcellID is
% fundamental to demodulate the signal.
enb_param.NDLRB         = Nrb;
enb_param.CyclicPrefix  = cp_type;
enb_param.NCellID       = 0;
enb_param.DuplexMode    = 'FDD';
enb_param.NSubframe     = 0;
enb_param.CellRefP      = 1;

%% 
enb         = lte_DLPHYparam(Nrb,cp_type);
N_cp_l_0    = enb.cp_0_length;
N_cp_l_else = enb.cp_else_length;
N_dl_symb   = enb.N_dl_symb;
FFT_size    = enb.FFT_size;

%% quantization parameters

% block size
Ns = 32; 

% number of bits of original samples
Qs = 15; 

% number of bits used to quantize the scaled samples
Qq = 6;  

%% resampling parameters
K = 2; %at TX: upsampling factor. at RX: downsampling factor
L = 3; %at TX: downsampling factor. at RX: upsampling factor

%% filter parameters

%lpf_rx = fir_lpf_ls_64th;
%lpf_rx = fir_lpf_ls_64th_wp03_ws037;
%lpf_rx = fir_lpf_ls_128th_wp03_ws037;

% it looks near the lpf used in Guo13
lpf_rx = fir_lpf_kaiser_window_Fpass9MHz_Fstop11_85_Fs61_44; 

%lpf_tx = fir_lpf_ls_64th;
%lpf_tx = fir_lpf_ls_64th_wp03_ws037;
%lpf_tx = fir_lpf_ls_128th_wp03_ws037;

% it looks near the lpf used in Guo13
lpf_tx = fir_lpf_kaiser_window_Fpass9MHz_Fstop11_85_Fs61_44;

%filters_delay    = 64;
filters_delay    = 32;

%% compression ratio calculation

Cratio = ((K/L)*Ns*Qq + Qs)/(Ns*Qs);


%% transmitter compression
resample_tx_comp;

%% receiver decompression
resample_rx_decomp;

%% SQNR as in Guo13
% Note that in the paper, the authors propose calculate SQNR in downsampled
% version of the signal.
if 0
    Ptx_ds      = mean(abs(sd(:)).^2);
    noise_ds    = signal_down_rx(:)-sd(:);
    Pn_ds       = mean(abs(noise_ds(:)).^2);
    SQNR_guo    = Ptx_ds/Pn_ds;
    SQNR_guo_dB = 10*log10(SQNR_guo);
end
%% SQNR given by E[|input|^2]/E[|(input - output)|^2]
if  0
    % the signal RX has zeros appended at its end  because the first
    % samples are discard (beacause resampling filter at tx and rx) and in
    % order to match the size of tx signal and rx signal, zeros are
    % inserted at the end of signal_rx.
    % Thus, the last samples of signal_rx are invalid.
    % 15360 is the number of samples in a slot for 20 MHz
    ind_valid    = 1: 15360*9; 
    
    Ptx         = mean(abs(signal(ind_valid)).^2);
    noise       = signal(ind_valid) - signal_rx(ind_valid);
    Pn          = mean(abs(noise(:)).^2);
    SQNR        = Ptx/Pn;
    SQNR_dB     = 10*log10(SQNR);
    SQNR_guo_dB,SQNR_dB
end
%% LTE demodulation
% you can disable this part of toolbox if you dont have the lte toolbox of
% matlab
if 0
    
    time_offset = lteDLFrameOffset(enb_param,signal_quant);
    signal_deoded = signal_quant(time_offset+1:end);
    TX = lteOFDMDemodulate(enb_param,signal);
    signal_decoded = signal_quant(time_offset+1:end); zeros(time_offset,1);
    RX = lteOFDMDemodulate(enb_param,[signal_quant(time_offset+1:end); zeros(time_offset,1)]);
    
    % Estimate channel and noise
    [Hest Nest] = lteDLChannelEstimate(enb_param,RX);
    
    %RX = RX.*Hest;
    
    
    % discard last slot because first samples are discarded
    TX_valid = TX(:,1:end-1);  
    RX_valid = RX(:,1:end-1);
    
    error_vector = RX_valid(:) - TX_valid(:);
    
    evm_as_in_guo = 100*sqrt(mean(abs(error_vector).^2)/...
        mean(abs(TX_valid(:)).^2))
    
    freq_evms= 100*lte_evm_annexE_36104(RX_valid(:,1:126),TX_valid(:,1:126));
    
    evm_as_in_annexE_36104_avg = mean(freq_evms(:))
    
    figure;
    plot(freq_evms);
    xlabel('resource block number');
    ylabel('EVM(%)');
    title('Each line is a subframe');
    
    [N,C]=hist(freq_evms(:),[0:0.01:3]);
    figure;
    plot(C,N);
    xlabel('EVM(%)');
    ylabel('Number of occurrences');
end
if 0
    lte_plot_tx_vs_rx([signal(:)],[signal_decoded(:)],Nrb,'normal',0,0);
end
%% Resampling only (ro)
% this part of code calculates the effects of resampling only.
if 0
    % indices valid. The last samples of signal after filters are the tail
    % of filter
    ro_ind_valid    = 1: 15360*9;
    
    % sd is the downsapled version of tx output
    ro_sd_up        = upsample(sd(:),L);
    
    % take into account resampling of TX and RX
    %ro_sd_up_filtered   = (L*K)*filter(lpf_rx.Numerator,lpf_rx.Denominator,ro_sd_up);
    ro_sd_up_filtered   = conv(lpf_rx.Numerator,ro_sd_up);
    ro_signal_quant     = downsample(ro_sd_up_filtered,K);
    
    ro_offset = lteDLFrameOffset(enb_param,ro_signal_quant);
    
    % Skip first samples of resampled signal, such that the ''transient''
    % region of filtes are not taken into account.
    ro_signal_rx        = ro_signal_quant(ro_offset+1:end);
    ro_rxGrid           = lteOFDMDemodulate(enb_param,ro_signal_rx);
    %% channel estimation
    if 1
        % Channel Estimator Configuration
        cec.FreqWindow = 9;               % Frequency averaging window in
        % Resource Elements (REs)
        cec.TimeWindow = 9;               % Time averaging window in REs
        cec.InterpType = 'Cubic';         % Cubic interpolation
        cec.PilotAverage = 'UserDefined'; % Pilot averaging method
        cec.InterpWinSize = 3;            % Interpolate up to 3 subframes
        % simultaneously
        cec.InterpWindow = 'Centred';     % Interpolation windowing method
        
        % Channel estimation
        enb_param.NSubframe = 0;
        [estChannel, noiseEst] = lteDLChannelEstimate(enb_param,cec,ro_rxGrid);
        
        % Channel equalization
        ro_RxEqGrid = lteEqualizeMMSE(ro_rxGrid, estChannel, noiseEst);
    end
%%
    txGrid  = lteOFDMDemodulate(enb_param,signal);
    
    ro_evms = lte_evm_annexE_36104(txGrid,ro_RxEqGrid);
    %%
    ro_signal_rx_valid  = ro_signal_rx(ro_ind_valid);
    ro_signal_tx_valid  = signal(ro_ind_valid);
    ro_noise_valid      = ro_signal_tx_valid(:)-ro_signal_rx_valid(:);
    
    ro_Ptx      = mean(abs(ro_signal_tx_valid).^2);
    ro_Pnoise   = mean(abs(ro_noise_valid).^2);
    
    ro_EVM_time_domain = 100*sqrt(ro_Pnoise/ro_Ptx);
    
    ro_SNR     = ro_Ptx/ro_Pnoise;
    
    ro_SNR_db  = 10*log10(ro_SNR)
    
end